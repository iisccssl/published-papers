package com.ibm.wala.cast.js.test.tool;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.ibm.wala.cast.js.ssa.JavaScriptInvoke;
import com.ibm.wala.cast.js.test.tool.DumpModuleDatalogFacts.MethodNodeData;

import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.SSAInstruction;


public class HashGenerateFactsForTemplate {

	private Map<String, TemplateEntry> importedPropertyTree; //hierarchy, TemplateEntry
		
	public class TemplateEntry{
		String hierarchy;
		String parent; // parent means the hierarchy except the propertyName
		String propertyName;
		ArrayList<String> privileges;
		String type;
		String heapObject; // heapObject corrs to the the property in the hierarchy
	}

	private String templateDir;
	private String reqHeapObjName;
	String importedModule;
	MethodNodeData currentMethodNode;
	IR ir;
	SSAInstruction instruction;
	String shortCurrentMethodName;
	BufferedWriter bOut;
	private String vNumPrefix;
	
	public HashGenerateFactsForTemplate(String tempDir, String heapObjectName,
			String importedModule, MethodNodeData currentMethodNode, IR ir,
			SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut) {
		
		this.templateDir = tempDir;
		this.reqHeapObjName = heapObjectName;
		this.importedModule = importedModule;
		this.currentMethodNode = currentMethodNode;
		this.instruction = instruction;
		this.ir = ir;
		this.shortCurrentMethodName = shortCurrentMethodName;
		this.bOut = bOut;
		
		this.vNumPrefix = "imported";
	}
	

	public void generateFactsFromTemplate() throws IOException {

		String fact;
		
		
		
		Iterator<TemplateEntry> templateEntryIterator = this.importedPropertyTree.values().iterator();

		while(templateEntryIterator.hasNext()){

			TemplateEntry entry = templateEntryIterator.next();
			
			if(entry.propertyName.equals("exports")){
				/*
				 * no need to process for exports entry
				 */
				continue;
			}

			TemplateEntry parentEntry = this.importedPropertyTree.get(entry.parent);

			if(parentEntry.type.equalsIgnoreCase("Object")) {
				
				this.processEntry(entry);

				/*
				 * generate heapPtsTo fact
				 * Assumption parentEntry.heapObject mapping is never null 
				 * And after processing the entry entry.heapObject has been set to
				 */
								
				fact = "heapPtsTo("+ parentEntry.heapObject +","
						+ this.makeDatalogCompatibleString(entry.propertyName) +" , "
						+ entry.heapObject + ").\n";

				bOut.write(fact);

			}
			else if (parentEntry.type.equalsIgnoreCase("Function")){
				
				/*
				 *  store everything in the v2 for this method if it is used as a constructor
				 *  which we can determine if it appears as a parent of any property in the tree
				 *  otheriwse it will be treated as a normal function and only facts for the return values will be generated
				 */
				
				
				String vNumString = this.vNumPrefix + "_" + "v2" + "_"+ this.makeDatalogCompatibleString(parentEntry.hierarchy) +"_"+ this.importedModule +"_"+ this.shortCurrentMethodName;
				fact = "formal("+ parentEntry.heapObject+ ","+ 1 +","+ vNumString + ").\n";  
				bOut.write(fact);
				
				String lValNumString =	vNumString;
				String  rValNumString = this.vNumPrefix + "_" + "v"+ "_" + this.makeDatalogCompatibleString(entry.propertyName)+ "_" +  this.importedModule + "_"+ this.makeDatalogCompatibleString(parentEntry.hierarchy) +"_"+ this.shortCurrentMethodName;

				fact = "store("+ lValNumString +", "+ this.makeDatalogCompatibleString(entry.propertyName)+", "+ rValNumString +").\n";
				bOut.write(fact);  

				/*
				 * set the heap object mapping for both object and function
				 */				 
				this.processEntry(entry);
				/*
				 * generate ptsTo fact
				 * after processing the entry entry.heapObject has been set to
				 */
				
				fact = "ptsTo("+ rValNumString + ", " + entry.heapObject + ").\n";
			}
		}		
	}

	
	
	private void processEntry(TemplateEntry entry) throws IOException {
	
		if(entry.type.equalsIgnoreCase("Object")){					
			this.processObjectEntry(entry);					
		}

		else if (entry.type.equalsIgnoreCase("Function")){					
			this.processFunctionEntry(entry);				
		}
			
	}


	private void processFunctionEntry(TemplateEntry entry) throws IOException {
		
		String fact;
		String propertyHeapObjName = "";
		
		propertyHeapObjName = entry.heapObject;
		
		if(propertyHeapObjName == null){		
			propertyHeapObjName = "h_func_" + entry.propertyName + "_" +  this.importedModule +"_"+ this.shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
			entry.heapObject = propertyHeapObjName; 
			this.importedPropertyTree.put( entry.hierarchy, entry);
		}	
		/*
		 * handling return privileges from a function, generate the below facts only if the function returns any privileges
		 */
		if(entry.privileges != null){
			/*
			 * methodRet facts
			 */
			String vNumString = this.vNumPrefix + "_" + "v" +"_"+ "retOf_" + this.makeDatalogCompatibleString(entry.hierarchy) + "_" + importedModule +"_"+ shortCurrentMethodName ; 
			fact = "methodRet("+ propertyHeapObjName +","+ vNumString  + ").\n";  
			bOut.write(fact);

			String retHeapObjName = "h_ret_" + entry.propertyName + "_" + this.importedModule +"_"+ this.shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();

			fact = "ptsTo("+ vNumString+","+ retHeapObjName+").\n";
			bOut.write(fact);
			
			this.generateTaintedFacts(retHeapObjName, entry.privileges);		
		}

		//TODO handle  prototype
		
	}


	private void processObjectEntry(TemplateEntry entry) throws IOException {
		
		String propertyHeapObjName = "";
		
		propertyHeapObjName = entry.heapObject;
		
		if(propertyHeapObjName == null){
			propertyHeapObjName = "h_obj_" + entry.propertyName + "_" +  importedModule +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
			entry.heapObject = propertyHeapObjName; 
			this.importedPropertyTree.put( entry.hierarchy, entry);
		}	

		if(entry.privileges != null){						
			this.generateTaintedFacts(propertyHeapObjName, entry.privileges);						
		}
		
	}


	private void generateTaintedFacts(String heapObjName, ArrayList<String> privileges) throws IOException {
		
		int i;
		String fact;
		
		for(i = 0 ; i < privileges.size() ; i++){
			
			fact = "isTainted(" 
				+ heapObjName + ","
				+ privileges.get(i)
				+ ").\n";

			bOut.write(fact);
		}		
	}


	public void readTemplatedFile(String importedModule) {
		
		TemplateEntry tEntry;
		String templateFile = this.templateDir+ File.separator + importedModule+".txt"; 
		
		this.importedPropertyTree = new HashMap<String,TemplateEntry>(); 
		try{
			// Open the file 	
			FileInputStream fstream = new FileInputStream(templateFile);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			
			/*
			 * Process the 1st line for the exports entry
			 */
			if ((strLine = br.readLine()) != null){
				
				String entry[] = strLine.split("\\s+");
				/*
				 * privileges associated with exports
				 */
				String privileges[] = entry[1].split(",");
				tEntry = new TemplateEntry();
				tEntry.hierarchy = entry[0];
				tEntry.heapObject = this.reqHeapObjName;
				tEntry.parent = "";			
				tEntry.propertyName = "exports";
				tEntry.type = "Objects";
				tEntry.privileges = new ArrayList<String>();
				for(int i = 0 ; i < privileges.length ; i++){
					tEntry.privileges.add(privileges[i]);
				}
				
			    this.generateTaintedFacts(reqHeapObjName, tEntry.privileges);
							
			}
			
			//Read File Line By Line
			while ((strLine = br.readLine()) != null)   {
				// Print the content on the console
				System.out.println ("^^^^^^^^^^^^^^^^^^^^^^^^^"+strLine);
				if(strLine.equalsIgnoreCase(""))
					continue;// skip the empty lines
				
				String entry[] = strLine.split("\\s+");
				String hierarchy = entry[0];
				if(this.existsInPropertyTree(hierarchy)){
					/*
					 * entry already exists, ass to privileges list
					 * Assumption: An entry will not have null privilege if it has privilege in another line
					 * So the privileges list has already been initialized
					 */
					tEntry = this.importedPropertyTree.get(hierarchy);
					if(! entry[2].equalsIgnoreCase("null")){
						tEntry.privileges.add(entry[2]);
						this.importedPropertyTree.put(hierarchy, tEntry);
					}
				}
				else{
					/*
					 * entry does not exist in the tree, create a new one
					 */
					tEntry = new TemplateEntry();
					tEntry.hierarchy = entry[0];
					int index = tEntry.hierarchy.lastIndexOf(".");
					tEntry.parent = tEntry.hierarchy.substring(0, index); 							
					tEntry.propertyName = tEntry.hierarchy.substring(index + 1);
					tEntry.type = entry[1];
				
					if(!entry[2].equalsIgnoreCase("null")){
						tEntry.privileges = new ArrayList<String>();
						tEntry.privileges.add(entry[2]);
					}
				
					this.importedPropertyTree.put( tEntry.hierarchy, tEntry);
				}
			}
			//Close the input stream
			in.close();
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}		
	}

	private boolean existsInPropertyTree(String hierarchy) {
		
		return this.importedPropertyTree.containsKey(hierarchy);		
	}


	public void dumpDatalogFacts() {
		 this.readTemplatedFile(importedModule);
		
		 try {
			this.generateFactsFromTemplate();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private String makeDatalogCompatibleString(String identifier) {

		if(identifier.contains("/"))
			identifier = identifier.replace('/', '_');
		if(identifier.contains("."))
			identifier = identifier.replace('.', '_');		
		if (identifier.contains("-"))
			identifier = identifier.replace('-', '_');

		// TODO Auto-generated method stub
		char firstChar = identifier.charAt(0);
		if (firstChar >='A' && firstChar <= 'Z'){
			// make an uppercase letter to lowercase
			char modifiedFirstChar = (char) (firstChar + ' ');
			identifier = identifier.replace(firstChar, modifiedFirstChar);
			return identifier + "_uppercase"; // indicating that the original text has the first letter in uppercase
		}	
		return identifier;
	}


}
