package com.ibm.wala.cast.js.test.tool;

/******************************************************************************

 * Copyright (c) 2002 - 2006 IBM Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *****************************************************************************/
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.ibm.wala.cast.ir.ssa.AstLexicalRead;
import com.ibm.wala.cast.ir.ssa.AstLexicalWrite;
import com.ibm.wala.cast.js.ipa.callgraph.JSCFABuilder;
import com.ibm.wala.cast.js.ipa.callgraph.JSZeroOrOneXCFABuilder;
import com.ibm.wala.cast.js.ipa.callgraph.Util;
import com.ibm.wala.cast.js.loader.JavaScriptLoader;
import com.ibm.wala.cast.js.loader.JavaScriptLoaderFactory;
import com.ibm.wala.cast.js.ssa.JavaScriptInvoke;
import com.ibm.wala.cast.js.ssa.JavaScriptPropertyRead;
import com.ibm.wala.cast.js.ssa.JavaScriptPropertyWrite;
import com.ibm.wala.cast.js.ssa.JavaScriptMultiplePermissionAnalysis.CheckBinaryOpInstruction;
import com.ibm.wala.cast.js.translator.CAstRhinoTranslatorFactory;
import com.ibm.wala.cast.js.types.JavaScriptMethods;
import com.ibm.wala.cast.loader.AstMethod;
import com.ibm.wala.classLoader.CallSiteReference;
import com.ibm.wala.classLoader.SourceFileModule;
import com.ibm.wala.examples.properties.WalaExamplesProperties;
import com.ibm.wala.ipa.callgraph.AnalysisCache;
import com.ibm.wala.ipa.callgraph.AnalysisOptions;
import com.ibm.wala.ipa.callgraph.AnalysisScope;
import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.CallGraphStats;
import com.ibm.wala.ipa.callgraph.Entrypoint;
import com.ibm.wala.ipa.callgraph.propagation.cfa.ZeroXInstanceKeys;
import com.ibm.wala.ipa.cha.IClassHierarchy;
import com.ibm.wala.properties.WalaProperties;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.ISSABasicBlock;
import com.ibm.wala.ssa.SSABinaryOpInstruction;
import com.ibm.wala.ssa.SSACFG;
import com.ibm.wala.ssa.SSAGetInstruction;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.ssa.SSAPhiInstruction;
import com.ibm.wala.ssa.SSAPutInstruction;
import com.ibm.wala.ssa.SSAReturnInstruction;
import com.ibm.wala.ssa.SymbolTable;
import com.ibm.wala.types.TypeName;
import com.ibm.wala.util.collections.Pair;
import com.ibm.wala.util.debug.Assertions;
import com.ibm.wala.util.warnings.WalaException;
import com.ibm.wala.viz.DotUtil;
import com.ibm.wala.viz.PDFViewUtil;

/*
 * This version distinguishes callsites by a number, does not simulate the call stack.
 * It is followed by Count since it needs to count the number of times a function has been invoked;  this is done only to eliminate duplicate
 * facts from being generated 
 *   
 */

// support require, globals, on event



class DumpProgramAnalysisDatalogFacts {
	
    /*private final String outputDirName = "/prospero/local/eclipse-workspace/wala/dump-cfg-outputs/image-editor-cfg/demo4";
	private final String outputDirName = "/prospero/local/eclipse-workspace/wala/dump-cfg-outputs/simple-lexical-prop";*/
	private final String outputDirName = "/prospero/local/Jetpack/storage";

	//TODO : change output directory name
	//private final String outputDirName = "/home/nawrin/eclipse_workspace/wala/dump-cfg-outputs/jetpack-modules/text-streams";
	CallGraph callGraph;
  
   public class MethodNodeData{
	  
    int nodeID;
    int noOfParameters;
    int invocationCount; 
    /*the intention was to differentiate between callsites that would cause a heap object creation inside a method. however
	it turns out to be difficult to identify the method itself i.e the node, therefore  currently there will be only one object created inside a function even though there can be multiple invocation of that function*/
    ArrayList<Integer> returnVNums; // empty if no return or void return
    TypeName type;
    /*
     * store the heapObjectCorresponding to this method
     */
    String methodHeapObject;
    String prototypeHeapObject; // could have inferred it through datalog rules, but in stead of that storing here to reduce the number of facts
    
    /**
     * Store a list <parameter/locals string, < vNum, Heap object>> mappings
     * However, with the current flow- context insensitive analysis model, no need to store the heapObject information for an identifier either
     * since now all the vNum corrs. to the same variable will point to all heap object corrs. to that variable   
     */
		
    Map< String, Pair<String, String>>  identifierToHeapMapping;
	 
    int parentNodeID;// method node for the lexical parent of this method 
    
    Map< Integer, String> vNumToIdentifierMapping;
    Map< String, String> WALAAssignIdToVNumMapping; // example: self, v8_StreamManager
  }
 
  ArrayList<MethodNodeData> codeBodyNodesInCG;
 
  public DumpProgramAnalysisDatalogFacts(CallGraph cg2) {
	  callGraph = cg2;
	  codeBodyNodesInCG = new ArrayList<MethodNodeData> (); 
	  
  }

  public void dumpCallGraph(JSCFABuilder builder){
	  System.out.println("dumping CG via Util method invocation");
	  Util.dumpCG(builder, callGraph);
	  System.err.println("printing cg "+ callGraph);
	  System.out.println(" CallGraph Statistics "+CallGraphStats.getStats(callGraph));
  }

  public void loadCodeBodyNodesinCG(String dir, String[] fileNames){
	  
	  for(int i=0; i< fileNames.length; i++){
	  
		TypeName type = TypeName.findOrCreate("L" + dir + "/" + fileNames[i]);
		if (callGraph != null) {
		  Iterator<CGNode> iter = callGraph.iterator();
		  CGNode node;
		  while (iter.hasNext()) {
			node = iter.next();
			TypeName tempType = node.getMethod().getDeclaringClass().getName();
	      
			if (tempType.toString().contains(fileNames[i]) && node.getGraphNodeId()> 1) {
			  
			  System.out.println("block no "+ node.getGraphNodeId() + " method "+ node.getMethod() ); 
			  System.out.println(tempType.toString() +" " +tempType.getInnermostElementType()+ " "+node.getGraphNodeId());
			
			  if(node.getMethod().toString().contains("Code body") && node.getGraphNodeId()>1){
			    /*
			     * construct an instance of  MethodNodeData and set the property value
			     */
	    		MethodNodeData aMethodData = new MethodNodeData();
	    		aMethodData.nodeID = node.getGraphNodeId();
	    		aMethodData.type = tempType; 
	    		aMethodData.noOfParameters = node.getMethod().getNumberOfParameters();
	    		aMethodData.returnVNums = new ArrayList<Integer>();
	    		if(aMethodData.nodeID < 62){
	    			aMethodData.invocationCount =1;
	    			aMethodData.parentNodeID = 1; // their parent is prologue.js
	    		}	
	    		
	    		aMethodData.identifierToHeapMapping = new HashMap< String, Pair<String, String>>();
	    		aMethodData.vNumToIdentifierMapping = new HashMap<Integer, String>();
	    		aMethodData.WALAAssignIdToVNumMapping = new HashMap< String, String>();
	    		/*
	    		 * find the return vNum 
	    		 */
	    		SSAInstruction[] instructions = node.getIR().getInstructions();
	    		
	    		
	    		for (int j = 0; j < instructions.length; j++) {
	    			if (instructions[j] instanceof SSAReturnInstruction ){
	    				if (!((SSAReturnInstruction)instructions[j]).returnsVoid())
		    			  aMethodData.returnVNums.add(new Integer (instructions[j].getUse(0)));		    			
		    		}  	
	    		}
	            codeBodyNodesInCG.add(aMethodData);
	    	  }   
	        } 
	     
	      }
	    }
	    
	  } 
  }
  
  public void createPDFforCFG(){
	  
	  int i;
	  String methodName, temp;
	  SSACFG cfg;
	  IR ir;
	  
	 
	  for(i=0; i < codeBodyNodesInCG.size(); i++){
	    temp = this.codeBodyNodesInCG.get(i).type.toString();
	    if(this.codeBodyNodesInCG.get(i).nodeID > 62){
	      methodName = temp.substring( temp.lastIndexOf(".")+4);
	      /*if(methodName.contains("/"))
	    	  methodName = methodName.substring( methodName.lastIndexOf("/"));*/
	      methodName = methodName.replace('/', '_');
	    }	 
	    else{
	      //methodName = "mScope"+"_"+temp.substring(temp.lastIndexOf("/")+1, temp.lastIndexOf(".")) ;
	    	methodName = "moduleScope";
	    }
	      	
		String pdfFileName =  methodName +"_cfg.pdf";
	    String dotFileName = methodName +"_cfg.dot";
	    
	    System.out.println(" pdf file "+pdfFileName);
	    // Get the IR of a CGNode
	    // Get CFG from IR
	    ir = callGraph.getNode(this.codeBodyNodesInCG.get(i).nodeID).getIR();
	    cfg = ir.getControlFlowGraph();
	    //load pdf properties
	    Properties wp = null;
	    try {
	      wp = WalaProperties.loadProperties();
	      wp.putAll(WalaExamplesProperties.loadProperties());
	    } catch (WalaException e) {
	      e.printStackTrace();
	      Assertions.UNREACHABLE();
	    }
	    String psFile = wp.getProperty(WalaProperties.OUTPUT_DIR) + File.separatorChar + pdfFileName;
	    String dotFile = wp.getProperty(WalaProperties.OUTPUT_DIR) + File.separatorChar
	        + dotFileName;
	    
	    String dotExe = wp.getProperty(WalaExamplesProperties.DOT_EXE);
	    String gvExe = wp.getProperty(WalaExamplesProperties.PDFVIEW_EXE);
	    
	    //draw the .dot file and load it in pdf file
	    try{
	      DotUtil.dotify(cfg, PDFViewUtil.makeIRDecorator(ir), dotFile, psFile, dotExe);
	      PDFViewUtil.launchPDFView(psFile, gvExe);
	    }
	    catch(Exception e){
	    	e.printStackTrace();
	    }
	    //print Variable names
	    System.out.println("variable file name should be "+ methodName+ "_var");
	    String varFileName = methodName + "_var";
	    printVarName(ir, varFileName);
	   
	 }  
  }
  
  public void dumpDatalogFacts() throws Exception {
	
	String desPath = "/prospero/local/software/des/examples";  

	FileWriter fstream = new FileWriter(desPath +"/programFacts.dl");
	BufferedWriter bOut = new BufferedWriter(fstream);  
	
	FileWriter exportFile = new FileWriter(this.outputDirName+"children.txt");
	BufferedWriter exportOut = new BufferedWriter(exportFile);  
	
	FileWriter phiMapFile = new FileWriter(this.outputDirName+"/phiVNum.txt");
	BufferedWriter phiMapOut = new BufferedWriter(phiMapFile);  
	
	
	  
	int global_i = 0; //increment it @ each callSiteID  
	int lValNum, rValNum;
	int ref, val;
	int objectRef, memberRef;
	int result;
	String field;
    String currentMethodName; //<todo> change it to the method name
    String vNumStringInDefiner;
	String variableDefiner;
	   
	String fact;
	String callSiteID;
	CallSiteReference callSite;
	MethodNodeData currentMethodNode;
    
	String originalPrefix = "org";
	
    /*
     * initialize the callStack
     */
    
    
    for(int i=0; i< this.codeBodyNodesInCG.size();i++){
      
      /**
       * map vNum to integer declared in parent scope	
       */
      HashMap<Integer, String> vNumOfIdentifierInParentScope = new HashMap<Integer, String>();	
      /*
       * set the method to be processed
       */
      currentMethodNode = this.codeBodyNodesInCG.get(i);
      currentMethodName = currentMethodNode.type.toString();
      
      String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
	  /*
	   * invoking removeDash is enough csince this string will be attached to vNum
	   */
      shortCurrentMethodName = this.removeDash(shortCurrentMethodName);
	  
      
	  /*
	   * get the IR of the node being processed
	   */
	  IR ir = callGraph.getNode(currentMethodNode.nodeID).getIR();
	  /* 
	   * Get CFG from IR
	   */
      SSACFG cfg = ir.getControlFlowGraph();
      /*
       * Iterate over the Basic Blocks of CFG
       */
    
      /* @Assumption: method names are unique
       * 
       */
      Iterator<ISSABasicBlock> cfgIt = cfg.iterator();
      int blockIndex =0;
      int lastInstrIndex = ir.getInstructions().length -1;
    
      while (cfgIt.hasNext()) {
    	ISSABasicBlock ssaBb = cfgIt.next();
     
        System.out.println("BLOCK number "+blockIndex);
                
        blockIndex ++;
        // Iterate over SSA Instructions for a Basic Block
        Iterator<SSAInstruction> ssaIt = ssaBb.iterator();
        while (ssaIt.hasNext()) {
           SSAInstruction instruction = ssaIt.next();
           //Print out the instruction
           System.out.println(instruction);
           
           if(instruction instanceof AstLexicalRead){
        	 int numRead = ((AstLexicalRead)instruction).getAccessCount();
        	 
        	 String rVarName;
        	 for(int r=0;r<numRead;r++){
        	      
        	   rVarName = ((AstLexicalRead)instruction).getAccess(r).variableName;
        	   lValNum = ((AstLexicalRead)instruction).getAccess(r).valueNumber;
        	   variableDefiner = ((AstLexicalRead)instruction).getAccess(r).variableDefiner;
        	   
        	   /*String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
        	   shortCurrentMethodName = this.makeDatalogCompatibleString(shortCurrentMethodName);*/
        	   
        	   /*
        	    * generate facts only for the methods that are defined and called
        	    * i.e. no need to generate these facts for the main (id >=2 && id <=62 ) method 
        	    */
        	   if(!this.isKeyWord(rVarName)){
        		 
        		 vNumOfIdentifierInParentScope.put(new Integer(lValNum), rVarName);
        		   
                 if(currentMethodNode.nodeID > 62 ){
            	   /**
            	    * However I think there would not be any lexicalRead instruction with non-keyword string to analyze in main method
            	    * so these nodeID checking may be redundant
            	    */
          	       fact= "formalLexicalRead("+ currentMethodNode.methodHeapObject +","+
          	                                "v"+lValNum+"_"+shortCurrentMethodName +","+
          	                                this.makeDatalogCompatibleString(rVarName)+ 
          	                             ").\n";
          	       bOut.write(fact);  
          	       System.out.print(fact);
                 }
               
                 /*
                  * for a varName in the parent/global scope get the vNum from the methodNodeData and generate assign fact
                  */
                 if(variableDefiner == null){
                   System.out.println("probably in global scope");
                   //TODO change this one if required 
                   this.codeBodyNodesInCG.get(0); // node 2 is stored at 0 index 
                 }
                 else{
                   MethodNodeData definerNode = this.getNodeFromMethodName(variableDefiner);
                   Pair<String, String> vNumHeapObjPair = definerNode.identifierToHeapMapping.get(rVarName);
                   /*
                    * handing instruction self=this; in parent node and later using self in child node
                    */
                   vNumStringInDefiner = definerNode.WALAAssignIdToVNumMapping.get(rVarName);
                   
                   if(vNumHeapObjPair != null) {
                     vNumStringInDefiner = vNumHeapObjPair.fst;
                     fact = "assign(v"+ lValNum +"_"+shortCurrentMethodName +","+vNumStringInDefiner +").\n";            	
            	     bOut.write(fact);  
            	     System.out.print(fact);
                   }
                   
                   else if( vNumStringInDefiner != null){
                	 fact = "assign(v"+ lValNum +"_"+shortCurrentMethodName +","+vNumStringInDefiner +").\n";            	
              	     bOut.write(fact);  
              	     System.out.print(fact);  
                   }
                 }
        	   }  
        	   
        	 }     
        	 
        	 
           }
           else if(instruction instanceof AstLexicalWrite){
        	 
        	 rValNum = ((AstLexicalWrite)instruction).getAccess(0).valueNumber; // assuming only one assignment
             String lVarName = ((AstLexicalWrite)instruction).getAccess(0).variableName;
             variableDefiner = ((AstLexicalWrite)instruction).getAccess(0).variableDefiner;
             //String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
             String rValNumString = "v"+ rValNum +"_"+shortCurrentMethodName;
                          
      	     /*
      	      * generate facts only for the methods that are defined and called
      	      * i.e. no need to generate these facts for the main (id >=2 && id <=62 ) method 
      	      */
             if (currentMethodNode.nodeID > 62){
          	    //this check may be redundant
        	    fact= "formalLexicalWrite("+ currentMethodNode.methodHeapObject +","+
        	    							this.makeDatalogCompatibleString(lVarName)+ ","+
        	                                rValNumString +
        	                             ").\n";
        	    bOut.write(fact);  
        	    System.out.print(fact);
             }
             vNumOfIdentifierInParentScope.put(new Integer(rValNum), lVarName);
             
             //TODO
             /*
              * for a varName in the parent/global scope get the vNum from the methodNodeData and generate assign fact
              * lexicalwrite instruction is not generated for writing into a locally defined variable, 
              * so whenever a lexicalwrite instruction appears,
              *      check in the current method node whether any entry have been created for the identifier,
              *           in that case remove it
              *   Had there been a collision, say a local variable has the same name as something in parent scope, 
              *      there would not be lexicalread/lexical write instruction, since the one from parent scope get overwritten by locally declared one          
              */
             if(variableDefiner == null){
                System.out.println("probably in global scope");
                //TODO change this one if required 
                this.codeBodyNodesInCG.get(0); // node 2 is stored at 0 index 
             }
             else{
                MethodNodeData definerNode = this.getNodeFromMethodName(variableDefiner);
                Pair<String, String> vNumHeapObjPair = definerNode.identifierToHeapMapping.get(lVarName);
                
                
                if(vNumHeapObjPair != null) {
                  vNumStringInDefiner = vNumHeapObjPair.fst;
                  fact = "assign("+ vNumStringInDefiner +","+ rValNumString+").\n";            	
                  bOut.write(fact);  
                  System.out.print(fact);
                  
                  /*
                   * Change in the current method node
                   */
                  this.removeMapEntryInCurrentMethodNode(currentMethodNode.nodeID, lVarName);
                  
                }  
                else{
                  /*
                   * this case corresponds to some x, that have in defined in parent scope as a normal var pointing to a primitive value
                   * therefore no entry was created in the methodNode
                   * But at this point x has been updated in some child node. so we are creating the entry in the definer parent node, 
                   *  the motive is x might now point to an heap object now and later accessed in some other method,
                   *  If we don't create the entry now in the definer method, later we wont be able to create appropriate assign fact upon x being accessed
                   */
                  this.createMapEntryInDefinerNode(definerNode.nodeID, lVarName, rValNumString);
                	
                }
             }
             
           }
           else if(instruction instanceof SSAPutInstruction ){
  		
        	 field = ((SSAPutInstruction) instruction).getDeclaredField().getName().toString();
  		  
        	 lValNum = ref = ((SSAPutInstruction)instruction ).getRef();
        	 rValNum = val = ((SSAPutInstruction) instruction).getVal();
          
        	 //String shortCurrentMethodName = currentMethodName.substring(currentMethodName.lastIndexOf("/")+1);
        	 /*String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
        	 shortCurrentMethodName = this.makeDatalogCompatibleString(shortCurrentMethodName);*/

        	 
        	 fact= "store(v"+ lValNum+"_"+shortCurrentMethodName +", "+ this.makeDatalogCompatibleString(field)+", v"+ rValNum +"_"+shortCurrentMethodName+").\n";
        	 bOut.write(fact);  
        	 System.out.print(fact);
        	 
        	 // handling exports
        	 String objectName = getVarName(ir, lValNum);
        	 
        	 if (objectName != null && objectName.equals("exports")){
        		 System.out.println("exports");
        		 
        	     System.out.println(">>>>>>>>>>>>>"+field+ " "+rValNum);
        	     String exportInfo = field + ","+ originalPrefix + "__"+"v"+rValNum +  "_" + shortCurrentMethodName+"\n";
        	     exportOut.write( exportInfo);
        		 
        		 
        	 }		 
        	 
        	 int instructionIndex = this.getInstructionIndex(ir, instruction);
        	 AstMethod method =  (AstMethod) ir.getMethod();
        	   
        	 int lineNum = method.getLineNumber(instructionIndex);
        	   
        	 System.out.println("******************"+lineNum);
        	
        	 
           }
           else if(instruction instanceof SSAGetInstruction ){
        	
        	 field = ((SSAGetInstruction) instruction).getDeclaredField().getName().toString();
        	 rValNum = ref = ((SSAGetInstruction) instruction).getRef();
        	 lValNum = val = ((SSAGetInstruction) instruction).getDef();
          
        	 //String shortCurrentMethodName = currentMethodName.substring(currentMethodName.lastIndexOf("/")+1);
        	 //String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
          
       	  	 fact= "load(v"+ lValNum+"_"+shortCurrentMethodName +", v"+ rValNum +"_"+shortCurrentMethodName+", "+ this.makeDatalogCompatibleString(field)+").\n";
           
       	  	 bOut.write(fact);  
       	  	 System.out.print(fact);
       	  	 
       	  	 String rVarName = getVarName(ir, rValNum);
       	  	 if (rVarName == null)
       	  		 rVarName = currentMethodNode.vNumToIdentifierMapping.get(new Integer(rValNum));
       	  	 //todo. check the 1st condition
       	  	 if(rVarName != null && rVarName.equalsIgnoreCase("chromePrivilege") 
       	  		 &&  (    field.equalsIgnoreCase("Cc")
       	  		       || field.equalsIgnoreCase("Ci")
       	  		       || field.equalsIgnoreCase("Cu")
       	  		       || field.equalsIgnoreCase("Cr")
       	  		       || field.equalsIgnoreCase("components")
       	  		     )
       	  	   ){
       	  		 
       	  	     for (int j=1; j<= currentMethodNode.invocationCount ;j++){
   			     
       	  	    	// heap object name differs from the one in invoke instr. coz the program counter info not available 
       			    String heapObjectName = "h_obj" + j +"_"+ lValNum +"_"+ field +"_"+shortCurrentMethodName ;
       			
       			    String vNumString = "v"+ lValNum +"_"+shortCurrentMethodName;
       			    fact = "ptsTo(" + vNumString +","+ heapObjectName+").\n"; 
	   			    System.out.println(fact);
	   			    bOut.write(fact);
       			    
	 			    fact = "isPrivileged(" 
	 			    	              + heapObjectName + ","
	 			    	              + "chrome"
	 			    	              + ").\n";
	 			     
	 			    System.out.println(fact);
	   			    bOut.write(fact);
	   			    
	   			    fact = "idIsPrivileged(" 
	   			    			+ vNumString + ","
	   			    			+ "chrome"
	   			    			+ ").\n";
     
	   			    System.out.println(fact);
	   			    bOut.write(fact);
	    		    
                } 	 
       	  		 
       	  	 }
       	  		 
       	  		 
           }
           else if(instruction instanceof JavaScriptPropertyRead){
        	
        	 lValNum = result = instruction.getDef();
        	 memberRef = ((JavaScriptPropertyRead)instruction).getMemberRef();
        	 rValNum = objectRef = ((JavaScriptPropertyRead)instruction).getObjectRef();
        	 
        	 //String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
        	 /* if it is sure that index is a integer value, generate the array facts
        	  * otherwise it is hard to determine, since the vNum corresponds to a string which is actually a parameter of a function but carries integer value
        	  * 
        	  */
        	 String arrayIndex = this.getVarName(ir, memberRef);
        	 if(arrayIndex!=null && isNumeric(arrayIndex)){
        	  	fact= "arrayLoad(v"+ lValNum+"_"+shortCurrentMethodName +",v"+ rValNum +"_"+shortCurrentMethodName+","+ memberRef+").\n";
               
           	  	bOut.write(fact);  
           	  	System.out.print(fact); 
        	 }
        	 
        	 else if ( this.isStringconstant(ir, instruction, memberRef)){
        		 
        		 field = arrayIndex;
        		 fact= "load(v"+ lValNum+"_"+shortCurrentMethodName +",v"+ rValNum +"_"+shortCurrentMethodName+","+field.toLowerCase()+").\n";
                 
            	 bOut.write(fact);  
            	 System.out.print(fact);
        	 }
        	 else{
        		 /* the string corrs. to vNum i.e memberRef is a variable (either local/global/parameter), 
        		  *the value of the variable can not be determined without doing a context+flow sensitive analysis
        		  */
        	 }
               
        	 
           }
           
           else if(instruction instanceof JavaScriptPropertyWrite){
          
        	 rValNum = ((JavaScriptPropertyWrite)instruction).getValue();
        	 memberRef = ((JavaScriptPropertyWrite)instruction).getMemberRef();
        	 lValNum = objectRef = ((JavaScriptPropertyWrite)instruction).getObjectRef();
        	 
        	 //String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
        	 /* if it is sure that index is a integer value, generate the array facts
        	  * otherwise it is hard to determine, since the vNum corresponds to a string which is actually a parameter of a function but carries integer value
        	  * 
        	  */
        	 String arrayIndex = this.getVarName(ir, memberRef);
        	 if(arrayIndex!=null && isNumeric(arrayIndex)){
        		 
        		 fact= "store(v"+ lValNum+"_"+shortCurrentMethodName +","+ memberRef+",v"+ rValNum +"_"+shortCurrentMethodName+").\n";
            	 bOut.write(fact);  
            	 System.out.print(fact);
        		  
        	 }
        	 
        	 else if ( this.isStringconstant(ir, instruction, memberRef)){
        		 
        		 field = arrayIndex;
        		 fact= "store(v"+ lValNum+"_"+shortCurrentMethodName +","+field.toLowerCase()+",v"+ rValNum +"_"+shortCurrentMethodName+").\n";
            	 bOut.write(fact);  
            	 System.out.print(fact);
        	 }
        	 else{
        		 /* the string corrs. to vNum i.e memberRef is a variable (either local/global/parameter), 
        		  *the value of the variable can not be determined without doing a context+flow sensitive analysis
        		  */
        	 }
           } 
           else if (instruction instanceof SSAPhiInstruction ){
          
        	 int paramIndex;
        	 //String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
        	 //String shortCurrentMethodName = currentMethodName.substring(currentMethodName.lastIndexOf("/")+1);
          
        	 lValNum = ((SSAPhiInstruction)instruction).getDef();
        	 String lValNumString = "v"+ lValNum +"_"+shortCurrentMethodName;
        	 String rValNumString = "";
        	 for( paramIndex = 0; paramIndex < instruction.getNumberOfUses(); paramIndex++){
            
        	   rValNum = instruction.getUse(paramIndex);
        	   rValNumString = "v"+ rValNum +"_"+shortCurrentMethodName;
        	   
        	   fact = "assign("+ lValNumString +","+ rValNumString+").\n";            	
        	   bOut.write(fact);  
        	   System.out.print(fact);
        	   
        	   // dump to PhiMap file
        	   
        	   phiMapOut.write(lValNumString +","+ rValNumString+"\n");
        	   
        	   
        	   
        	   if(vNumOfIdentifierInParentScope.containsKey(new Integer(rValNum))){
        		 String lVarName = vNumOfIdentifierInParentScope.get(new Integer(rValNum));  
        		 vNumOfIdentifierInParentScope.put(new Integer(lValNum), lVarName);
        		 fact= "formalLexicalWrite("+ currentMethodNode.methodHeapObject +","+
        		 							 lVarName+ ","+
											lValNumString +
											").\n";
        		 bOut.write(fact);  
        		 System.out.print(fact);
        	   }
        	   
        	 }
        	 /*
        	  * Take the name from 2nd argument of phi instruction, the 1st one in general corrs. to prototype one
        	  */
        	 String secondArgName = getVarName(ir, instruction.getUse(1));
        	 if(secondArgName == null)
        		 secondArgName = currentMethodNode.vNumToIdentifierMapping.get(new Integer(instruction.getUse(1)));
        	 currentMethodNode.vNumToIdentifierMapping.put(new Integer(lValNum), secondArgName);
        	 
           }
           
           else if(instruction instanceof SSABinaryOpInstruction){
        	
        	CheckBinaryOpInstruction cObj= new  CheckBinaryOpInstruction((SSABinaryOpInstruction) instruction);   
        	   
        	if( cObj.isAddOperator() && !((SSABinaryOpInstruction)instruction).mayBeIntegerOp()){  
        	  String operand1 = this.getVarName(ir, instruction.getUse(0));
        	  String operand2 = this.getVarName(ir, instruction.getUse(1));
           	  
        	  
           	  if((operand1 != null && !isNumeric(operand1))
           	     || (operand2 != null && !isNumeric(operand2))){
           		
           		//concatanates string
           	  }
        	}
           	//check if any of the arg has a string val
           	
           	
           	
           }
           else if (instruction instanceof JavaScriptInvoke ){
   		     
        	 String heapObjectName, vNumString;  
        	 
        	 
        	 int instructionIndex = this.getInstructionIndex(ir, instruction);
        	 AstMethod method =  (AstMethod) ir.getMethod();
        	   
        	 int lineNum = method.getLineNumber(instructionIndex);
        	   
        	 System.out.println("******************"+lineNum);
        	 
        	 
        	  //haila
        	 //String shortCurrentMethodName = currentMethodName.substring(currentMethodName.lastIndexOf("/")+1);
        	 //String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ; 
        	 boolean isConstruct =  ((JavaScriptInvoke)instruction).getDeclaredTarget().equals(JavaScriptMethods.ctorReference);
   		     
        	 
   		  	 if(isConstruct){
   			   /*
   			    * Construct either Object, function object or any other type of object  
   			    */
   		  	   String constructorName = getVarName(ir, ((JavaScriptInvoke)instruction).getFunction());
   		  	   
   		  	   
   		  	   if(constructorName != null){ 
   			
	   		  	   if(constructorName.equalsIgnoreCase("Object")){
	   			  
	   		  		 String objectName = this.getVarName(ir,instruction.getDef());
	   		  		 String tempName ="";
	   		  		 String objectNum = new Integer(instruction.getDef()).toString();
	   		  		 
	   		  		 if(objectName == null){
	   		  		   objectName = objectNum;
	   		  		 }  
	   		  		 else{
	   		  		   tempName	= objectName; 
	   		  		   objectName = objectName + "_"+objectNum;
	   		  		 }
	   			      
	   			     for (int j=1; j<= currentMethodNode.invocationCount ;j++){
	 	     		    
		       			heapObjectName = "h_obj_" + j+"_"+objectName +"_"+shortCurrentMethodName+"_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
	   			        vNumString = "v"+ instruction.getDef()+"_"+shortCurrentMethodName; 
		       			//store this info in the methodNode
		       			this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, tempName, vNumString, heapObjectName);
		       			
		       			
		   			    fact = "ptsTo(" + vNumString +","+ heapObjectName+").\n"; 
		   			    System.out.println(fact);
		   			    bOut.write(fact);
		   			     
		   			    if(this.privilegedObjectsContain(tempName)){
		   			    	
				  			 fact = "isPrivileged("+ heapObjectName + ").\n";
				  			 System.out.println(fact);
			   			     bOut.write(fact);		  
			   			     
			   			    fact = "idIsPrivileged(" 
	   			    			+ vNumString + ","
	   			    			+ "chrome"
	   			    			+ ").\n";
	 
			   			    System.out.println(fact);
			   			    bOut.write(fact);
				  		 }
	   			     
	   			     }
	   			     
	   			  
	   			     
	   		  	   }
	   		  	   else if (constructorName.equalsIgnoreCase("Function")){
	   				   			     			  
	   		  		 String constructorMethodFullName, constructorMethodName;
	   		  		 MethodNodeData callerNode; 
	   			  
	   		  		 callerNode = this.getNodeFromMethodName(currentMethodName);
	   			  
	   		  		 /*
	   		  		  * Get call site
	   		  		  */
	 			  
	   		  		 callSite = ((JavaScriptInvoke)instruction).getCallSite();
	   		  		 Set<CGNode> targets = callGraph.getPossibleTargets(callGraph.getNode(callerNode.nodeID), callSite);
	 			  
	   		  		 Iterator<CGNode> targetsIterator = targets.iterator() ;
	 			 
	   		  		 while(targetsIterator.hasNext()){
	 				 
	   		  		   CGNode target =  targetsIterator.next();
	   		  		   /*
	   		  		    * signature always start with ctor node in this case
	   		  		    */
	   		  		   
	   		  		   String constructorSignature = target.getMethod().toString();
	   		  		   constructorMethodFullName = constructorSignature.substring(constructorSignature.lastIndexOf("(")+1, constructorSignature.lastIndexOf(")")); 
	   		  		   
	   		  		   MethodNodeData constructorNode = this.getNodeFromMethodName(constructorMethodFullName);
	   		  		   /*
	   		  		    * constructor node null means the function is constructed but is never called,  so need to be modeled
	   		  		    */
	   		  		   if(constructorNode != null){
	   		  		   //haila
	   		  		   //constructorMethodName = constructorMethodFullName.substring(constructorMethodFullName.lastIndexOf("/")+1);
	   		  		     constructorMethodName = this.getMethodShortName(constructorNode); 
	   		  		   
	   		  		   /*
	   		  		    * TODO: This loop should be removed from here. This was probably written to facilitate context-sensitivity. 
	   		  		    *      i.e. to create separate heap object for for different invocation. But the fact produced here does not have to to do anything with context-sensivity.
	   		  		    *      Because, function definition/declaration is done once; there will be one statement for function object construction and that time the invocation count is not known
	   		  		    *      . Heap object creation in Context-sensitivity has to be taken care of in a different way. 
	   		  		    */
	   		  		    
	   		  		      for (int j=1; j<= currentMethodNode.invocationCount ;j++){
		   	     		    
		       			    heapObjectName = "h_func_" + j + "_"+constructorMethodName+"_"+shortCurrentMethodName + "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
		       			    //constructorNode;
		       			    String prototypeObjectName = "p_func_" + j + "_"+constructorMethodName+"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
		   		  		    vNumString = "v"+ instruction.getDef()+"_"+shortCurrentMethodName; 
		       			    
		       			    this.storeMethodParentAndHeapObjectMapping( constructorNode.nodeID, heapObjectName, prototypeObjectName, currentMethodNode.nodeID);
		       			    this.storeIdentifierToHeapMapping( currentMethodNode.nodeID, constructorMethodName, vNumString, heapObjectName);
		       			    
		       			    fact = "ptsTo("+ vNumString +","+ heapObjectName +").\n";	
		   		  		    System.out.println(fact);
		   		  		    bOut.write(fact);
		 	 			 
		   		  		    fact = "heapPtsTo("+ heapObjectName +", prototype, "+prototypeObjectName+ ").\n";  
		   		  		    System.out.println(fact);
		   		  		    bOut.write(fact);
	   		  		   
		 	  			 /*
		 	  			  * check whether the constructorMethod was invoked at any point in the code
		 	  			  * otherwise there is no point of spitting out facts for its parameter and return value
		 	  			  */
		 	  			    String paramName;
		 	  			    
		 	  			    if( constructorNode != null){
		 	  			      for (int paramIndex = 1; paramIndex< constructorNode.noOfParameters; paramIndex++){
		 	  			    	
		 	  			    	vNumString = "v"+(paramIndex+1)+"_"+ constructorMethodName;
		 	  			    	if(paramIndex > 1){
		 	  			    	  /*
		 	  			    	   * real parameters start from index 3 i.e. v3 for non-main method
		 	  			    	   * Assumption: paramName will never be null	
		 	  			    	   */
		 	  			    		
		 	  			    	   paramName = this.getVarName( callGraph.getNode(constructorNode.nodeID).getIR(), paramIndex+1);
		 	  			        
		 	  			    	   this.storeIdentifierToHeapMapping(constructorNode.nodeID, paramName, vNumString, "paramNull");
		 	  			    	}
		 	  			        
		 	    	   	        fact = "formal("+ heapObjectName+ ","+ paramIndex +","+ vNumString + ").\n";  
		 	    	   	        System.out.println(fact);
		 	  			        bOut.write(fact);
		 	  			      }
		 	  			  
		 	  			      for(int returnIndex=0; returnIndex< constructorNode.returnVNums.size(); returnIndex++){
		 	  				  
		 	      	   	        fact = "methodRet("+ heapObjectName +",v"+ constructorNode.returnVNums.get(returnIndex)+"_"+constructorMethodName  + ").\n";  	
		 	      	   	        System.out.println(fact);
		 	    			    bOut.write(fact);  
		 	  			  
		 	  			      }	 
		 	  			   }
	   		  		     } 	 
	   		  		  }  
	 	  			 
	 			  }
	   			  
	   			  
	   		   }
	   		   else if (constructorName.equalsIgnoreCase("String")){
	   			   
	   			 String stringObjectName = this.getVarName(ir, instruction.getDef());
	   			 String stringObjectNum = new Integer(instruction.getDef()).toString();
	     		 if(stringObjectName == null){
	     			 stringObjectName = stringObjectNum;
	     		 }
	     		 else
	     		   stringObjectName = stringObjectName +"_"+ stringObjectNum;
	     		
	     		 vNumString = "v"+ instruction.getDef()+"_"+shortCurrentMethodName;
	     		 for (int j=1; j<= currentMethodNode.invocationCount ;j++){
	     		    
	     			 heapObjectName = "h_str_" + j +"_"+ instruction.getDef() +"_"+stringObjectName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;    
	     		     this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, stringObjectName, vNumString, heapObjectName);
	     			 
	     			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n"; 
	     		     System.out.println(fact);
	     		     bOut.write(fact);
	     		  }
	   		   }
	   		  	   
	   			else if (constructorName.equalsIgnoreCase("Boolean")){
	   			  
	   			  String booleanObjectName = this.getVarName(ir,instruction.getDef());
	   			  String booleanObjectNum = new Integer(instruction.getDef()).toString(); 
	   			  if(booleanObjectName == null){
	   				booleanObjectName = booleanObjectNum; 
	   			  }
	   			  else
	   				booleanObjectName = booleanObjectName +"_"+ booleanObjectNum;  
	   			  
	   			  vNumString = "v"+ instruction.getDef()+"_"+shortCurrentMethodName;
	   			  for (int j=1; j<= currentMethodNode.invocationCount ;j++){
	     		      			     
	    			 heapObjectName = "h_boolean_" + j +"_"+ instruction.getDef() +"_"+booleanObjectName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
	    			 this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, booleanObjectName, vNumString, heapObjectName);
	    			 
	    		     fact = "ptsTo("+ vNumString +"_"+shortCurrentMethodName+","+ heapObjectName+").\n"; 
	    		     System.out.println(fact);
	    		     bOut.write(fact);
	    		   }
	   			}
	   		  	   
	   			else if (constructorName.equalsIgnoreCase("Date")){
	     		  String dateObjectName = this.getVarName(ir, instruction.getDef());
	     		  String dateObjectNum = new Integer(instruction.getDef()).toString();
	     		  if(dateObjectName == null){
	     			 dateObjectName = dateObjectNum; 
	     		  }
	     		  else   
	     			  dateObjectName = dateObjectName +"_"+ dateObjectNum;
	     		  
	     		  vNumString = "v"+ instruction.getDef()+"_"+shortCurrentMethodName;
	   			  
	     		  for(int j=1; j<= currentMethodNode.invocationCount ;j++){
	     		         
	  			     heapObjectName = "h_date_" + j +"_"+ instruction.getDef() +"_"+dateObjectName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
	  			     this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, dateObjectName, vNumString, heapObjectName);
	  			     
	  			     fact = "ptsTo(v"+ instruction.getDef()+"_"+shortCurrentMethodName+","+ heapObjectName+").\n"; 
		   		     System.out.println(fact);
		   		     bOut.write(fact);
	   			  }
	     		  
	     		}
	   		  	   
	   			else if (constructorName.equalsIgnoreCase("Error")){
	   				/*
	   				 * Do not process "new Error" statement
	   				 */
	   			}
	     			   			
	   			else{
	   
	   				/*
	   				 * Construct an object of a type that has been already declared
	   				 * @TODO : figure out object constructor name
	   				 */
	   			    String objectConstructorSignature;
	   				String constructorMethodFullName, constructorMethodName;
	     			MethodNodeData callerNode; 
	     			  
	     			callerNode = this.getNodeFromMethodName(currentMethodName);
	     			  
	     			/*
	   			     * Get call site
	   			     */
	   			  
	   			    callSite = ((JavaScriptInvoke)instruction).getCallSite();
	   			    Set<CGNode> targets = callGraph.getPossibleTargets(callGraph.getNode(callerNode.nodeID), callSite);
	   			  
	   			    Iterator<CGNode> targetsIterator = targets.iterator() ;
	   			 
	   			    while(targetsIterator.hasNext()){
	   				 
	   				  CGNode target =  targetsIterator.next();
	   				  objectConstructorSignature = target.getMethod().toString();
	   				  constructorMethodFullName = objectConstructorSignature.substring(objectConstructorSignature.indexOf(",")+1, objectConstructorSignature.indexOf(">"));
	   				  MethodNodeData constructorNode = this.getNodeFromMethodName(constructorMethodFullName);
	   				   
	   				  /*
	   				   * the body of this target has to be processed 
	   				   */
	   				  this.incrementNodeInvocationCount(constructorNode.nodeID);
	   				  //constructorNode.invocationCount++;
	   				   
	   				  //haila
	   				  //constructorMethodName = constructorMethodFullName.substring(constructorMethodFullName.lastIndexOf("/")+1);
	   				  constructorMethodName = this.getMethodShortName(constructorNode);
	   				  vNumString = "v"+ instruction.getDef()+"_"+shortCurrentMethodName;
	   				
		   			  for (int j=1; j<= currentMethodNode.invocationCount ;j++){
		   	     		    
		       			heapObjectName = "h_obj_" + j+"_"+ constructorMethodName+"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
		       			
		       			this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, constructorMethodName, vNumString, heapObjectName);
		       			
		       			fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
		   	   			System.out.println(fact);
		   	 			bOut.write(fact);
		   	 			
		   	 			
		   	 			/*
		   	 			 * dump Prototype Fact over here, instead of inferring it through datalog rule
		   	 			 */
		   	 			
			   	 		fact = "prototypeOf("+ heapObjectName + ","+ constructorNode.prototypeHeapObject+").\n";	
		   	   			System.out.println(fact);
		   	 			bOut.write(fact);
		   	 			
		   	 			
		   	 			   
		   			  } 
	   				   
	   	 			  global_i++;
	   	 			  callSiteID = "i" + new Integer(global_i).toString() ;
	   	 			   
	   	 			  /*
	   	 			   * Setting the callee function name
	   	 			   */
	   	 			  
	   	   	   	   	   fact = "actual("+ callSiteID + ","+0+",v"+ instruction.getUse(0)+ "_" +shortCurrentMethodName +").\n";
	   	   	   		   System.out.println(fact);
	   	   	 		   bOut.write(fact);
	   	 		       
	   	   	 		  
	   	   	 		   
	   	   	 	      /*
	   	 			   * Setting the 'this' parameter of the function
	   	 			   */
	   	 			  fact = "actual("+ callSiteID + ","+1+",v"+ instruction.getDef()+ "_" + shortCurrentMethodName +").\n";
	   	  	   		  System.out.println(fact);
	   	  	 		  bOut.write(fact);
	   	  	 		  
	   	  	 		  
	   	  	 		  /*
	     			   * Setting parameters of the invoked function, param start from index v2, v1 set to this
	     			   */
	   	  	 		  int paramCount = ((JavaScriptInvoke)instruction).getNumberOfParameters();
	     			  for (int paramIndex = 1; paramIndex< paramCount; paramIndex++){
	     				fact = "actual("+ callSiteID+ ","+ (paramIndex+1) +",v"+ instruction.getUse(paramIndex) +"_"+shortCurrentMethodName+").\n";  
	   	   	   	    	System.out.println(fact);
	   	 			    bOut.write(fact);
	   	 			  }
	     			  
	     			   /*
	     			    * ((JavaScriptInvoke)instruction).getNumberOfUses() returns the number of both params and lexicalRead
	     			    */
	     			   int useCount = ((JavaScriptInvoke)instruction).getNumberOfUses();
	     			   /*
	     			    * lexicalReadIndex is set to paramCount because the way getLexicalUse handles the array index  
	     			    */
	     			   for (int lexicalReadIndex = paramCount; lexicalReadIndex< useCount; lexicalReadIndex++){
	     				 
	     			     String rVarName = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableName;
	     			     variableDefiner = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableDefiner;
	     			     
	             	     if(!this.isKeyWord(rVarName)){
	             		   lValNum = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).valueNumber;
	             		   fact = "actualLexicalRead("+ callSiteID+ ","+
	             		   							 ",v"+ lValNum +"_"+shortCurrentMethodName+","+
	             		   							  this.makeDatalogCompatibleString(rVarName) +").\n";  
	   		 
	             		   System.out.println(fact);
	             		   bOut.write(fact);          
	             	     }
	     			     
	     			   }
	     			   
	//////////////////////////////////////////////////////////////////////////
	     			   
	     			   /*
	     			    * Setting return values of the invoked function
	     			    */
	     			   int returnCount = ((JavaScriptInvoke)instruction).getNumberOfReturnValues();
	     			   for (int returnIndex = 0; returnIndex< returnCount; returnIndex++){
	     				 fact = "callRet("+ callSiteID+ ","+ returnIndex +",v"+ instruction.getDef(returnIndex) +"_"+shortCurrentMethodName+").\n";  
	       	   	         System.out.println(fact);
	     			     bOut.write(fact);
	     			   }
	
	     			   
	     			   /*
	     			    * ((JavaScriptInvoke)instruction).getNumberOfDefs() returns the number of returns, exceptions and lexicalwrites
	     			    * the index is adjusted appropriately in getLexicalDef()
	     			    * return+1 for skipping the exception vNum
	     			    */
	     			   int defCount = ((JavaScriptInvoke)instruction).getNumberOfDefs();
		 				   instruction.getDef();
	
	     			   for (int lexicalWriteIndex = returnCount+1; lexicalWriteIndex< defCount; lexicalWriteIndex++){
	     				 
	      			     if(((JavaScriptInvoke)instruction).isLexicalDef(lexicalWriteIndex)){
	      			    	 
	      				    String lVarName = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableName;
	      	  			    variableDefiner = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableDefiner;
	      	  			    
	      	  			    rValNum = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).valueNumber;
	      	          		fact = "actualLexicalWrite("+ callSiteID+ ","
	      	          									+ this.makeDatalogCompatibleString(lVarName) 
	      	          		   							+ ",v"+ rValNum +"_"+shortCurrentMethodName+","
	      	          		   							+").\n";  
	      			 
	      	          		System.out.println(fact);
	      	          		bOut.write(fact);          
	      	          	     
	      			     }
	      			   }
	     			   
	      			      			   
	     			  /*
	     			   * setting the return value
	     			   */
	     			  fact = "callRet("+ callSiteID+ ",v"+ instruction.getDef()+"_"+ shortCurrentMethodName +").\n";
	     	   		  System.out.println(fact);
	     	 		  bOut.write(fact);
	
	   	  	 		   
	   	 			   
	   			    }// end of while loop
	   				
	 			   
	   			}// end of else
	   			
	   		  }  //end of if constructorNmae
   		  	   
   		  	   else{
   		  		   // construcotrName is null. so the assumption is function is used as a constructor, but the consructor name is null, example var a = new exports.foo();
   		  		   
   		  			String objectConstructorSignature;
	   				String constructorMethodFullName, constructorMethodName;
	     			MethodNodeData callerNode; 
	     			  
	     			callerNode = this.getNodeFromMethodName(currentMethodName);
	     			  
	     			/*
	   			     * Get call site
	   			     */
	   			  
	   			    callSite = ((JavaScriptInvoke)instruction).getCallSite();
	   			    Set<CGNode> targets = callGraph.getPossibleTargets(callGraph.getNode(callerNode.nodeID), callSite);
	   			  
	   			    Iterator<CGNode> targetsIterator = targets.iterator() ;
	   			 
	   			    while(targetsIterator.hasNext()){
	   				 
	   				  CGNode target =  targetsIterator.next();
	   				  objectConstructorSignature = target.getMethod().toString();
	   				  constructorMethodFullName = objectConstructorSignature.substring(objectConstructorSignature.indexOf(",")+1, objectConstructorSignature.indexOf(">"));
	   				  MethodNodeData constructorNode = this.getNodeFromMethodName(constructorMethodFullName);
	   				   
	   				  /*
	   				   * the body of this target has to be processed 
	   				   */
	   				  this.incrementNodeInvocationCount(constructorNode.nodeID);
	   				  //constructorNode.invocationCount++;
	   				   
	   				  //haila
	   				  //constructorMethodName = constructorMethodFullName.substring(constructorMethodFullName.lastIndexOf("/")+1);
	   				  constructorMethodName = this.getMethodShortName(constructorNode);
	   				  vNumString = "v"+ instruction.getDef()+"_"+shortCurrentMethodName;
	   				
		   			  for (int j=1; j<= currentMethodNode.invocationCount ;j++){
		   	     		    
		       			heapObjectName = "h_obj_" + j+"_"+ constructorMethodName+"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
		       			
		       			this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, constructorMethodName, vNumString, heapObjectName);
		       			
		       			fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
		   	   			System.out.println(fact);
		   	 			bOut.write(fact);
		   	 			
		   	 			
		   	 			/*
		   	 			 * dump Prototype Fact over here, instead of inferring it through datalog rule
		   	 			 */
		   	 			
			   	 		fact = "prototypeOf("+ heapObjectName + ","+ constructorNode.prototypeHeapObject+").\n";	
		   	   			System.out.println(fact);
		   	 			bOut.write(fact);
		   	 			
		   	 			
		   	 			   
		   			  } 
	   				   
	   	 			  global_i++;
	   	 			  callSiteID = "i" + new Integer(global_i).toString() ;
	   	 			   
	   	 			  /*
	   	 			   * Setting the callee function name
	   	 			   */
	   	 			  
	   	   	   	   	   fact = "actual("+ callSiteID + ","+0+",v"+ instruction.getUse(0)+ "_" +shortCurrentMethodName +").\n";
	   	   	   		   System.out.println(fact);
	   	   	 		   bOut.write(fact);
	   	 		       
	   	   	 		  
	   	   	 		   
	   	   	 	      /*
	   	 			   * Setting the 'this' parameter of the function
	   	 			   */
	   	 			  fact = "actual("+ callSiteID + ","+1+",v"+ instruction.getDef()+ "_" + shortCurrentMethodName +").\n";
	   	  	   		  System.out.println(fact);
	   	  	 		  bOut.write(fact);
	   	  	 		  
	   	  	 		  
	   	  	 		  /*
	     			   * Setting parameters of the invoked function, param start from index v2, v1 set to this
	     			   */
	   	  	 		  int paramCount = ((JavaScriptInvoke)instruction).getNumberOfParameters();
	     			  for (int paramIndex = 1; paramIndex< paramCount; paramIndex++){
	     				fact = "actual("+ callSiteID+ ","+ (paramIndex+1) +",v"+ instruction.getUse(paramIndex) +"_"+shortCurrentMethodName+").\n";  
	   	   	   	    	System.out.println(fact);
	   	 			    bOut.write(fact);
	   	 			  }
	     			  
	     			   /*
	     			    * ((JavaScriptInvoke)instruction).getNumberOfUses() returns the number of both params and lexicalRead
	     			    */
	     			   int useCount = ((JavaScriptInvoke)instruction).getNumberOfUses();
	     			   /*
	     			    * lexicalReadIndex is set to paramCount because the way getLexicalUse handles the array index  
	     			    */
	     			   for (int lexicalReadIndex = paramCount; lexicalReadIndex< useCount; lexicalReadIndex++){
	     				 
	     			     String rVarName = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableName;
	     			     variableDefiner = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableDefiner;
	     			     
	             	     if(!this.isKeyWord(rVarName)){
	             		   lValNum = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).valueNumber;
	             		   fact = "actualLexicalRead("+ callSiteID+ ","+
	             		   							 ",v"+ lValNum +"_"+shortCurrentMethodName+","+
	             		   							  this.makeDatalogCompatibleString(rVarName) +").\n";  
	   		 
	             		   System.out.println(fact);
	             		   bOut.write(fact);          
	             	     }
	     			     
	     			   }
	     			   
	//////////////////////////////////////////////////////////////////////////
	     			   
	     			   /*
	     			    * Setting return values of the invoked function
	     			    */
	     			   int returnCount = ((JavaScriptInvoke)instruction).getNumberOfReturnValues();
	     			   for (int returnIndex = 0; returnIndex< returnCount; returnIndex++){
	     				 fact = "callRet("+ callSiteID+ ","+ returnIndex +",v"+ instruction.getDef(returnIndex) +"_"+shortCurrentMethodName+").\n";  
	       	   	         System.out.println(fact);
	     			     bOut.write(fact);
	     			   }
	
	     			   
	     			   /*
	     			    * ((JavaScriptInvoke)instruction).getNumberOfDefs() returns the number of returns, exceptions and lexicalwrites
	     			    * the index is adjusted appropriately in getLexicalDef()
	     			    * return+1 for skipping the exception vNum
	     			    */
	     			   int defCount = ((JavaScriptInvoke)instruction).getNumberOfDefs();
		 				   instruction.getDef();
	
	     			   for (int lexicalWriteIndex = returnCount+1; lexicalWriteIndex< defCount; lexicalWriteIndex++){
	     				 
	      			     if(((JavaScriptInvoke)instruction).isLexicalDef(lexicalWriteIndex)){
	      			    	 
	      				    String lVarName = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableName;
	      	  			    variableDefiner = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableDefiner;
	      	  			    
	      	  			    rValNum = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).valueNumber;
	      	          		fact = "actualLexicalWrite("+ callSiteID+ ","
	      	          									+ this.makeDatalogCompatibleString(lVarName) 
	      	          		   							+ ",v"+ rValNum +"_"+shortCurrentMethodName+","
	      	          		   							+").\n";  
	      			 
	      	          		System.out.println(fact);
	      	          		bOut.write(fact);          
	      	          	     
	      			     }
	      			   }
	     			   
	      			      			   
	     			  /*
	     			   * setting the return value
	     			   */
	     			  fact = "callRet("+ callSiteID+ ",v"+ instruction.getDef()+"_"+ shortCurrentMethodName +").\n";
	     	   		  System.out.println(fact);
	     	 		  bOut.write(fact);
	
	   	  	 		   
	   	 			   
	   			    }// end of while loop
	   				
   		  		   
   		  	   }
	   	
   		  }	  // if construct/invoke 
   		  else{
   			  
   		    // process for special require function invocation
 				// process events
   			/*
   			 * Invoke instruction  
   			 */
   			String calleeMethodFullName, calleeMethodName;  
   			MethodNodeData callerNode;
			callerNode = this.getNodeFromMethodName(currentMethodName);
   			/*
 			 * Get call site
 			 */
 			  
 			callSite = ((JavaScriptInvoke)instruction).getCallSite();
 			Set<CGNode> targets = callGraph.getPossibleTargets(callGraph.getNode(callerNode.nodeID), callSite);
 			  
 			String invokedMethodName = getVarName(ir, instruction.getUse(0));
 		
 			 
 			/*
    		 * Handling "WALA assign" statement
    		 */
    	    if(invokedMethodName != null && invokedMethodName.equalsIgnoreCase("WALA_assign")){
    	    		
    	       String rVNumString = "v" + instruction.getUse(2)+ "_" + shortCurrentMethodName;
    	       String lVNumString = "v" + instruction.getDef()+ "_" + shortCurrentMethodName;
    	       
    	       String lVarName = getVarName(ir, instruction.getDef());
    	       this.createWALAAssignMapentry(currentMethodNode.nodeID, lVarName, lVNumString);
    	       System.out.println("WALA_Assign "+ rVNumString );
             			
    	       fact = "assign("+ lVNumString +","+ rVNumString+").\n";	
  	   	   	   System.out.println(fact);
  	   	   	   bOut.write(fact);
  	    	 
    	 	}

 			 
 			/*
 			 * Handling "require" statement
 			 */
    	 	else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("require")){
 	 		   String importedModule = getVarName(ir, instruction.getUse(2));
 	 		   System.out.println("REQUIRED "+ importedModule );
 	  		   importedModule = this.makeDatalogCompatibleString(importedModule);

 			   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                 
               for (int j=1; j<= currentMethodNode.invocationCount ;j++){
	      			     
       			 heapObjectName = "h_req_" + j +"_"+ instruction.getDef() +"_"+ importedModule +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
          			 
       			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
   	   			 System.out.println(fact);
   	   			 bOut.write(fact);
	   	 	
   	   			 String privilege;
          			 
 			     if(importedModule.equalsIgnoreCase("chrome")
 			        || importedModule.equalsIgnoreCase("text-stream")
 			        ||importedModule.equalsIgnoreCase("byte-stream")){
 	 			    
 			    	privilege = importedModule; 
 			    	fact = "isPrivileged(" 
 			    	              + heapObjectName + ","
 			    	              + privilege
 			    	              + ").\n";
 			       
 	 			    System.out.println(fact);
 	   			    bOut.write(fact);
 	   			    
 	   			    
 	   			    fact = "idIsPrivileged(" 
		    			+ vNumString + ","
		    			+ privilege
		    			+ ").\n";

 	   			    System.out.println(fact);
 	   			    bOut.write(fact);
			     
 	   			      
 			      }  
 			     
 			     
 			     
 			     
   			   
 			    
                } 	 
 	 		 }
 	 		 
 	 		/*
   			 * Handling "Cu.import" /Cuimport statement
   			 */
   	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("Cuimport")){
   	 			String jsmPath = getVarName( ir, instruction.getUse(2));
   	 			String jsmObject = getVarName( ir, instruction.getUse(3));
   	 				   
   	 			String jsmName = jsmPath.substring(jsmPath.lastIndexOf("/"), jsmPath.lastIndexOf('.')) ;	   
   	 			   
   	 			System.out.println("Cuimport"+ jsmName );
  	 			vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                jsmName = this.makeDatalogCompatibleString(jsmName);
                for (int j=1; j<= currentMethodNode.invocationCount ;j++){
  	      			     
                  heapObjectName = "h_file_" + j +"_"+ instruction.getUse(3) +"_"+ jsmName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
            		 
            	  fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
            	  System.out.println(fact);
            	  bOut.write(fact);
	   	 			 
            		 
            	  if(jsmPath.equalsIgnoreCase("resource://gre/modules/NetUtil.jsm")){

            		fact = "isPrivileged(" 
   	 			   	              + heapObjectName + ","
   	 			   	              + ""
   	 			   	              + ").\n";
   	 			      
   	   			      
            		System.out.println(fact);
            		bOut.write(fact);
            		
            		  fact = "idIsPrivileged(" 
  		    			+ vNumString + ","
  		    			+ ""
  		    			+ ").\n";

   	   			    System.out.println(fact);
   	   			    bOut.write(fact);
  			     
            		
            		
            	  }
                } 	 
   	 		 }
  			
 	 		 
 	 		/*
 			 * Handling "MozFile" statement
 			 */
 	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozFile")){
 	 			   String fileName = getVarName(ir, instruction.getUse(2));
 	 			   System.out.println("MozFile "+ fileName );
 	 			   fileName = this.makeDatalogCompatibleString(fileName);
 	 			   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                 
                   for (int j=1; j<= currentMethodNode.invocationCount ;j++){
	      			     
          			 heapObjectName = "h_file_" + j +"_"+ instruction.getDef() +"_"+ fileName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
          			 
          			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
	   	   			 System.out.println(fact);
	   	   			 bOut.write(fact);
	   	 			 
          			 
 	 			     fact = "isPrivileged(" 
 	 			    	              + heapObjectName + ","
 	 			    	              + "file"
 	 			    	              + ").\n";
 	 			      
 	   			      
 	 			     System.out.println(fact);
 	   			     bOut.write(fact);
 	   			     
 	   			     fact = "idIsPrivileged(" 
		    			+ vNumString + ","
		    			+ "file"
		    			+ ").\n";

	   			    System.out.println(fact);
	   			    bOut.write(fact);
			     
                  } 	 
 	 		 }
 	 		 
    	    /*
 			 * Handling "MozFileParent" statement
 			 */
 	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozFileParent")){
 	 			   String fileName = getVarName(ir, instruction.getUse(2));
 	 			   System.out.println("MozFileParent "+ fileName );
 	 			   fileName = this.makeDatalogCompatibleString(fileName);
 	 			   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                 
                   for (int j=1; j<= currentMethodNode.invocationCount ;j++){
	      			     
          			 heapObjectName = "h_file_" + j +"_"+ instruction.getDef() +"_"+ fileName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
          			 
          			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
	   	   			 System.out.println(fact);
	   	   			 bOut.write(fact);
	   	 			 
          			 
 	 			     fact = "isPrivileged(" 
 	 			    	              + heapObjectName + ","
 	 			    	              + "file"
 	 			    	              + ").\n";
 	 			      
 	   			      
 	 			     System.out.println(fact);
 	   			     bOut.write(fact);
 	   			     
	 	   			 fact = "idIsPrivileged(" 
			    			+ vNumString + ","
			    			+ "file"
			    			+ ").\n";
	
		   			    System.out.println(fact);
		   			    bOut.write(fact);
                  } 	 
 	 		 }
 	 		 
    	    
 	 		/*
  			 * Handling "MozFileInputStream" statement
  			 */
  	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozFileInputStream")){
  	 			   String fileName = "v" + instruction.getUse(2);
  	 			   /*if (fileName.contains("/"))
  	 				   fileName = fileName.replace('/', '_');*/
  	 			   System.out.println("MozFileInputStream "+ fileName );
  	 			   fileName = this.makeDatalogCompatibleString(fileName);
 	 			   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                  
                    for (int j=1; j<= currentMethodNode.invocationCount ;j++){
 	      			     
           			 heapObjectName = "h_file_" + j +"_"+ instruction.getDef() +"_"+ fileName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
           			
           			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
	   	   			 System.out.println(fact);
	   	   			 bOut.write(fact);
	   	 			 
  	 			     fact = "isPrivileged(" 
  	 			    	              + heapObjectName + ","
  	 			    	              + "fileInputStream"
  	 			    	              + ").\n";
  	 			      
  	   			      
  	 			     System.out.println(fact);
  	   			     bOut.write(fact);
  	   			     
	  	   			fact = "idIsPrivileged(" 
		    			+ vNumString + ","
		    			+ "fileInputStream"
		    			+ ").\n";
	
	   			    System.out.println(fact);
	   			    bOut.write(fact);
                   } 	 
  	 		 }
 			
 	 		/*
   			 * Handling "MozConverterInputStream" statement
   			 */
   	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozConverterInputStream")){
   	 			   String streamName = "v" + instruction.getUse(2);
   	 			   /*if (fileName.contains("/"))
   	 				   fileName = fileName.replace('/', '_');*/
   	 			   System.out.println("MozConverterInputStream "+ streamName );
   	 			   streamName = this.makeDatalogCompatibleString(streamName);
  	 			   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                   
                     for (int j=1; j<= currentMethodNode.invocationCount ;j++){
  	      			     
            			heapObjectName = "h_stream_" + j +"_"+ instruction.getDef() +"_"+ streamName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
            			
            			fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
 	   	   			 	System.out.println(fact);
 	   	   			 	bOut.write(fact);
 	   	 			 
 	   	   			 	fact = "isPrivileged(" 
   	 			    	              + heapObjectName + ","
   	 			    	              + "converterInputStream"
   	 			    	              + ").\n";
   	 			      
   	   			      
 	   	   			 	System.out.println(fact);
 	   	   			 	bOut.write(fact);
 	   	   			 	
	 	   	   			fact = "idIsPrivileged(" 
			    			+ vNumString + ","
			    			+ "converterInputStream"
			    			+ ").\n";
		
		   			    System.out.println(fact);
		   			    bOut.write(fact);
                    } 	 
   	 		 }
    	    
    	    /*
   			 * Handling "MozIOUtil" statement
   			 */
   	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozIOUtil")){
   	 			  
  	 			vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                   
                for (int j=1; j<= currentMethodNode.invocationCount ;j++){
  	      			     
                	heapObjectName = "h_ioutils_" + j +"_"+ instruction.getDef()+"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
            			
            		fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
 	   	   			System.out.println(fact);
 	   	   			bOut.write(fact);
 	   	 			 
 	   	   			fact = "isPrivileged(" 
   	 			    	              + heapObjectName + ","
   	 			    	              + "ioUtil"
   	 			    	              + ").\n";
   	 			      
   	   			      
 	   	   		 	System.out.println(fact);
 	   	   		 	bOut.write(fact);
                 } 	 
   	 		 }
    	    
    	    /*
   			 * Handling "MozBufferedOutputStream" statement
   			 */
   	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozBufferedOutputStream")){
   	 			   String streamName = "v" + instruction.getUse(3);
   	 			   /*if (fileName.contains("/"))
   	 				   fileName = fileName.replace('/', '_');*/
   	 			   System.out.println("MozBufferedOutputStream "+ streamName );
   	 			   streamName = this.makeDatalogCompatibleString(streamName);
  	 			   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                   
                     for (int j=1; j<= currentMethodNode.invocationCount ;j++){
  	      			     
            			heapObjectName = "h_stream_" + j +"_"+ instruction.getDef() +"_"+ streamName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
            			
            			fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
 	   	   			 	System.out.println(fact);
 	   	   			 	bOut.write(fact);
 	   	 			 
 	   	   			 	fact = "isPrivileged(" 
   	 			    	              + heapObjectName + ","
   	 			    	              + "bufferedOutputStream"
   	 			    	              + ").\n";
   	 			      
   	   			      
 	   	   			 	System.out.println(fact);
 	   	   			 	bOut.write(fact);
                    } 	 
   	 		 }
    	    
    	    /*
  			 * Handling "MozBinaryInputStream" statement
  			 */
  	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozBinaryInputStream")){
  	 			   String streamName = "v" + instruction.getUse(2);
  	 			
  	 			   System.out.println("MozBinaryInputStream "+ streamName );
  	 			   streamName = this.makeDatalogCompatibleString(streamName);
 	 			   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                  
                    for (int j=1; j<= currentMethodNode.invocationCount ;j++){
 	      			     
           			 heapObjectName = "h_binis_" + j +"_"+ instruction.getDef() +"_"+ streamName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
           			
           			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
	   	   			 System.out.println(fact);
	   	   			 bOut.write(fact);
	   	 			 
  	 			     fact = "isPrivileged(" 
  	 			    	              + heapObjectName + ","
  	 			    	              + "binaryInputStream"
  	 			    	              + ").\n";
  	 			      
  	   			      
  	 			     System.out.println(fact);
  	   			     bOut.write(fact);
                   } 	 
  	 		 }
 			
    	    /*
  			 * Handling "MozBinaryOutputStream" statement
  			 */
  	 		 else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("MozBinaryOutputStream")){
  	 			String streamName = "v" + instruction.getUse(2);
  	 	
  	 			System.out.println("MozBinaryOutputStream "+ streamName );
  	 			streamName = this.makeDatalogCompatibleString(streamName);
 	 			vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                  
                for (int j=1; j<= currentMethodNode.invocationCount ;j++){
 	      			     
           		  heapObjectName = "h_binos_" + j +"_"+ instruction.getDef() +"_"+ streamName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
           			
           		  fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
	   	   		  System.out.println(fact);
	   	   		  bOut.write(fact);
	   	 			 
  	 			  fact = "isPrivileged(" 
  	 			    	              + heapObjectName + ","
  	 			    	              + "binaryOutputStream"
  	 			    	              + ").\n";
  	 			      
  	   			      
  	 			   System.out.println(fact);
  	   			   bOut.write(fact);
                } 	 
  	 		 } 
    	    
    	    
  	 		 else if(invokedMethodName != null && invokedMethodName.equalsIgnoreCase("JetpackTextReader")){
  	 		   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
              
               for (int j=1; j<= currentMethodNode.invocationCount ;j++){
     			     
     			 heapObjectName = "h_jetpackTextReader_" + j +"_"+ instruction.getDef() +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
     			
     			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
 	   			 System.out.println(fact);
 	   			 bOut.write(fact);
 	 			 
 			     fact = "isPrivileged(" 
 			    	              + heapObjectName + ","
 			    	              + "jetpackTextReader"
 			    	              + ").\n";
 			      
   			      
 			     System.out.println(fact);
   			     bOut.write(fact);
               } 	 
  	 		 }
    	    
  	 		 else if(invokedMethodName != null && invokedMethodName.equalsIgnoreCase("JetpackTextWriter")){
   	 		   vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
               
               for (int j=1; j<= currentMethodNode.invocationCount ;j++){
      			     
      			 heapObjectName = "h_jetpackTextWriter_" + j +"_"+ instruction.getDef() +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
      			
      			 fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
  	   			 System.out.println(fact);
  	   			 bOut.write(fact);
  	 			 
  			     fact = "isPrivileged(" 
  			    	              + heapObjectName + ","
  			    	              + "jetpackTextWriter"
  			    	              + ").\n";
  			      
    			      
  			     System.out.println(fact);
    		     bOut.write(fact);
               } 	 
   	 		 }
    	    
  	 		 else if(invokedMethodName != null && invokedMethodName.equalsIgnoreCase("JetpackBinReader")){
    	 		vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                
                for (int j=1; j<= currentMethodNode.invocationCount ;j++){
       			     
       			  heapObjectName = "h_jetpackBinReader_" + j +"_"+ instruction.getDef() +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
       			
       			  fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
   	   			  System.out.println(fact);
   	   			  bOut.write(fact);
   	 			 
   	   			  fact = "isPrivileged(" 
   			    	              + heapObjectName + ","
   			    	              + "jetpackBinReader"
   			    	              + ").\n";
   			      
     			      
   	   			  System.out.println(fact);
   	   			  bOut.write(fact);
                } 	 
    	 	 }
      	    
    	 	 else if(invokedMethodName != null && invokedMethodName.equalsIgnoreCase("JetpackBinWriter")){
     	 		vNumString = "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
                 
                for (int j=1; j<= currentMethodNode.invocationCount ;j++){
        			     
        		  heapObjectName = "h_jetpackBinWriter_" + j +"_"+ instruction.getDef() +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
        			
        		  fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
        		  System.out.println(fact);
        		  bOut.write(fact);
    	 			 
    			  fact = "isPrivileged(" 
    			    	              + heapObjectName + ","
    			    	              + "jetpackBinWriter"
    			    	              + ").\n";
    			      
      			      
    			  System.out.println(fact);
      		      bOut.write(fact);
               } 	 
     	 	 }
    	    
 	 		 Iterator<CGNode> targetsIterator = targets.iterator() ;
 			 
 			 while(targetsIterator.hasNext()){
 			   CGNode target = targetsIterator.next();
 			   target.getGraphNodeId();
 			   calleeMethodFullName = target.getMethod().getDeclaringClass().getName().toString();
 			   
 			   if (    calleeMethodFullName.equalsIgnoreCase("Lprologue.js/max")
 					|| calleeMethodFullName.equalsIgnoreCase("Lprologue.js/min")   
 			       )
 				   continue;
 			   
 			   MethodNodeData calleeNode = this.getNodeFromMethodName(calleeMethodFullName);
 			   //haila
 			   //calleeMethodName = calleeMethodFullName.substring(calleeMethodFullName.lastIndexOf("/")+1);
 			   calleeMethodName = this.getMethodShortName(calleeNode);
 			   /*
 				* the body of this target has to be processed 
 				*/
 			   this.incrementNodeInvocationCount(target.getGraphNodeId());// can be also done here directly

 			   global_i++;
 			   callSiteID = "i" + new Integer(global_i).toString() ;
 			   
 			    
 			   /*
                * set the invoked function name  			
                */
 			  
  			   fact = "actual("+ callSiteID+ ","+0+",v"+ instruction.getUse(0)+ "_" + shortCurrentMethodName +").\n";
    	   	   System.out.println(fact);
    	 	   bOut.write(fact);
    	 		  
    	 	   /*
  			    * Setting parameters of the invoked function, param start from index 1
  			    */
    	 	   int paramCount = ((JavaScriptInvoke)instruction).getNumberOfParameters();
  			   for (int paramIndex = 1; paramIndex< paramCount; paramIndex++){
  				 fact = "actual("+ callSiteID+ ","+ paramIndex +",v"+ instruction.getUse(paramIndex) +"_"+shortCurrentMethodName+").\n";  
    	   	     System.out.println(fact);
  			     bOut.write(fact);
  			   }
  			   
  			   /*
  			    * ((JavaScriptInvoke)instruction).getNumberOfUses() returns the number of both params and lexicalRead
  			    */
  			   int useCount = ((JavaScriptInvoke)instruction).getNumberOfUses();
  			   /*
  			    * lexicalReadIndex is set to paramCount because the way getLexicalUse handles the array index  
  			    */
  			   for (int lexicalReadIndex = paramCount; lexicalReadIndex< useCount; lexicalReadIndex++){
  				 
  			     String rVarName = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableName;
  			     variableDefiner = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableDefiner;
  			     
          	     if(!this.isKeyWord(rVarName)){
          		   lValNum = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).valueNumber;
          		   fact = "actualLexicalRead("+ callSiteID+ ","+
          		   							 "v"+ lValNum +"_"+shortCurrentMethodName+","+
          		   							  this.makeDatalogCompatibleString(rVarName) +").\n";  
		 
          		   System.out.println(fact);
          		   bOut.write(fact);          
          	     }
  			     
  			   }
  			   
  			   /*
  			    * Setting return values of the invoked function
  			    */
    	 	   int returnCount = ((JavaScriptInvoke)instruction).getNumberOfReturnValues();
  			   for (int returnIndex = 0; returnIndex< returnCount; returnIndex++){
  				 fact = "callRet("+ callSiteID+ ","+ returnIndex +",v"+ instruction.getDef(returnIndex) +"_"+shortCurrentMethodName+").\n";  
    	   	     System.out.println(fact);
  			     bOut.write(fact);
  			   }

  			   
  			   /*
  			    * ((JavaScriptInvoke)instruction).getNumberOfDefs() returns the number of returns, exceptions and lexicalwrites
  			    * the index is adjusted appropriately in getLexicalDef()
  			    * return+1 for skipping the exception vNum
  			    */
  			   int defCount = ((JavaScriptInvoke)instruction).getNumberOfDefs();
  			   
  			   for (int lexicalWriteIndex = returnCount+1; lexicalWriteIndex< defCount; lexicalWriteIndex++){
  				 
   			     if(((JavaScriptInvoke)instruction).isLexicalDef(lexicalWriteIndex)){
   			    	 
   				    String lVarName = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableName;
   	  			    variableDefiner = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableDefiner;
   	  			    
   	  			    rValNum = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).valueNumber;
   	          		fact = "actualLexicalWrite("+ callSiteID+ ","
   	          									+ this.makeDatalogCompatibleString(lVarName) 
   	          		   							+ ",v"+ rValNum +"_"+shortCurrentMethodName
   	          		   							+").\n";  
   			 
   	          		System.out.println(fact);
   	          		bOut.write(fact);          
   	          	     
   			     }
   			   }
  			   
   			      			   
  			  /*
  			   * setting the return value
  			   */
  			  fact = "callRet("+ callSiteID+ ",v"+ instruction.getDef()+"_"+ shortCurrentMethodName +").\n";
  	   		  System.out.println(fact);
  	 		  bOut.write(fact);
 			   
 			}// end of while
              
 	   			
   		  }//end of else
   		  
   	    }// end of invoke instruction
        else if (instruction instanceof SSAReturnInstruction ){
          
          if(currentMethodName.equalsIgnoreCase("")){
        	  rValNum = instruction.getUse(0);
        	  fact = "MethodRet(v"+ rValNum + ").\n";
        	  bOut.write(fact);  
              System.out.println(fact);
          }
        	
        /*  if(currentMethodName.equalsIgnoreCase(""))
            fact = "MethodRet(v"+ lValNum +",v"+ rValNum +")";
          else
            fact = "MethodRet(v"+ lValNum +"_"+currentMethodName+",v"+ rValNum +"_"+currentMethodName+")";
               	
            bOut.write(fact);  
            System.out.println(fact);
            */
  	    }
      
           
                 
      }// end of one block
      vNumOfIdentifierInParentScope.clear(); 
    }//end of one method node
     bOut.write("\n\n");
    }
    //Close the output stream
    String rules = this.getDatalogRules();
    bOut.write(rules);
    bOut.close();
	exportOut.close();
	phiMapOut.close();
  }
  

  private int getInstructionIndex(IR ir, SSAInstruction instruction) {
	
	SSAInstruction ssair[] = ir.getInstructions();
	
	for(int i=0; i< ssair.length;i++){
		
		if(ssair[i] == instruction)
			return i;
	}
		
	  
	  
	return 0;
}

private void createWALAAssignMapentry(int nodeID, String lVarName, String lValNumString) {
	int i;
	MethodNodeData node;
	for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
	  node = this.codeBodyNodesInCG.get(i);
	  if(node.nodeID == nodeID){
		node.WALAAssignIdToVNumMapping.put(lVarName, lValNumString);
		this.codeBodyNodesInCG.set(i, node);
		return;
	  }
	}
	
 }

 private void createMapEntryInDefinerNode(int nodeID, String lVarName, String rValNumString) {
	int i;
	MethodNodeData node;
	for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
	  node = this.codeBodyNodesInCG.get(i);
	  if(node.nodeID == nodeID){
		node.identifierToHeapMapping.put(lVarName,  Pair.make(rValNumString,"heap_var"));
		this.codeBodyNodesInCG.set(i, node);
		return;
	  }
    }
  }

  private void removeMapEntryInCurrentMethodNode(int nodeID, String lVarName) {
	int i;
	MethodNodeData node;
	for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
	  node = this.codeBodyNodesInCG.get(i);
	  if(node.nodeID == nodeID){
		node.identifierToHeapMapping.remove(lVarName);
		this.codeBodyNodesInCG.set(i, node);
		return;
	  }
	} 
  }

  private void storeIdentifierToHeapMapping( int nodeID, String objectName, String vNumString, String heapObjectName) {
	
	int i;
	MethodNodeData node;
	for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
		node = this.codeBodyNodesInCG.get(i);
		if(node.nodeID == nodeID){
			node.identifierToHeapMapping.put(objectName,  Pair.make(vNumString,heapObjectName));
			this.codeBodyNodesInCG.set(i, node);
			return;
		}
	 }
   }

  private boolean isKeyWord(String rVarName) {
	
	if(rVarName.equals("undefined"))
	  return true;
	else if (rVarName.equals("Function"))
	  return true;
	else if(rVarName.equals("String"))
	  return true;
	else if (rVarName.equals("Object"))
	  return true;	
	else if(rVarName.equals("Date"))
	  return true;
	else if (rVarName.equals("Number"))
	  return true;
	else if (rVarName.equals("Boolean"))
	  return true;
	else if (rVarName.equals("Error"))
	  return true;
	// keyword defined for the analysis
	else if (rVarName.equals("WALA_assign"))
	  return true;
	else if(rVarName.equals("require"))
	  return true;
	else if(rVarName.equals("Cuimport"))
	  return true;	
	else if (rVarName.equals("MozFile"))
	  return true;	
	else if(rVarName.equals("MozFileInputStream"))
	  return true;
	else if (rVarName.equals("MozConverterInputStream"))
	  return true;
		
	else	  
	  return false;
  }

  private void storeMethodParentAndHeapObjectMapping(int nodeID, String heapObjectName, String prototypeObjectName, int parentNodeID) {
	  
	int i;
	MethodNodeData node;
	for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
		node = this.codeBodyNodesInCG.get(i);
		if(nodeID == node.nodeID){
			node.parentNodeID = parentNodeID;
			node.methodHeapObject = heapObjectName;
			node.prototypeHeapObject =  prototypeObjectName;
			this.codeBodyNodesInCG.set(i, node);
			return;
		}
	}
  }

  private boolean isStringconstant(IR ir, SSAInstruction instruction, int vNum) {
	
	  SymbolTable symTable = ir.getSymbolTable();
	
	  if(symTable.isConstant(vNum)) {
    	 final Object value = symTable.getConstantValue(vNum);
    	 return !isNumeric(value.toString());
    	 
	  }
	return false;
  }

  private boolean privilegedObjectsContain(String objectName) {
  	if(objectName.equalsIgnoreCase("browser"))
  		return true;
  	return false;
  }
  
  private String getDatalogRules(){
	  /*
	   * We may not need separate rules for array, they are in fact same as object access,
	   * unless accessing an element of a tainted array results in a tainted element. check this 
	   */
	  String rules = "% rules %\n"+
                     " ptsTo(V1,H) :- \n"+ 
                     "      ptsTo(V2, H),\n"+ 
                     "      assign(V1, V2).\n"+
                      "\n \n"+
                      
                      "heapPtsTo(H1, F, H2) :-\n"+
                      "    store(V1, F, V2),\n"+ 
                      "    ptsTo(V1, H1),\n"+
                      "    ptsTo(V2, H2).\n"+
                      "\n \n"+
                      
                      "ptsTo(V2,H2) :-\n"+
                      "    load(V2, V1, F),\n"+ 
                      "    ptsTo(V1, H1),\n"+ 
                      "    heapPtsTo(H1, F, H2).\n"+
                      "\n \n"+
                      
                      "isTainted(H1, P) :-\n"+
                      "    heapPtsTo(H1, F, H2),\n"+ 
                      "    isPrivileged(H2, P).\n"+
                      "\n \n"+
                      
                      "isTainted(H1, P) :-\n"+
                      "    heapPtsTo(H1, F, H2),\n"+
                      "    isTainted(H2, P).\n"+
                      "\n \n"+
                      
                      "arrayHeapPtsTo(H1, F, H2) :-\n"+
                      "    arrayStore(V1, F, V2),\n"+ 
                      "    ptsTo(V1, H1),\n"+
                      "    ptsTo(V2, H2).\n"+
                      "\n \n"+
                      
                      "ptsTo(V2,H2) :-\n"+
                      "    arrayLoad(V2, V1, F),\n"+ 
                      "    ptsTo(V1, H1),\n"+ 
                      "    arrayHeapPtsTo(H1, F, H2).\n"+
                      "\n \n"+
                      
                      "isTainted(H1, P) :-\n"+
                      "    arrayHeapPtsTo(H1, F, H2),\n"+ 
                      "    isPrivileged(H2, P).\n"+
                      "\n \n"+
                      
                      "isTainted(H1, P) :-\n"+
                      "    arrayHeapPtsTo(H1, F, H2),\n"+
                      "    isTainted(H2, P).\n"+
                      "\n \n"+
                      
                      "idIsTainted(V, P) :-\n"+
                      "    ptsTo(V, H),\n"+
                      "    isPrivileged(H, P),\n"+
                      "    not(idIsPrivileged(V,P)).\n"+
                      "\n \n"+
                      
                      "idIsTainted(V, P) :-\n"+
                      "	    ptsTo(V, H),\n"+
                      "     isTainted(H, P).\n"+
                      "\n \n"+
                      
                      "aliasTaintedPrivID(VT, VP, P ) :-\n"+
                      "	    ptsTo(VT, H),\n"+
                      "	    ptsTo(VP, H),\n"+
                      "     idIsTainted(VT, P),\n"+
                      "     idIsPrivileged(VP, P).\n"+
                      "\n \n"+
                      
                      "aliasTaintedTaintedID(VT1, VT2, P ) :-\n"+
                      "	    ptsTo(VT1, H),\n"+
                      "	    ptsTo(VT2, H),\n"+
                      "		not(VT1 = VT2),\n"+
                      "     idIsTainted(VT1, P),\n"+
                      "     idIsTainted(VT2, P).\n"+
                      "\n \n"+
                      
	                  "%call graph%\n\n"+
	                  "calls(I, M):-\n"+
	                  "		actual(I, 0, C),\n"+
	                  "		ptsTo(C,M).\n"+
	                  "\n \n"+
	                  
	                  "%interprocedural assignments%\n\n"+
	                  "assign(V1, V2):-\n"+
	                  "		calls(I,M),\n"+
	                  "		formal(M, Z, V1),\n"+
	                  "		actual(I, Z, V2).\n"+
	                  "\n \n"+
	                  
	                  "assign(V2, V1):-\n"+
	                  "		calls(I, M),\n"+  
	                  "		methodRet(M,V1),\n"+
	                  "		callRet(I, V2).\n"+
	                  "\n \n"+
	                  
	                  "assign(V1, V2):-\n"+
	                  "		calls(I,M),\n"+
	                  "		formalLexicalRead(M, V1, VarName),\n"+
	                  "		actualLexicalRead(I, V2, VarName).\n"+
	                  "\n \n"+
	                  
	                  
	                  "assign(V1, V2):-\n"+
	                  "		calls(I,M),\n"+
	                  "		formalLexicalWrite(M, VarName, V1),\n"+
	                  "		actualLexicalWrite(I, VarName, V2).\n"+
	                  "\n \n"+
	                  
	                  "%prototype handling%\n\n"+
	                  
	                  "heapPtsTo(H1, F, H2):-\n"+
	                  "		prototype(H1,H),\n"+
	                  "		heapPtsTo(H, F, H2).\n"+
	                  "\n \n"+
	                  
	                  "prototypeOf(D, H):-\n"+
	                  "		typeof(M,D),\n"+
	                  "		heapPtsTo(M, protype, H).\n"+
	                  "\n \n"+
	                  
	                  
	                  "prototypeOf(O, H):-\n"+
	                  "		heapPtsTo(M, prototype, P),\n"+
	                  "		heapPtsTo(M, prototype, H),\n"+
	  				  "		prototypeOf(O,P).\n";
                      /*
                       * The 2nd last rule is redundant if we decide to store the prototype object info in the MethodNodeData
                       * Rule name changed to avoid confusion with property named "prototype"
                       *
                       * The last rule is to equate the two prototype objects. The one declared during function construction and the one is the actual prototype object.
                       * 
                       * */
      return rules;               		
               		
  }

private void incrementNodeInvocationCount(int methodNodeID) {
	
	
	for(int i=0; i< this.codeBodyNodesInCG.size();i++){
		if(this.codeBodyNodesInCG.get(i).nodeID == methodNodeID){
			MethodNodeData node = this.codeBodyNodesInCG.get(i);
			node.invocationCount++;
			this.codeBodyNodesInCG.set(i, node);
			return;
		}
	}
	
}



  public MethodNodeData getNodeFromMethodName (String methodName){
	  for(int i=0; i< this.codeBodyNodesInCG.size(); i++ ){
		  
		 if(this.codeBodyNodesInCG.get(i).type.toString().equalsIgnoreCase(methodName)) 
		   return this.codeBodyNodesInCG.get(i);
		
	   }  
	  return null;/*indicates the method  was not calles, hence does not appear in the callgraph*/
  }


  public static void main(String[] args) throws Exception {
	 
	 //TODO change source file and directory name 
	String dir = "tests/jetpack-modules";
	
	String fileName1= "export.js";	
	String fileName2 = "file.js";
	  
	/*String dir = "tests/scope";
		
	String fileName1= "inherit.js";
	
	String fileName2 = "scope-global.js";*/  

	Util.setTranslatorFactory(new CAstRhinoTranslatorFactory())  ;
    JavaScriptLoaderFactory loaders = Util.makeLoaders();
    URL script = Util.class.getClassLoader().getResource(dir + File.separator + fileName1);
    if (script == null) {
      script = Util.class.getClassLoader().getResource(dir + "/" + fileName1);
    }
    assert script != null : "cannot find " + dir + " and " + fileName1;
    
    URL script2 = Util.class.getClassLoader().getResource(dir + File.separator + fileName2);
    if (script2 == null) {
      script2 = Util.class.getClassLoader().getResource(dir + "/" + fileName2);
    }
    assert script2 != null : "cannot find " + dir + " and " + fileName2;

    AnalysisScope scope;
    if (script.openConnection() instanceof JarURLConnection) {
      scope = Util.makeScope(new URL[] { script }, loaders, JavaScriptLoader.JS);
    } else {
      //scope = Util.makeScope(new SourceFileModule[] { Util.makeSourceModule(script, dir, fileName1), Util.makeSourceModule(script2, dir, fileName2)  }, loaders, JavaScriptLoader.JS);
    	scope = Util.makeScope(new SourceFileModule[] { Util.makeSourceModule(script, dir, fileName1) }, loaders, JavaScriptLoader.JS);	
    }
   
    IClassHierarchy cha = Util.makeHierarchy(scope, loaders);
  
    Iterable<Entrypoint> roots = Util.makeScriptRoots(cha);
    
    AnalysisOptions options = Util.makeOptions(scope, cha, roots);
    
    AnalysisCache cache = Util.makeCache();
    
   
    JSCFABuilder builder = new JSZeroOrOneXCFABuilder(cha, options, cache, null, null, ZeroXInstanceKeys.ALLOCATIONS, false);
    
    CallGraph cg = builder.makeCallGraph(options); 
    DumpProgramAnalysisDatalogFacts dumpPAFObject = new DumpProgramAnalysisDatalogFacts(cg); 
    dumpPAFObject.dumpCallGraph(builder);
    
    String allFileNames []= new String [2] ;
    allFileNames[0]= fileName1;
    allFileNames[1]= fileName2;
    dumpPAFObject.loadCodeBodyNodesinCG(dir, allFileNames);
   
    for(int i=0; i< dumpPAFObject.codeBodyNodesInCG.size(); i++ ){
	   
	   System.out.println( dumpPAFObject.codeBodyNodesInCG.get(i).nodeID);
	   System.out.println( dumpPAFObject.codeBodyNodesInCG.get(i).noOfParameters);
	   for (int j=0; j< dumpPAFObject.codeBodyNodesInCG.get(i).returnVNums.size() ; j++)
	      System.out.println( j+ " "+ dumpPAFObject.codeBodyNodesInCG.get(i).returnVNums.get(j));
	   System.out.println( dumpPAFObject.codeBodyNodesInCG.get(i).type );
	   System.out.println("-------parents------------------");
	   /*
	    * printing scope parents
	    * */
	   int p;
	   IR ir = cg.getNode(dumpPAFObject.codeBodyNodesInCG.get(i).nodeID).getIR();
	   AstMethod method =  (AstMethod) ir.getMethod();
	   String parents[] = method.lexicalInfo().getScopingParents();
	   for ( p = 0; parents!= null && p< parents.length; p++){
		   System.out.println(parents[p]);
	   }
	   
	   System.out.println("--------------exposed names-----------");
	   Pair<String, String> exposedNames[] = method.lexicalInfo().getExposedNames();
	   
	   for ( p = 0; exposedNames!= null && p< exposedNames.length; p++){
		   System.out.println(exposedNames[p].fst+" "+exposedNames[p].snd);
	   }
	   
	   System.out.println("--------------exit uses-----------");
	   int exitUses[] = method.lexicalInfo().getExitExposedUses();
	   
	   
	   for ( p = 0; exitUses!= null && p< exitUses.length; p++){
		   System.out.println(exitUses[p]);
	   }
	   
	   System.out.println("--------------exposed uses-----------");
	   int exposedUses[] = method.lexicalInfo().getExposedUses(0);
	   
	   
	   for ( p = 0; exposedUses!= null && p< exposedUses.length; p++){
		   System.out.println(exposedUses[p]);
	   }
	   
	   System.out.println("-------------------------");
	   
	  
   }

    dumpPAFObject.createPDFforCFG();
    try {
    	dumpPAFObject.dumpDatalogFacts();
    	for(int i=0; i< dumpPAFObject.codeBodyNodesInCG.size(); i++ ){
    		System.out.println( i +" "+dumpPAFObject.codeBodyNodesInCG.get(i).type +" "+ dumpPAFObject.codeBodyNodesInCG.get(i).invocationCount);
    	 
    	dumpPAFObject.applyDatalog(); 
    	 
     }
    }catch(Exception e){
    	e.printStackTrace();
    }
    
       
  }
  
  private void applyDatalog() {
	// invoke shell script to beautify text
		try {
			//String actualPath = newFile.getCanonicalPath();
			String desPath = "/prospero/local/software/des/";
			String command = desPath+"des";
			command = "./datalog.sh";
		
			Process p = Runtime.getRuntime().exec(command);
			p.waitFor();
		} catch (Exception e) {
			e.printStackTrace();
		}
	
  }

private static CGNode getFunctionNode(CallGraph CG, String dir, String file) {
	  TypeName type = TypeName.findOrCreate("L" + dir + "/" + file);
	  if (CG != null) {
	    Iterator<CGNode> iter = CG.iterator();
	    CGNode node;
	    while (iter.hasNext()) {
	      node = iter.next();
	      TypeName tempType = node.getMethod().getDeclaringClass().getName();
	      //if (tempType.equals(type))
	      if (tempType.toString().contains(file) && node.getGraphNodeId()> 1) {
	    	  System.out.println("block no "+ node.getGraphNodeId() + "method "+ node.getMethod() ); 
	    	  System.out.println(tempType.toString() +" " +tempType.getInnermostElementType()+ node.getGraphNodeId());
	    	 if(node.getMethod().toString().contains("Code body") && node.getGraphNodeId()>1)  
	    	    return node;
	      }
	     
	    }
	  }
	  System.err.println("Can't find :" + dir + "/" + file);
	  return null;
  }

  private void printVarName(IR ir, String varFileName){
	 
	  SSAInstruction[] instructions = ir.getInstructions();
	  SymbolTable symTable = ir.getSymbolTable();
	  
	  int instrIndex = 0; 
	
	  for(int i=0; i< instructions.length;i++){
		  if(instructions[i]!=null){
			  instrIndex = i;
			  break;
		  }
	  }
		  
	  try{
		  
	  
		  FileWriter fstream = new FileWriter(this.outputDirName+ "/"+ varFileName);
		  BufferedWriter bufferOut = new BufferedWriter(fstream);  
			
	      	  
		  SSAInstruction instruction = instructions[instrIndex];
		  if (instruction !=null){
		     
		    for (int varNum=1; varNum<= symTable.getMaxValueNumber(); varNum++){
		       	String s;
		      	if (symTable.isConstant(varNum)) {
		          final Object value = symTable.getConstantValue(varNum);
		          s = (value != null) ? value.toString() : null;
		       	}
		       	else {
		          final String[] varName = ir.getLocalNames(instrIndex, varNum);
		          if(varName != null && varName.length == 1)
		        	s = varName[0];
		    	  else if (varName != null && varName.length > 1){
		    	    s = varName[varName.length-1];
		    	    if(s.equalsIgnoreCase("undefined"))
		    	      s= varName[0];
		    	  }
		    	  else
		    	    s =  null;
		       	}
		        //System.out.println("v"+varNum + " "+s);    
		    	bufferOut.write("v"+varNum + " "+s+"\n");    	
		    }
		 }
		  
		 bufferOut.close(); 
	  }catch(Exception e){
		  e.printStackTrace();
	  }
	   
	  
  }
  
  private String getVarName ( IR ir, int vN){
	  
	  SSAInstruction[] instructions = ir.getInstructions();
	  SymbolTable symTable = ir.getSymbolTable();
	
	  int instrIndex = 0; 
		
	  for(int i=0; i< instructions.length;i++){
		  if(instructions[i]!=null){
			  instrIndex = i;
			  break;
		  }
	  }
	
	  SSAInstruction instruction = instructions[instrIndex];
	  String s =null;
	  if (instruction !=null){
		  if (symTable.isConstant(vN)) {
    	      final Object value = symTable.getConstantValue(vN);
    	      return (value != null) ? value.toString() : null;
    	}
    	else {
    	      final String[] varName = ir.getLocalNames(instrIndex, vN);
    	      if(varName != null && varName.length == 1)
    	    	  return  varName[0];
    	      else if (varName != null && varName.length > 1){
    	    	  s = varName[varName.length-1];
    	    	  if(s.equalsIgnoreCase("undefined"))
    	    		  return varName[0];
    	    	  else
    	    		  return s;
    	      }
    	      else
    	    	  return  null;
    	}
	  }
	  return s;
  }
  
  private String getMethodShortName(MethodNodeData node) {
	  
	  String temp = node.type.toString();
	  String methodName;
	  if(node.nodeID > 62){
	      methodName = temp.substring( temp.lastIndexOf(".")+4);
	      if(methodName.contains("/"))
	    		//methodName = methodName.substring( methodName.lastIndexOf("/")+1);
		      methodName = methodName.replace('/', '_');     
	      
	      
	  }    
	  else
	      //methodName= "mScope"+"_"+temp.substring(temp.lastIndexOf("/")+1, temp.lastIndexOf(".")) ;
		  methodName = "moduleScope";
	
	  return methodName;
  }
  
  
  private static boolean isNumeric(String str)
  {
    return str.matches("-?\\d+(.\\d+)?");
  }
  
  private String removeDash( String identifier){
	  if(identifier.contains("-"))
	      identifier = identifier.replace('-', '_');
	  return identifier;
  }
  
  private String makeDatalogCompatibleString(String identifier) {
	  
	   if(identifier.contains("/"))
	      identifier = identifier.replace('/', '_');
	   if (identifier.contains("-"))
		  identifier = identifier.replace('-', '_');
    
		// TODO Auto-generated method stub
		char firstChar = identifier.charAt(0);
		if (firstChar >='A' && firstChar <= 'Z'){
			 // make an uppercase letter to lowercase
			 char modifiedFirstChar = (char) (firstChar + ' ');
			 identifier = identifier.replace(firstChar, modifiedFirstChar);
			 return identifier + "_uppercase"; // indicating that the original text has the first letter in uppercase
		}	
		return identifier;
	}

  
}
