package com.ibm.wala.cast.js.test.tool;

import java.util.ArrayList;


import java.io.BufferedReader;
import java.io.DataInputStream;

import java.io.FileInputStream;
import java.io.InputStreamReader;

import com.ibm.wala.util.collections.Pair;


class MozStub{
	
	
	private final String stubListFilePath = "/prospero/local/Jetpack/interface.txt"; 
	private ArrayList<Pair<String, String>> privilegeXPCOMStubList;// StubName and Privilege pair
	
	public MozStub(){
		
		privilegeXPCOMStubList = new ArrayList<Pair<String,String>> ();
		loadFromFile();
	};
	
	public ArrayList< Pair<String,String>> getListOfPrivilegeXPCOMStub(){
		
		return this.privilegeXPCOMStubList;
	}
	
	private void setListOfPrivilegeXPCOMStub(String stubName){
		
		String temp = stubName.substring(3);
		char [] ch= new char[1];
		ch[0] = (char) (temp.charAt(0) + ' ');// make the lowercase
		String privilegeName = new String ( ch, 0, 1) + temp.substring(1);
		
		Pair<String, String> stubPair = Pair.make( stubName, privilegeName); 
		this.privilegeXPCOMStubList.add(stubPair);
	}
	
	public boolean isPrivilegeXPCOMStub(String stubName){

		
		for (int i =0; i< this.privilegeXPCOMStubList.size(); i++){
			Pair<String, String> p = this.privilegeXPCOMStubList.get(i);
			if(p.fst.equals(stubName))
				return true;
		}
      		
		return false;
	}
	
	private void loadFromFile(){
		
		// read From File
		try{
			// Open the file that is the first 
			// command line parameter
			FileInputStream fstream = new FileInputStream(this.stubListFilePath);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//Read File Line By Line
			while ((strLine = br.readLine()) != null)   {
				// Print the content on the console
				System.out.println ("^^^^^^^^^^^^^^^^^^^^^^^^^"+strLine);
				this.setListOfPrivilegeXPCOMStub(strLine);
			}
			//Close the input stream
			in.close();
		}catch (Exception e){//Catch exception if any
			
			System.err.println("Error: " + e.getMessage());
		}
		
		
	}

	public String getPrivilegeForStub(String stubName) {
		
		for (int i =0; i< this.privilegeXPCOMStubList.size(); i++){
			Pair<String, String> p = this.privilegeXPCOMStubList.get(i);
			if(p.fst.equals(stubName))
				return p.snd;
		}
		return null;
	}
	
	
	
}