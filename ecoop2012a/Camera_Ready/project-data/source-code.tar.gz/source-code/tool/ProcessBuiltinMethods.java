package com.ibm.wala.cast.js.test.tool;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Random;

import com.ibm.wala.cast.js.ssa.JavaScriptInvoke;
import com.ibm.wala.cast.js.ssa.JavaScriptPropertyRead;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.SSAInstruction;

public class ProcessBuiltinMethods {
	
	String vNumPrefix = "builtin";
	/*
	 * lis tof unhandled construct:
	 * __defineGetter
	 * __defineSetter
	 * function.apply
	 * eval
	 */
	
	public ProcessBuiltinMethods(){
		
	}

	public void dumpDatalogFactsForBuiltinMethod(String calleeMethodFullName, IR ir,
			SSAInstruction instruction, String shortCurrentMethodName, BufferedWriter bOut) throws IOException {
		
		String fact;
		String rValNumString, lValNumString;
		
		
		if (/**
		 * Math functions
		 * */
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/abs")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/acos")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/asin")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/atan")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/atan2")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/ceil")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/cos")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/exp")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/floor")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/log")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/max")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/min")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/pow")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/random")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/round")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/sin")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/sqrt")	|| 
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/tan") ||
				/**
				 * String functions
				 * */
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringToString")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringValueOf")		||
				/**
				 * Array functions
				 * */
				
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/sort")	||
				/**
				 * Function functions
				 * */
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/functionToString")	

		){
			/*
			 * This function returns primitive value so do nothing
			 */
		}

		/**
		 * Array functions
		 * */
		else if(
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/arrayToString")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/arrayToLocaleString") ||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/join")
				){
			
			rValNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(1) +"_"+shortCurrentMethodName;// object on which this function is called, this value
			
			String primObjectName = new Integer(instruction.getDef()).toString();
			String heapObjectName = "h_"+ "String" + "_"+ instruction.getDef() +"_"+primObjectName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;   
			/*
			 * no need to store heap mapping, since we are not considering capability leak through primitive value
			 */
			//this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, primObjectName, vNumString, heapObjectName);

			fact = "ptsTo("+ rValNumString +","+ heapObjectName+").\n"; 
			bOut.write(fact);
			
		}
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/concat")){
			/*
			 * Being conservative, not considering the array index
			 */
			
			String element; 
			String array = this.vNumPrefix + "_" + "v"+ instruction.getUse(1)+"_"+shortCurrentMethodName ;
			
			int paramCount = ((JavaScriptInvoke)instruction).getNumberOfParameters();
			for (int paramIndex = 2; paramIndex< paramCount; paramIndex++){
				element = this.vNumPrefix + "_" + "v"+ instruction.getUse(paramIndex) +"_"+shortCurrentMethodName;
				fact= "cArrayStore("+ array +", "+ element +").\n";				  
				bOut.write(fact);
			}
			
			/*
			 * Being conservative, we are assigning the same heap to the concatenated array
			 */

			this.dumpConservativeAssignFact(instruction,shortCurrentMethodName, bOut);	
		}
				
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/push")){
			/*
			 * Being conservative, not considering the array index
			 */
			
			String element =	this.vNumPrefix + "_" + "v"+ instruction.getUse(2) +"_"+shortCurrentMethodName ;
			String array = this.vNumPrefix + "_" + "v"+ instruction.getUse(1)+"_"+shortCurrentMethodName ;

			fact= "cArrayStore("+ array +", "+ element +").\n";
			bOut.write(fact);  
		}
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/pop")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/shift")
				){
			/*
			 * Being conservative, not considering the array index
			 */		
						
			String element = this.vNumPrefix + "_" + "v"+ instruction.getDef() +"_"+shortCurrentMethodName ;
			String array = this.vNumPrefix + "_" + "v"+ instruction.getUse(1)+"_"+shortCurrentMethodName ;

			fact= "cArrayLoad("+ element +", "+ array +").\n";
			bOut.write(fact);  
			
		}
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/reverse")	||					
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/slice")	
				){
			/*
			 * Being conservative, we are assigning the same heap to the processed array
			 */   
			this.dumpConservativeAssignFact(instruction,shortCurrentMethodName, bOut);			
			
		}
				/**
				 * String functions
				 * */
		else if(
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringToString")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringValueOf")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringCharAt")	||				
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toUpperCase")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLocaleUpperCase")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLowerCase")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLocaleLowerCase")	||				
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringSplit")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/substring")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/replace")	
		){
			/*
			 * Being conservative, we are assigning the same heap to the processed string
			 */  
			this.dumpConservativeAssignFact(instruction,shortCurrentMethodName, bOut);	
		}
		
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringCharCodeAt")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/indexOf")	){
			
			
			rValNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(1) +"_"+shortCurrentMethodName;// object on which this function is called, this value
			
			String primObjectName = new Integer(instruction.getDef()).toString();
			String heapObjectName = "h_"+ "Number" + "_"+ instruction.getDef() +"_"+primObjectName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;    
			/*
			 * no need to store heap mapping, since we are not considering capability leak through primitive value
			 */
			//this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, primObjectName, vNumString, heapObjectName);

			fact = "ptsTo("+ rValNumString +","+ heapObjectName+").\n"; 
			bOut.write(fact);
		}
		/**
		 * Function functionsApply
		 * */
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/functionApply")){			
		
			String vNumString;
			String callSiteID = "i" + new Integer(this.getRandomNumber()).toString() ;
			/*
			 * set the invoked function name  			
			 */
			vNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(1) +"_"+shortCurrentMethodName;
			fact = "actual("+ callSiteID+ ","+0+","+ vNumString +").\n";
			bOut.write(fact);
		
			/*
			 * Problem in modeling apply. arguments array have not been handled. If possible change the instruction to call isntruction
			 */
		
		}
		
		/**
		 * Function functionsCall
		 * */
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/functionCall")){			
			
			String vNumString;
			String callSiteID = "i" + new Integer(this.getRandomNumber()).toString() ;
			/*
			 * set the invoked function name  			
			 */
			vNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(1) +"_"+shortCurrentMethodName;
			fact = "actual("+ callSiteID+ ","+0+","+ vNumString +").\n";
			bOut.write(fact);
					
			/*
			 * Setting parameters of the invoked function, param start from index 1
			 */
			int paramCount = ((JavaScriptInvoke)instruction).getNumberOfParameters();
			for (int paramIndex = 2; paramIndex< paramCount; paramIndex++){
				vNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(paramIndex) +"_"+shortCurrentMethodName;
				fact = "actual("+ callSiteID+ ","+ paramIndex +","+ vNumString +").\n";  
				bOut.write(fact);
			}
		}
				/**
				 * Object functions
				 * */
		else if(
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toString")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLocaleString")	||			
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/hasOwnProperty")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/isPrototypeOf")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/propertyIsEnumerable")){
			/*
			 * This function returns primitive value so do nothing
			 */
			
		}
		else if(calleeMethodFullName.equalsIgnoreCase("Lprologue.js/valueOf")	){
			this.dumpConservativeAssignFact(instruction,shortCurrentMethodName, bOut);	
		}
		else if(		/**
				 * Global functions
				 * */
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/eval")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/parseInt")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/parseFloat")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/isNaN")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/isFinite")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/decodeURI")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/decodeURIComponent")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/encodeURI")	||
				calleeMethodFullName.equalsIgnoreCase("Lprologue.js/encodeURIComponent")
		){
			/*
			 * This function returns primitive value so do nothing
			 */			
		}
	}

	private void dumpConservativeAssignFact(SSAInstruction instruction, String shortCurrentMethodName, BufferedWriter bOut) throws IOException {
		
		String fact;
		String rValNumString, lValNumString;
		/*
		 * Being conservative, we are assigning the same heap to the processed string
		 */

		lValNumString = this.vNumPrefix + "_" + "v"+ instruction.getDef() +"_"+shortCurrentMethodName;// return value
		rValNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(1) +"_"+shortCurrentMethodName;// object on which this function is called, this value

		fact = "assign("+ lValNumString +","+ rValNumString +").\n";  
		bOut.write(fact);
	}

	public boolean checkBuiltinMethod(String calleeMethodFullName) {
		if (/**
			 * Math functions
			 * */
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/abs")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/acos")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/asin")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/atan")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/atan2")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/ceil")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/cos")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/exp")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/floor")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/log")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/max")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/min")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/pow")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/random")||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/round")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/sin")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/sqrt")	|| 
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/tan")	||
			
			/**
			 * Array functions
			 * */
		
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/arrayToString")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/arrayToLocaleString")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/concat")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/join")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/pop")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/push")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/reverse")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/shift")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/slice")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/sort")	||
			/**
			 * String functions
			 * */
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringToString")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringValueOf")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringCharAt")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringCharCodeAt")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toUpperCase")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLocaleUpperCase")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLowerCase")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLocaleLowerCase")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/indexOf")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/stringSplit")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/substring")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/replace")	||
			/**
			 * Function functions
			 * */
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/functionToString")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/functionApply")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/functionCall")	||
			/**
			 * Object functions
			 * */
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toString")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/toLocaleString")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/valueOf")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/hasOwnProperty")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/isPrototypeOf")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/propertyIsEnumerable")	||
			/**
			 * Global functions
			 * */
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/eval")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/parseInt")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/parseFloat")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/isNaN")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/isFinite")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/decodeURI")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/decodeURIComponent")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/encodeURI")	||
			calleeMethodFullName.equalsIgnoreCase("Lprologue.js/encodeURIComponent")
			){
				return true;
			}
		return false;
	}
	
	private int getRandomNumber() {
		int min = 1000;
		int max = 5000;
		Random rand = new Random();
		int random = rand.nextInt(max-min+1) + min;	
		return random;
	}
}
