package com.ibm.wala.cast.js.test.overprivileged;

/******************************************************************************

 * Copyright (c) 2002 - 2006 IBM Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *****************************************************************************/



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.io.FileReader;

import java.io.LineNumberReader;

import java.net.JarURLConnection;
import java.net.URL;



import com.ibm.wala.cast.js.ipa.callgraph.JSCFABuilder;
import com.ibm.wala.cast.js.ipa.callgraph.JSZeroOrOneXCFABuilder;
import com.ibm.wala.cast.js.ipa.callgraph.Util;
import com.ibm.wala.cast.js.loader.JavaScriptLoader;
import com.ibm.wala.cast.js.loader.JavaScriptLoaderFactory;
import com.ibm.wala.cast.js.translator.CAstRhinoTranslatorFactory;



import com.ibm.wala.classLoader.SourceFileModule;

import com.ibm.wala.ipa.callgraph.AnalysisCache;
import com.ibm.wala.ipa.callgraph.AnalysisOptions;
import com.ibm.wala.ipa.callgraph.AnalysisScope;
import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.CallGraphStats;
import com.ibm.wala.ipa.callgraph.Entrypoint;
import com.ibm.wala.ipa.callgraph.propagation.cfa.ZeroXInstanceKeys;
import com.ibm.wala.ipa.cha.IClassHierarchy;

import com.ibm.wala.cast.js.test.overprivileged.MozStub;

/*
 * This version distinguishes callsites by a number, does not simulate the call stack.
 * It is followed by Count since it needs to count the number of times a function has been invoked;  this is done only to eliminate duplicate
 * facts from being generated 
 *   
 */

// support require, globals, on event

//import com.ibm.wala.cast.js.test.tool.DumpModuleDatalogFacts;

class AnalyzeMultipleModules {

	String WALARootDir;
	private final String WALAJSsourcePath = "com.ibm.wala.cast.js.test/examples-src/tests";
	private final String desPath = "/prospero/local/software/des/";

	
	String source = ""; // source Dir will be wrt WALA 'tests'
	String destination = "";


	CallGraph callGraph;
	private String destinationRootDir;
	
	MozStub mozStub;
	private String templateDir;

	public AnalyzeMultipleModules() {

	}

	public void walk(File file) {

		if(!file.isDirectory())
			return;
		try {
			for (File child : file.listFiles()) {
				if(child.isDirectory()) {
					new File(this.destination, child.getName()).mkdir();
					this.walk(child);
				} else {
					System.out.println("File = " + child.getCanonicalPath());
					String walaJSSrcDir = this.getWALARelativeSrcDir(child.getParent()); 
					this.analyzeSingleModule(walaJSSrcDir, child.getName());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	private String getWALARelativeSrcDir(String path) {

		int index = path.indexOf("examples-src/tests");
		path = path.substring(index+13 );// strip out the examples-src part
		/*index = path.lastIndexOf(File.separator);
			String relativeSrcDir = path.substring(0,index);	  
			return relativeSrcDir;
		 */
		return path;
	}




	private void analyzeSingleModule(String moduleSrcDir, String moduleFileName) throws Exception{

		

		Util.setTranslatorFactory(new CAstRhinoTranslatorFactory())  ;

		JavaScriptLoaderFactory loaders = Util.makeLoaders();


		URL script = Util.class.getClassLoader().getResource(moduleSrcDir + File.separator + moduleFileName);

		if (script == null) {

			script = Util.class.getClassLoader().getResource(moduleSrcDir + "/" + moduleFileName);

		}

		assert script != null : "cannot find " + moduleSrcDir + " and " + moduleFileName;


		AnalysisScope scope;
		if (script.openConnection() instanceof JarURLConnection) {
			scope = Util.makeScope(new URL[] { script }, loaders, JavaScriptLoader.JS);
		} else {

			scope = Util.makeScope(new SourceFileModule[] { Util.makeSourceModule(script, moduleSrcDir, moduleFileName) }, loaders, JavaScriptLoader.JS);	
		}

		IClassHierarchy cha = Util.makeHierarchy(scope, loaders);

		Iterable<Entrypoint> roots = Util.makeScriptRoots(cha);

		AnalysisOptions options = Util.makeOptions(scope, cha, roots);

		AnalysisCache cache = Util.makeCache();


		JSCFABuilder builder = new JSZeroOrOneXCFABuilder(cha, options, cache, null, null, ZeroXInstanceKeys.ALLOCATIONS, false);

		CallGraph cg = builder.makeCallGraph(options);   
        
		String fileSpecificOutputDir = moduleSrcDir.substring(moduleSrcDir.indexOf(File.separator)+1);// strip out tests from the path
		fileSpecificOutputDir += File.separator + moduleFileName.substring(0, moduleFileName.indexOf('.'));

		String outputDirPath = this.destinationRootDir + File.separator + fileSpecificOutputDir; 
		
		DumpModuleDatalogFacts dumpPAFObject = new DumpModuleDatalogFacts(cg, outputDirPath, this.templateDir, mozStub);
		dumpPAFObject.dumpCallGraph(builder);

		dumpPAFObject.loadCodeBodyNodesinCG(this.source, moduleFileName);

		dumpPAFObject.createPDFforCFG();
		try {
			dumpPAFObject.dumpDatalogFacts();
			dumpPAFObject.generateDesIniFile(outputDirPath, desPath);
			dumpPAFObject.applyDatalog();
		}catch(Exception e){
			e.printStackTrace();
		}
        
	}



	

	private void generateDatalogSHFile() throws IOException {
		
		FileWriter fstream = new FileWriter("datalog.sh");
		BufferedWriter dshOut = new BufferedWriter(fstream);
		
		String dshString = "#!/bin/sh" +"\n"
                         + "traceFile=trace" + "\n";
		dshString += "cd "+ this.desPath+"\n"
						+ "echo `pwd` > $traceFile" + "\n"
						+"./des"+"\n";

		dshOut.write(dshString);
		dshOut.close();
		
		File datalogSHFile = new File("datalog.sh");
		if(!datalogSHFile.canExecute())
			datalogSHFile.setExecutable(true, false); //anyone can run datalog.sh
	}

	public static void main(String[] args) throws Exception {

		AnalyzeMultipleModules sg = new AnalyzeMultipleModules();
		sg.WALARootDir = args[0];
		sg.source = args[1];
		sg.destinationRootDir = args[2];
		sg.templateDir = args[3];
		/*
		 *  set the destinationRootDir, if non-existing then create it
		 */
		File file = new File(sg.destinationRootDir);
		try {
			if(!file.exists()) {
				file.mkdir();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		/* loading the stub list*/
		sg.mozStub = new MozStub();  
		
		/*
		 * dump the script to invoke DES executable
		 */
		
		sg.generateDatalogSHFile();
		/*
		 * set the input JS directory
		 */
		file = new File(sg.WALARootDir+ File.separator+ sg.WALAJSsourcePath+ File.separator+ sg.source);
		sg.walk(file);



	}



}



