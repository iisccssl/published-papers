package com.ibm.wala.cast.js.test.overprivileged;

/******************************************************************************

 * Copyright (c) 2002 - 2006 IBM Corporation.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *****************************************************************************/
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.ibm.wala.cast.ir.ssa.AstLexicalRead;
import com.ibm.wala.cast.ir.ssa.AstLexicalWrite;
import com.ibm.wala.cast.js.ipa.callgraph.JSCFABuilder;

import com.ibm.wala.cast.js.ipa.callgraph.Util;

import com.ibm.wala.cast.js.ssa.JavaScriptInvoke;
import com.ibm.wala.cast.js.ssa.JavaScriptPropertyRead;
import com.ibm.wala.cast.js.ssa.JavaScriptPropertyWrite;
import com.ibm.wala.cast.js.ssa.JavaScriptMultiplePermissionAnalysis.CheckBinaryOpInstruction;

import com.ibm.wala.cast.js.types.JavaScriptMethods;
import com.ibm.wala.cast.loader.AstMethod;
import com.ibm.wala.classLoader.CallSiteReference;

import com.ibm.wala.examples.properties.WalaExamplesProperties;

import com.ibm.wala.ipa.callgraph.CGNode;
import com.ibm.wala.ipa.callgraph.CallGraph;
import com.ibm.wala.ipa.callgraph.CallGraphStats;
import com.ibm.wala.properties.WalaProperties;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.ISSABasicBlock;
import com.ibm.wala.ssa.SSABinaryOpInstruction;
import com.ibm.wala.ssa.SSACFG;
import com.ibm.wala.ssa.SSAGetInstruction;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.ssa.SSAPhiInstruction;
import com.ibm.wala.ssa.SSAPutInstruction;
import com.ibm.wala.ssa.SSAReturnInstruction;
import com.ibm.wala.ssa.SymbolTable;
import com.ibm.wala.types.TypeName;
import com.ibm.wala.util.collections.Pair;
import com.ibm.wala.util.debug.Assertions;
import com.ibm.wala.util.warnings.WalaException;
import com.ibm.wala.viz.DotUtil;
import com.ibm.wala.viz.PDFViewUtil;



/*
 * This version distinguishes callsites by a number, does not simulate the call stack.
 * It is followed by Count since it needs to count the number of times a function has been invoked;  this is done only to eliminate duplicate
 * facts from being generated 
 *   
 */



//

// support require, globals, on event



class DumpModuleDatalogFacts_ret_not_overpriv {

	//private final String desPath = "/prospero/local/software/des/";
	private final String outputDirName ;
	private final String templateDir;
	private final String XPCOMTemplateDir;
	
	private  String vNumPrefix; 
	CallGraph callGraph;

	MozStub mozStub;
	ProcessBuiltinMethods pbmObj;

	public class MethodNodeData{

		int nodeID;
		int noOfParameters;

		ArrayList<Integer> returnVNums; // empty if no return or void return
		TypeName type;
		/*
		 * store the heapObjectCorresponding to this method
		 */
		String methodHeapObject;
		String prototypeHeapObject; // could have inferred it through datalog rules, but in stead of that storing here to reduce the number of facts
		/**
		 * Store a list <parameter/locals string, < vNum, Heap object>> mappings
		 * However, with the current flow- context insensitive analysis model, no need to store the heapObject information for an identifier either
		 * since now all the vNum corrs. to the same variable will point to all heap object corrs. to that variable   
		 */

		Map< String, Pair<String, String>>  identifierToHeapMapping;

		int parentNodeID;// method node for the lexical parent of this method 

		Map< Integer, String> vNumToIdentifierMapping;
		Map< String, String> WALAAssignIdToVNumMapping; // example: self, v8_StreamManager

	}


	ArrayList<MethodNodeData> codeBodyNodesInCG;
	

	public DumpModuleDatalogFacts(CallGraph cg2, String outputDirPath, String templateDirPath, MozStub mozStub) {
		callGraph = cg2;
		codeBodyNodesInCG = new ArrayList<MethodNodeData> (); 
	
		this.outputDirName = outputDirPath;
		this.templateDir = templateDirPath;
		this.XPCOMTemplateDir = this.templateDir + File.separator + "XPCOM";
		this.mozStub = mozStub;
		this.pbmObj = new ProcessBuiltinMethods();
	}

	public void dumpCallGraph(JSCFABuilder builder){
		System.out.println("dumping CG via Util method invocation");
		Util.dumpCG(builder, callGraph);
		System.err.println("printing cg "+ callGraph);
		System.out.println(" CallGraph Statistics "+CallGraphStats.getStats(callGraph));
	}

	public void loadCodeBodyNodesinCG(String dir, String fileName){



		TypeName type = TypeName.findOrCreate("L" + dir + "/" + fileName);
		if (callGraph != null) {
			Iterator<CGNode> iter = callGraph.iterator();
			CGNode node;
			while (iter.hasNext()) {
				node = iter.next();
				TypeName tempType = node.getMethod().getDeclaringClass().getName();

				if (tempType.toString().contains(fileName) && node.getGraphNodeId()> 1) {

					System.out.println("block no "+ node.getGraphNodeId() + " method "+ node.getMethod() ); 
					System.out.println(tempType.toString() +" " +tempType.getInnermostElementType()+ " "+node.getGraphNodeId());

					if(node.getMethod().toString().contains("Code body") && node.getGraphNodeId()>1){
						/*
						 * construct an instance of  MethodNodeData and set the property value
						 */
						MethodNodeData aMethodData = new MethodNodeData();
						aMethodData.nodeID = node.getGraphNodeId();
						aMethodData.type = tempType; 
						aMethodData.noOfParameters = node.getMethod().getNumberOfParameters();
						aMethodData.returnVNums = new ArrayList<Integer>();
						if(aMethodData.nodeID < 62){						
							aMethodData.parentNodeID = 1; // their parent is prologue.js
						}	

						aMethodData.identifierToHeapMapping = new HashMap< String, Pair<String, String>>();
						aMethodData.vNumToIdentifierMapping = new HashMap<Integer, String>();
						aMethodData.WALAAssignIdToVNumMapping = new HashMap< String, String>();
						/*
						 * find the return vNum 
						 */
						SSAInstruction[] instructions = node.getIR().getInstructions();


						for (int j = 0; j < instructions.length; j++) {
							if (instructions[j] instanceof SSAReturnInstruction ){
								if (!((SSAReturnInstruction)instructions[j]).returnsVoid())
									aMethodData.returnVNums.add(new Integer (instructions[j].getUse(0)));		    			
							}  	
						}
						codeBodyNodesInCG.add(aMethodData);
					}   
				} 

			}
		}


	}

	public void createPDFforCFG(){

		int i;
		String methodName, temp;
		SSACFG cfg;
		IR ir;

		this.createOutputDir();


		for(i=0; i < codeBodyNodesInCG.size(); i++){
			temp = this.codeBodyNodesInCG.get(i).type.toString();
			if(this.codeBodyNodesInCG.get(i).nodeID > 62){
				methodName = temp.substring( temp.lastIndexOf(".")+4);
				/*if(methodName.contains("/"))
    	  methodName = methodName.substring( methodName.lastIndexOf("/"));*/
				methodName = methodName.replace('/', '_');
			}	 
			else{
				//methodName = "mScope"+"_"+temp.substring(temp.lastIndexOf("/")+1, temp.lastIndexOf(".")) ;
				methodName = "moduleScope";
			}

			String pdfFileName =  methodName +"_cfg.pdf";
			String dotFileName = methodName +"_cfg.dot";

			System.out.println(" pdf file "+pdfFileName);
			// Get the IR of a CGNode
			// Get CFG from IR
			ir = callGraph.getNode(this.codeBodyNodesInCG.get(i).nodeID).getIR();
			cfg = ir.getControlFlowGraph();
			//load pdf properties
			Properties wp = null;
			try {

				wp = WalaProperties.loadProperties();
				wp.putAll(WalaExamplesProperties.loadProperties());
			} catch (WalaException e) {
				e.printStackTrace();
				Assertions.UNREACHABLE();
			}
			/*String psFile = wp.getProperty(WalaProperties.OUTPUT_DIR) + File.separatorChar + pdfFileName;
			String dotFile = wp.getProperty(WalaProperties.OUTPUT_DIR) + File.separatorChar + dotFileName;*/

			String psFile = this.outputDirName + File.separatorChar + "pdfDir" + File.separatorChar + pdfFileName;
			String dotFile = this.outputDirName + File.separatorChar + "pdfDir" + File.separatorChar + dotFileName;

			String dotExe = wp.getProperty(WalaExamplesProperties.DOT_EXE);
			String gvExe = wp.getProperty(WalaExamplesProperties.PDFVIEW_EXE);

			//draw the .dot file and load it in pdf file
			try{
				DotUtil.dotify(cfg, PDFViewUtil.makeIRDecorator(ir), dotFile, psFile, dotExe);
				//PDFViewUtil.launchPDFView(psFile, gvExe);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			//print Variable names
			System.out.println("variable file name should be "+ methodName+ "_var");
			String varFileName = methodName + "_var";
			printVarName(ir, varFileName);
		}  
	}

	private void createOutputDir() {

		ArrayList<String> dirs = new ArrayList<String>();  
		File file = new File(this.outputDirName);

		while(!file.exists()){
			if(file.getParentFile().exists())
				file.mkdir();
			else{
				dirs.add(file.getName());
				file = file.getParentFile();

			}
			/*tempDir = tempDir.substring(tempDir.indexOf(File.separator));
		file = new File(tempDir);*/	 
		}

		for(int i=dirs.size()-1; i>=0 ;i--){
			String dir = file.getAbsolutePath() + File.separator + dirs.get(i);
			file = new File(dir);
			if(!file.exists())
				file.mkdir();

		}

		/*
		 * outputDir is created. now create s sub directory for dumping the pdf files
		 */

		File pdfDir = new File(this.outputDirName+ File.separator + "pdfDir");
		pdfDir.mkdir();

		File mapDir = new File(this.outputDirName+ File.separator + "map");
		mapDir.mkdir();

		File tempGenDir = new File(this.outputDirName+ File.separator + "tempGenDir");
		tempGenDir.mkdir();

		File WALAappendDir = new File(this.outputDirName+ File.separator + "WALAappendDir");
		WALAappendDir.mkdir();

		File overprivilegedDir = new File (this.outputDirName+ File.separator + "overprivilegedDir");
		overprivilegedDir.mkdir();
	}


	/**
	 * Analyze instructions one by one and spit out Datalog facts to a file
	 * @throws Exception
	 */



	public void dumpDatalogFacts() throws Exception {


		/*String desPath = "/prospero/local/software/des/examples";  

		FileWriter fstream = new FileWriter(desPath +"/programFacts.dl");*/
		FileWriter fstream = new FileWriter(this.outputDirName+ File.separator +"programFacts.dl");
		BufferedWriter bOut = new BufferedWriter(fstream);  

		FileWriter exportFile = new FileWriter(this.outputDirName+ File.separator +"children");
		BufferedWriter exportOut = new BufferedWriter(exportFile);  

		/*
		 * privilege generation should be recorded here. This is exclusive to the module being analyzed. 
		 */
		FileWriter privFile = new FileWriter(this.outputDirName+ File.separator +"privileged");
		BufferedWriter privOut = new BufferedWriter(privFile);  

		/*
		 * files for template generation
		 */
		String templateGenerationDir = this.outputDirName+ File.separator + "tempGenDir";

		FileWriter varMapFile = new FileWriter( templateGenerationDir + File.separator +"varMap.txt");
		BufferedWriter varMapOut = new BufferedWriter(varMapFile);  

		FileWriter parentFile = new FileWriter( templateGenerationDir + File.separator +"parent.txt");
		BufferedWriter parentOut = new BufferedWriter(parentFile);  

		FileWriter prototypeFile = new FileWriter( templateGenerationDir + File.separator +"prototype.txt");
		BufferedWriter prototypeOut = new BufferedWriter( prototypeFile);  
		
		/*
		 * Files for dumping WALA append parent child mapping 
		 */
		String WALAappendDir = this.outputDirName+ File.separator + "WALAappendDir";
		FileWriter WAparentFile = new FileWriter( WALAappendDir + File.separator +"parent.txt");
		BufferedWriter WAparentOut = new BufferedWriter( WAparentFile);
		
		FileWriter WAvarMapFile = new FileWriter( WALAappendDir + File.separator +"varMap.txt");
		BufferedWriter WAMapOut = new BufferedWriter(WAvarMapFile);  
		
		FileWriter WAretFile = new FileWriter( WALAappendDir + File.separator +"ret.txt");
		BufferedWriter WAretOut = new BufferedWriter( WAretFile);
				
		/*
		 * Files required for over privileged
		 */
		String overprivilegedDir = this.outputDirName+ File.separator + "overprivilegedDir";
		FileWriter isMozReqFile = new FileWriter( overprivilegedDir + File.separator +"isMozReq.txt");
		BufferedWriter isMozReqOut = new BufferedWriter( isMozReqFile);
		

		int global_i = 0; //increment it @ each callSiteID  
		int lValNum, rValNum;

		String currentMethodName; //<todo> change it to the method name
		MethodNodeData currentMethodNode;


		/*
		 * initialize the callStack
		 */
		for(int i=0; i< this.codeBodyNodesInCG.size();i++){

			/*
			 * map vNum to integer declared in parent scope	
			 */
			HashMap<Integer, String> vNumOfIdentifierInParentScope = new HashMap<Integer, String>();	
			/*
			 * set the method to be processed
			 */
			currentMethodNode = this.codeBodyNodesInCG.get(i);
			currentMethodName = currentMethodNode.type.toString();

			String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
			/*
			 * invoking removeDash is enough since this string will be attached to vNum
			 */
			shortCurrentMethodName = this.removeDash(shortCurrentMethodName);
			if(shortCurrentMethodName.indexOf("WALAappend") != -1){
				this.vNumPrefix = "true" ;
				//shortCurrentMethodName = "moduleScope";
			}	
			else
				this.vNumPrefix = "false";
			/*
			 * get the IR of the node being processed
			 */
			IR ir = callGraph.getNode(currentMethodNode.nodeID).getIR();
			/* 
			 * Get CFG from IR
			 */
			SSACFG cfg = ir.getControlFlowGraph();
			/*
			 * Iterate over the Basic Blocks of CFG
			 * @Assumption: method names are unique
			 */
			Iterator<ISSABasicBlock> cfgIt = cfg.iterator();

			while (cfgIt.hasNext()) {
				ISSABasicBlock ssaBb = cfgIt.next();

				// Iterate over SSA Instructions for a Basic Block
				Iterator<SSAInstruction> ssaIt = ssaBb.iterator();
				while (ssaIt.hasNext()) {
					SSAInstruction instruction = ssaIt.next();

					/*
					 * Once appended code line is reached the prefix will always be true for the moduleScope code whose nodeID is 2
					 * The following condition will always be false for any method defined inside the file, since its line no is calculated wrt to the method body
					 * Therefore the appendedCodeStarted flag will be always false and vNumPrefix will be fixed to false
					 */
					/*if(this.getSrcLineNumForInstruction(ir, instruction) > this.moduleOrgFileLen)
						appendedCodeStarted = true;

					if (appendedCodeStarted)
						this.vNumPrefix = "true" ;
					else
						this.vNumPrefix = "false";
					 */

					if(instruction instanceof AstLexicalRead){

						this.processAstLexicalReadInstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, vNumOfIdentifierInParentScope, bOut);
					}
					else if(instruction instanceof AstLexicalWrite){

						this.processAstLexicalWriteInstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, vNumOfIdentifierInParentScope, bOut);
					}
					else if(instruction instanceof SSAPutInstruction ){

						this.processSSAPutInstruction(ir, instruction, shortCurrentMethodName, bOut, exportOut, varMapOut, parentOut, prototypeOut);
					}
					else if(instruction instanceof SSAGetInstruction ){

						this.processSSAGetInstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, privOut, WAparentOut, WAMapOut);
					}
					else if(instruction instanceof JavaScriptPropertyRead){

						this.processJavaScriptPropertyReadInstruction(ir, instruction, shortCurrentMethodName, bOut);
					}
					else if(instruction instanceof JavaScriptPropertyWrite){

						this.processJavaScriptPropertyWriteInstruction(ir, instruction, shortCurrentMethodName, bOut);
					} 
					else if (instruction instanceof SSAPhiInstruction ){

						this.processSSAPhiInstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, vNumOfIdentifierInParentScope, bOut);
					}
					else if(instruction instanceof SSABinaryOpInstruction){

						this.processSSABinaryOPInstruction(ir, instruction);
					}
					else if (instruction instanceof JavaScriptInvoke ){

						boolean isConstruct =  ((JavaScriptInvoke)instruction).getDeclaredTarget().equals(JavaScriptMethods.ctorReference);

						if(isConstruct){
							/*
							 * Construct either Object, function object or any other type of object  
							 */
							global_i = this.processConstructInstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, global_i);						}  

						else{
							// TODO process events						
							global_i = this.processInvokeInstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, privOut, WAretOut, isMozReqOut, global_i);
						}
					}
					else if (instruction instanceof SSAReturnInstruction ){

						String fact;
						if(currentMethodName.equalsIgnoreCase("")){
							rValNum = instruction.getUse(0);
							fact = "MethodRet(v"+ rValNum + ").\n";
							bOut.write(fact);  
							System.out.println(fact);
						}

						/*  if(currentMethodName.equalsIgnoreCase(""))
	              fact = "MethodRet(v"+ lValNum +",v"+ rValNum +")";
	            else
	              fact = "MethodRet(v"+ lValNum +"_"+currentMethodName+",v"+ rValNum +"_"+currentMethodName+")";

	              bOut.write(fact);  
	              System.out.println(fact);
						 */
					}
				}// end of one block
				vNumOfIdentifierInParentScope.clear(); 
			}//end of one method node
			bOut.write("\n\n");
		}
		//Close the output stream
		String rules = this.getDatalogRules();
		bOut.write(rules);
		bOut.close();
		exportOut.close();
		privOut.close();
		varMapOut.close();
		parentOut.close();
		prototypeOut.close();
		WAMapOut.close();
		WAparentOut.close();
		WAretOut.close();
		isMozReqOut.close();
	}

	/*
	 * Analyze Construct instruction  
	 */

	private int processConstructInstruction(
			MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut,  int global_i) throws IOException {

		String constructorName = getVarName(ir, ((JavaScriptInvoke)instruction).getFunction());

		if(constructorName != null){ 

			if(constructorName.equalsIgnoreCase("Object")){

				this.processObjectLiteralConstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut);
			}
			else if (constructorName.equalsIgnoreCase("Function")){

				/*
				 * Construct an Function object 
				 */
				this.processFunctionObjectConstruction(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut);
			}
			else if (constructorName.equalsIgnoreCase("String") 
					||constructorName.equalsIgnoreCase("Number")
					|| constructorName.equalsIgnoreCase("Boolean")
					|| constructorName.equalsIgnoreCase("Date")
					|| constructorName.equalsIgnoreCase("Array")
					|| constructorName.equalsIgnoreCase("RegExp")){

				this.processPrimitiveObjectConstruction(constructorName, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut);

			}

			else if (constructorName.equalsIgnoreCase("Error")){
				/*
				 * Do not process "new Error" statement
				 */
			}

			else{

				/*
				 * Construct an object of a type that has been already declared, almost all the cases the type will be a function
				 * @TODO : figure out object constructor name
				 */

				global_i = this.processCustomObjectConstruction(constructorName, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, global_i);


			}// end of else

		} // if constructname null checking

		else{

			// construcotrName is null. so the assumption is function is used as a constructor, but the constructor name is null, example var a = new exports.foo();

			global_i = this.processCustomObjectConstruction(constructorName, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, global_i);

		}  		


		return global_i;
	}

	/*
	 * Analyze Invoke instruction  
	 */

	private int processInvokeInstruction(
			MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, BufferedWriter privOut, BufferedWriter WAretOut, BufferedWriter isMozReqOut, int global_i) throws IOException {

		String invokedMethodName = getVarName(ir, instruction.getUse(0));
		/*
		 * Handling "WALA assign" statement
		 */
		if(invokedMethodName != null && invokedMethodName.equalsIgnoreCase("WALA_assign")){

			this.processWALAAssignStatement(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut);
		}
		/*
		 * Handling "require" statement
		 */
		else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("require")){

			this.processRequireStatement(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, privOut, isMozReqOut);
		}
		/*
		 * Handling "Cu.import" /Cuimport statement
		 */
		else if (invokedMethodName != null && invokedMethodName.equalsIgnoreCase("Cuimport")){

			this.processCuimportStatement(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, privOut);
		}

		/*
		 * Handling "MozStub" statement
		 */
		else if (invokedMethodName != null && mozStub.isPrivilegeXPCOMStub(invokedMethodName)){

			this.processMozStubStatement(invokedMethodName, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, privOut, isMozReqOut);
		}

		/*
		 * Handling any Custom Defined Function Invocation Statement
		 */
		else
			global_i = this.processCustomFunctionInvocationStatement(currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, WAretOut, global_i);

		return global_i;
	}

	/*
	 * Handle any custom defined method invocation statement
	 */
	private int processCustomFunctionInvocationStatement(
			MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, BufferedWriter WAretOut, int global_i) throws IOException {

		String fact;		
		String currentMethodName; 

		int lValNum, rValNum;
		String vNumString;
		String calleeMethodFullName, calleeMethodName;  
		MethodNodeData callerNode;
		String variableDefiner;

		String callSiteID;
		CallSiteReference callSite;
		

		currentMethodName = currentMethodNode.type.toString();	
		callerNode = this.getNodeFromMethodName(currentMethodName);
		/*
		 * Get call site
		 */

		callSite = ((JavaScriptInvoke)instruction).getCallSite();
		Set<CGNode> targets = callGraph.getPossibleTargets(callGraph.getNode(callerNode.nodeID), callSite);

		if(targets.isEmpty()){
			/*
			 * The constructor is from template
			 */
			global_i = this.processCustomFunctionInvocationFromTemplate(ir, instruction, shortCurrentMethodName, bOut, global_i);
		}
		else{

			Iterator<CGNode> targetsIterator = targets.iterator() ;

			while(targetsIterator.hasNext()){
				CGNode target = targetsIterator.next();
				target.getGraphNodeId();
				calleeMethodFullName = target.getMethod().getDeclaringClass().getName().toString();

				/*
				 * Check for Javasciprt builtin functions
				 */				
				if(this.pbmObj.checkBuiltinMethod(calleeMethodFullName)){
					this.pbmObj.dumpDatalogFactsForBuiltinMethod(calleeMethodFullName, ir, instruction, shortCurrentMethodName, bOut);
					continue;
				}

				MethodNodeData calleeNode = this.getNodeFromMethodName(calleeMethodFullName);
				//haila
				//calleeMethodName = calleeMethodFullName.substring(calleeMethodFullName.lastIndexOf("/")+1);
				calleeMethodName = this.getMethodShortName(calleeNode);
				/*
				 * the body of this target has to be processed 
				 */

				global_i++;
				callSiteID = "i" + new Integer(global_i).toString() ;
				/*
				 * set the invoked function name  			
				 */
				vNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(0) +"_"+shortCurrentMethodName;
				fact = "actual("+ callSiteID+ ","+0+","+ vNumString +").\n";
				bOut.write(fact);
				String vNumFunctionName = vNumString; 				
				/*
				 * Setting parameters of the invoked function, param start from index 1
				 */
				int paramCount = ((JavaScriptInvoke)instruction).getNumberOfParameters();
				for (int paramIndex = 1; paramIndex< paramCount; paramIndex++){
					vNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(paramIndex) +"_"+shortCurrentMethodName;
					fact = "actual("+ callSiteID+ ","+ paramIndex +","+ vNumString +").\n";  
					bOut.write(fact);
				}

				/*
				 * ((JavaScriptInvoke)instruction).getNumberOfUses() returns the number of both params and lexicalRead
				 */
				int useCount = ((JavaScriptInvoke)instruction).getNumberOfUses();
				/*
				 * lexicalReadIndex is set to paramCount because the way getLexicalUse handles the array index  
				 */
				for (int lexicalReadIndex = paramCount; lexicalReadIndex< useCount; lexicalReadIndex++){

					String rVarName = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableName;
					variableDefiner = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableDefiner;

					if(!this.isKeyWord(rVarName)){
						lValNum = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).valueNumber;
						vNumString = this.vNumPrefix + "_" + "v"+ lValNum +"_"+shortCurrentMethodName; 
						fact = "actualLexicalRead("+ callSiteID+ ","+
						vNumString + ","+
						this.makeDatalogCompatibleString(rVarName) +").\n";  
						bOut.write(fact);          
					}

				}

				/*
				 * Setting return values of the invoked function
				 */
				int returnCount = ((JavaScriptInvoke)instruction).getNumberOfReturnValues();

				/*
				 * ((JavaScriptInvoke)instruction).getNumberOfDefs() returns the number of returns, exceptions and lexicalwrites
				 * the index is adjusted appropriately in getLexicalDef()
				 * return+1 for skipping the exception vNum
				 */
				int defCount = ((JavaScriptInvoke)instruction).getNumberOfDefs();

				for (int lexicalWriteIndex = returnCount+1; lexicalWriteIndex< defCount; lexicalWriteIndex++){

					if(((JavaScriptInvoke)instruction).isLexicalDef(lexicalWriteIndex)){

						String lVarName = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableName;
						variableDefiner = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableDefiner;

						rValNum = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).valueNumber;
						vNumString = this.vNumPrefix + "_"+"v"+ rValNum +"_"+shortCurrentMethodName;
						fact = "actualLexicalWrite("+ callSiteID+ ","
						+ this.makeDatalogCompatibleString(lVarName) + "," 
						+ vNumString 
						+").\n";  

						bOut.write(fact);          

					}
				}
				/*
				 * setting the return value
				 */
				vNumString = this.vNumPrefix + "_" + "v"+ instruction.getDef() +"_"+ shortCurrentMethodName; 
				fact = "callRet("+ callSiteID+ ","+ vNumString +").\n";
				bOut.write(fact);	

				/*
				 *  for WALAappend function spit out the function name and ret vNum
				 */
                if(this.vNumPrefix.equals("true"))
                	WAretOut.write(vNumFunctionName + ","+vNumString+"\n"); 

			}// end of while
		}
		return global_i;
	}
	
	private int processCustomFunctionInvocationFromTemplate(IR ir,
			SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, int global_i) throws IOException {
	
		String fact;		
		
		String vNumString;
		String callSiteID;
		
		global_i++;
		callSiteID = "i" + new Integer(global_i).toString() ;
		/*
		 * set the invoked function name  			
		 */
		vNumString = this.vNumPrefix + "_" + "v"+ instruction.getUse(0) +"_"+shortCurrentMethodName;
		fact = "actual("+ callSiteID+ ","+0+","+ vNumString +").\n";
		bOut.write(fact);
		
		/*
		 * setting the return value
		 */
		vNumString = this.vNumPrefix + "_" + "v"+ instruction.getDef() +"_"+ shortCurrentMethodName; 
		fact = "callRet("+ callSiteID+ ","+ vNumString +").\n";
		bOut.write(fact);
		
		return global_i;
	}

	/*
	 * Handling MozStub statement
	 */

	private void processMozStubStatement(
			String invokedMethodName, MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, BufferedWriter privOut, BufferedWriter isMozReqOut) throws IOException {

		String fact;		
		String vNumString;
		String heapObjectName;

		vNumString = this.vNumPrefix + "_" +"v" +  instruction.getDef() + "_" + shortCurrentMethodName;
		heapObjectName = "h_"+ invokedMethodName + "_"+ instruction.getDef() +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;

		fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
		System.out.println(fact);
		bOut.write(fact);
		
		/*
		 * spit for overprivileged info		   
		 */
		fact = "isMoz("+ vNumString +","+ this.makeDatalogCompatibleString(invokedMethodName)+").\n";	
		System.out.println(fact);
		bOut.write(fact);
		
		//isMozReqOut.write(fact); no need to spit out, already taken care of by privileged facts 
		
		String mozObjectName = getVarName(ir, instruction.getDef());
		if(mozObjectName != null)
		this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, mozObjectName, vNumString, heapObjectName);

		fact = "isPrivileged(" 
			+ heapObjectName + ","
			+ mozStub.getPrivilegeForStub(invokedMethodName)
			+ ").\n";


		System.out.println(fact);
		bOut.write(fact);

		fact = "idIsPrivileged(" 
			+ vNumString + ","
			+  mozStub.getPrivilegeForStub(invokedMethodName)
			+ ").\n";

		System.out.println(fact);
		bOut.write(fact);

		// dump to privFile

		fact = "(" 
			+ "h__"
			+ "v" + instruction.getDef()+"__"
			+ shortCurrentMethodName + "#" 
			+ this.getSrcLineNumForInstruction(ir, instruction)
			+ ","+ mozStub.getPrivilegeForStub(invokedMethodName)
			+ ").\n";

		System.out.println(fact);
		privOut.write(fact);
		

		/*
		 * Consult the template file and generate Datalog Facts for the property tree for MozStub
		 * for the module being imported All capabilities are considered as tainted in stead of privileged
		 */
		GenerateFactsForXPCOMTemplate gfXObj = new GenerateFactsForXPCOMTemplate(this.XPCOMTemplateDir, this.mozStub, heapObjectName, invokedMethodName, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, privOut); 
		gfXObj.dumpDatalogFacts(this.outputDirName + File.separator + "heapMapForTemplate");
		gfXObj.dumpvNumToRandomMapping(this.outputDirName + File.separator + "map");
		
	}

	/*
	 * Handling "Cu.import" /Cuimport statement
	 */
	private void processCuimportStatement( MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, BufferedWriter privOut) throws IOException {

		String fact;		
		String vNumString;
		String heapObjectName;

		String jsmPath = getVarName( ir, instruction.getUse(2));
		String jsmObject = getVarName( ir, instruction.getUse(3));

		String jsmName = jsmPath.substring(jsmPath.lastIndexOf("/"), jsmPath.lastIndexOf('.')) ;	   

		System.out.println("Cuimport"+ jsmName );
		vNumString = this.vNumPrefix + "_" + "v" +  instruction.getDef() + "_" + shortCurrentMethodName;
		jsmName = this.makeDatalogCompatibleString(jsmName);


		heapObjectName = "h_file" + "_"+ instruction.getDef() +"_"+ jsmName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;

		fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
		System.out.println(fact);
		bOut.write(fact);


		if(jsmPath.equalsIgnoreCase("resource://gre/modules/NetUtil.jsm")){

			fact = "isPrivileged(" 
				+ heapObjectName + ","
				+ "netUtil"
				+ ").\n";


			System.out.println(fact);
			bOut.write(fact);

			fact = "idIsPrivileged(" 
				+ vNumString + ","
				+ "netUtil"
				+ ").\n";

			System.out.println(fact);
			bOut.write(fact);

		}

	}

	/*
	 * Handling require statement
	 */

	private void processRequireStatement(MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, BufferedWriter privOut, BufferedWriter isMozReqOut) throws IOException {


		String fact;		
		String vNumString;
		String heapObjectName;

		String privilege;

		String importedModule = getVarName(ir, instruction.getUse(2));
		System.out.println("REQUIRED "+ importedModule );
		//importedModule = this.makeDatalogCompatibleString(importedModule);

		vNumString = this.vNumPrefix + "_" + "v" +  instruction.getDef() + "_" + shortCurrentMethodName;

		heapObjectName = "h_req" + "_"+ instruction.getDef() +"_"+ this.makeDatalogCompatibleString(importedModule) +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;

		fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
		System.out.println(fact);
		bOut.write(fact);

		/*
		 * spit for overprivileged info		   
		 */
		fact = "isReq("+ vNumString +","+ this.makeDatalogCompatibleString(importedModule)+").\n";	
		System.out.println(fact);
		bOut.write(fact);
		
		isMozReqOut.write(fact);
/*		
		// TODO: temporary solution, make it more general
		
		String objectName = getVarName(ir, instruction.getDef());
		this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, objectName, vNumString, heapObjectName);
	*/	

		String reqObjectName = getVarName(ir, instruction.getDef());
		if(reqObjectName != null)
		this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, reqObjectName, vNumString, heapObjectName);


		if(importedModule.equalsIgnoreCase("chrome")){

			//TODO: tainted/privileged ??
			privilege = this.makeDatalogCompatibleString(importedModule); 
			fact = "isPrivileged(" 
				+ heapObjectName + ","
				+ privilege
				+ ").\n";

			System.out.println(fact);
			bOut.write(fact);						
			

			fact = "idIsPrivileged(" 
				+ vNumString + ","
				+ privilege
				+ ").\n";

			System.out.println(fact);
			bOut.write(fact);


			// dump to privFile

			fact = "(" 
				+ "h__"
				+ "v" + instruction.getDef()+"__"
				+ shortCurrentMethodName + "#" 
				+ this.getSrcLineNumForInstruction(ir, instruction)
				+ ",chrome"
				+ ").\n";

			System.out.println(fact);
			privOut.write(fact);
		
			
			GenerateFactsForChromeTemplate gfchObj = new GenerateFactsForChromeTemplate(this.templateDir, heapObjectName, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut); 
			gfchObj.dumpDatalogFacts(this.outputDirName + File.separator + "heapMapForTemplate");
			gfchObj.dumpvNumToRandomMapping(this.outputDirName + File.separator + "map");
			return;
		}  

		/*
		 * Consult the template file and generate Datalog Facts
		 * for the module being imported All capabilities are considered as tainted in stead of privileged
		 */
		GenerateFactsForTemplate gfObj = new GenerateFactsForTemplate(this.templateDir, heapObjectName, importedModule, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut); 
		gfObj.dumpDatalogFacts(this.outputDirName + File.separator + "heapMapForTemplate");
		gfObj.dumpvNumToRandomMapping(this.outputDirName + File.separator + "map");

	}

	/*
	 * Handling WALA_Assign statement
	 */



	private void processWALAAssignStatement( MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut) throws IOException {

		String fact;	

		String rVNumString = this.vNumPrefix + "_" +"v" + instruction.getUse(2)+ "_" + shortCurrentMethodName;
		String lVNumString = this.vNumPrefix + "_" +"v" + instruction.getDef()+ "_" + shortCurrentMethodName;

		String lVarName = getVarName(ir, instruction.getDef());
		this.createWALAAssignMapentry(currentMethodNode.nodeID, lVarName, lVNumString);
		System.out.println("WALA_Assign "+ rVNumString );

		fact = "assign("+ lVNumString +","+ rVNumString+").\n";	
		System.out.println(fact);
		bOut.write(fact);

	}

	/*
	 * Analyze Custom Object Construction Instruction
	 * Construct an object of a type that has been already declared, almost all the cases the type will be a function
	 * @TODO : figure out object constructor name
	 */

	private int processCustomObjectConstruction(
			String constructorName,	MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, int  global_i) throws IOException {

		int lValNum, rValNum;

		String fact;		
		String vNumString;
		String heapObjectName;
		String currentMethodName; 

		String variableDefiner;

		String callSiteID;
		CallSiteReference callSite;

		currentMethodName = currentMethodNode.type.toString();	

		String objectConstructorSignature;
		String constructorMethodFullName, constructorMethodName;
		MethodNodeData callerNode; 

		callerNode = this.getNodeFromMethodName(currentMethodName);

		/*
		 * Get call site
		 */

		callSite = ((JavaScriptInvoke)instruction).getCallSite();
		Set<CGNode> targets = callGraph.getPossibleTargets(callGraph.getNode(callerNode.nodeID), callSite);

		if(targets.isEmpty()){
			/*
			 * The constructor is from template
			 */
			global_i = this.processCustomObjectFromTemplate( constructorName, currentMethodNode, ir, instruction, shortCurrentMethodName, bOut, global_i);
		}
		else{
			Iterator<CGNode> targetsIterator = targets.iterator() ;

			while(targetsIterator.hasNext()){

				CGNode target =  targetsIterator.next();
				objectConstructorSignature = target.getMethod().toString();
				constructorMethodFullName = objectConstructorSignature.substring(objectConstructorSignature.indexOf(",")+1, objectConstructorSignature.indexOf(">"));
				MethodNodeData constructorNode = this.getNodeFromMethodName(constructorMethodFullName);

				/*
				 * the body of this target has to be processed 
				 */

				//haila
				//constructorMethodName = constructorMethodFullName.substring(constructorMethodFullName.lastIndexOf("/")+1);

				constructorMethodName = this.getMethodShortName(constructorNode);
				vNumString = this.vNumPrefix + "_" +"v"+ instruction.getDef()+"_"+shortCurrentMethodName;

				heapObjectName = "h_obj" + "_"+ constructorMethodName+"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
				
				String constructedObjectName = this.getVarName(ir, instruction.getDef());
				String constructedObjectNum = new Integer(instruction.getDef()).toString();
				if(constructedObjectName == null){
					constructedObjectName = constructedObjectNum;
				}
				
				/*
				 * The else case might be a problem. but can not think of any other technique as of now
				 */
				
				this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, constructedObjectName, vNumString, heapObjectName);

			

				fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
				bOut.write(fact);				

				/*
				 * dump Prototype Fact over here, instead of inferring it through datalog rule
				 */

				fact = "prototypeOf("+ heapObjectName + ","+ constructorNode.prototypeHeapObject+").\n";	
				System.out.println(fact);
				bOut.write(fact);   	 						

				global_i++;
				callSiteID = "i" + new Integer(global_i).toString() ;
				/*
				 * Setting the callee function name
				 */
				vNumString = this.vNumPrefix + "_" +"v"+ instruction.getUse(0)+"_"+shortCurrentMethodName;
				fact = "actual("+ callSiteID + ","+0+","+ vNumString +").\n";
				bOut.write(fact);
				/*
				 * Setting the 'this' parameter of the function
				 */
				vNumString = this.vNumPrefix + "_" +"v"+ instruction.getDef()+"_"+shortCurrentMethodName;
				fact = "actual("+ callSiteID + ","+1+","+ vNumString +").\n";
				bOut.write(fact);

				/*
				 * Setting parameters of the invoked function, param start from index v2, v1 set to this
				 */
				int paramCount = ((JavaScriptInvoke)instruction).getNumberOfParameters();
				for (int paramIndex = 1; paramIndex< paramCount; paramIndex++){
					vNumString = this.vNumPrefix + "_" +"v"+ instruction.getUse(paramIndex)+"_"+shortCurrentMethodName;
					fact = "actual("+ callSiteID+ ","+ (paramIndex+1) +","+ vNumString +").\n";  
					bOut.write(fact);
				}

				/*
				 * ((JavaScriptInvoke)instruction).getNumberOfUses() returns the number of both params and lexicalRead
				 */
				int useCount = ((JavaScriptInvoke)instruction).getNumberOfUses();
				/*
				 * lexicalReadIndex is set to paramCount because the way getLexicalUse handles the array index  
				 */
				for (int lexicalReadIndex = paramCount; lexicalReadIndex< useCount; lexicalReadIndex++){

					String rVarName = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableName;
					variableDefiner = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).variableDefiner;

					if(!this.isKeyWord(rVarName)){
						lValNum = ((JavaScriptInvoke)instruction).getLexicalUse(lexicalReadIndex).valueNumber;
						vNumString = this.vNumPrefix + "_" +"v"+ lValNum +"_"+shortCurrentMethodName;
						fact = "actualLexicalRead("+ callSiteID+ ","
						+ vNumString +","
						+ this.makeDatalogCompatibleString(rVarName) +").\n";  
						bOut.write(fact);          
					}

				}

				//////////////////////////////////////////////////////////////////////////

				/*
				 * Setting no of return values of the invoked function
				 */
				int returnCount = ((JavaScriptInvoke)instruction).getNumberOfReturnValues();

				/*
				 * ((JavaScriptInvoke)instruction).getNumberOfDefs() returns the number of returns, exceptions and lexicalwrites
				 * the index is adjusted appropriately in getLexicalDef()
				 * return+1 for skipping the exception vNum
				 */
				int defCount = ((JavaScriptInvoke)instruction).getNumberOfDefs();
				instruction.getDef();

				for (int lexicalWriteIndex = returnCount+1; lexicalWriteIndex< defCount; lexicalWriteIndex++){

					if(((JavaScriptInvoke)instruction).isLexicalDef(lexicalWriteIndex)){

						String lVarName = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableName;
						variableDefiner = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).variableDefiner;

						rValNum = ((JavaScriptInvoke)instruction).getLexicalDef(lexicalWriteIndex).valueNumber;
						vNumString = this.vNumPrefix + "_" +"v"+ rValNum +"_"+shortCurrentMethodName;
						fact = "actualLexicalWrite("+ callSiteID+ ","
						+ this.makeDatalogCompatibleString(lVarName) + ","
						+ vNumString +","
						+").\n";  
						bOut.write(fact);          
					}
				}
				

			}// end of while loop

		}
		return global_i;
     
	}

	private int processCustomObjectFromTemplate(String constructorMethodName, MethodNodeData currentMethodNode, IR ir, SSAInstruction instruction, String shortCurrentMethodName, BufferedWriter bOut, int  global_i) throws IOException {
		
		String fact;		
		String vNumString;
		String heapObjectName;
		
		String callSiteID;
		
		
		vNumString = this.vNumPrefix + "_" +"v"+ instruction.getDef()+"_"+shortCurrentMethodName;

		heapObjectName = "h_obj" + "_"+ constructorMethodName+"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
		
		String constructedObjectName = this.getVarName(ir, instruction.getDef());
		String constructedObjectNum = new Integer(instruction.getDef()).toString();
		if(constructedObjectName == null){
			constructedObjectName = constructedObjectNum;
		}
		
		/*
		 * The if case might be a problem. but can not think of any other technique as of now
		 */
		
		this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, constructedObjectName, vNumString, heapObjectName);
		
		fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n";	
		bOut.write(fact);				
		
		global_i++;
		callSiteID = "i" + new Integer(global_i).toString() ;

		/*
		 * Setting the callee function name
		 */
		vNumString = this.vNumPrefix + "_" +"v"+ instruction.getUse(0)+"_"+shortCurrentMethodName;
		fact = "actual("+ callSiteID + ","+0+","+ vNumString +").\n";
		bOut.write(fact);

		/*
		 * Setting the 'this' parameter of the function
		 */
		vNumString = this.vNumPrefix + "_" +"v"+ instruction.getDef()+"_"+shortCurrentMethodName;
		fact = "actual("+ callSiteID + ","+1+","+ vNumString +").\n";
		bOut.write(fact);

		return global_i;
		
	}

	/*
	 * Analyze Function construction Instruction
	 */
	private void processFunctionObjectConstruction( MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut) throws IOException {

		String fact;

		String vNumString;
		String heapObjectName;
		String currentMethodName; 

		String constructorMethodFullName, constructorMethodName;
		MethodNodeData callerNode; 

		CallSiteReference callSite;

		currentMethodName = currentMethodNode.type.toString();
		callerNode = this.getNodeFromMethodName(currentMethodName);

		/*
		 * Get call site
		 */

		callSite = ((JavaScriptInvoke)instruction).getCallSite();
		Set<CGNode> targets = callGraph.getPossibleTargets(callGraph.getNode(callerNode.nodeID), callSite);

		Iterator<CGNode> targetsIterator = targets.iterator() ;

		while(targetsIterator.hasNext()){

			CGNode target =  targetsIterator.next();
			/*
			 * signature always start with ctor node in this case
			 */

			String constructorSignature = target.getMethod().toString();
			constructorMethodFullName = constructorSignature.substring(constructorSignature.lastIndexOf("(")+1, constructorSignature.lastIndexOf(")")); 

			MethodNodeData constructorNode = this.getNodeFromMethodName(constructorMethodFullName);
			/*
			 * constructor node null means the function is constructed but is never called,  so need to be modeled
			 */
			if(constructorNode != null){
				//haila
				//constructorMethodName = constructorMethodFullName.substring(constructorMethodFullName.lastIndexOf("/")+1);
				constructorMethodName = this.getMethodShortName(constructorNode); 

				/*
				 * TODO: This loop should be removed from here. This was probably written to facilitate context-sensitivity. 
				 *      i.e. to create separate heap object for for different invocation. But the fact produced here does not have to to do anything with context-sensivity.
				 *      Because, function definition/declaration is done once; there will be one statement for function object construction and that time the invocation count is not known
				 *      . Heap object creation in Context-sensitivity has to be taken care of in a different way. 
				 */

				heapObjectName = "h_func_" + "_"+constructorMethodName+"_"+shortCurrentMethodName + "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
				//constructorNode;
				String prototypeObjectName = "p_func_" + "_"+constructorMethodName+"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
				vNumString = this.vNumPrefix + "_" +"v"+ instruction.getDef()+"_"+shortCurrentMethodName; 

				this.storeMethodParentAndHeapObjectMapping( constructorNode.nodeID, heapObjectName, prototypeObjectName, currentMethodNode.nodeID);
				
				String constructedObjectName = this.getVarName(ir, instruction.getDef());
				String constructedObjectNum = new Integer(instruction.getDef()).toString();
				if(constructedObjectName == null){
					constructedObjectName = constructedObjectNum;
				}
				
				/*
				 * The if case might be a problem. but can not think of any other technique as of now
				 */
				
				this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, constructedObjectName, vNumString, heapObjectName);				

				fact = "ptsTo("+ vNumString +","+ heapObjectName +").\n";	
				bOut.write(fact);

				fact = "heapPtsTo("+ heapObjectName +", prototype, "+prototypeObjectName+ ").\n";  
				bOut.write(fact);

				/*
				 * check whether the constructorMethod was invoked at any point in the code
				 * otherwise there is no point of spitting out facts for its parameter and return value
				 */
				String paramName;

				if( constructorNode != null){
					for (int paramIndex = 1; paramIndex< constructorNode.noOfParameters; paramIndex++){

						vNumString = this.vNumPrefix + "_" + "v"+(paramIndex+1)+"_"+ constructorMethodName;
						if(paramIndex > 1){
							/*
							 * real parameters start from index 3 i.e. v3 for non-main method
							 * Assumption: paramName will never be null	
							 */

							paramName = this.getVarName( callGraph.getNode(constructorNode.nodeID).getIR(), paramIndex+1);

							this.storeIdentifierToHeapMapping(constructorNode.nodeID, paramName, vNumString, "paramNull");
						}

						fact = "formal("+ heapObjectName+ ","+ paramIndex +","+ vNumString + ").\n";  
						bOut.write(fact);
					}

					for(int returnIndex=0; returnIndex< constructorNode.returnVNums.size(); returnIndex++){

						vNumString = this.vNumPrefix + "_" + "v" + constructorNode.returnVNums.get(returnIndex) +"_"+ constructorMethodName; 
						fact = "methodRet("+ heapObjectName +","+ vNumString  + ").\n";  
						bOut.write(fact);  

					}	 
				}
			} 	 
		}  		
	}

	/*
	 * Analyze Primitive Object i.e. String, Boolean,Date construction Instruction
	 */
	private void processPrimitiveObjectConstruction(String constructorName, MethodNodeData currentMethodNode,
			IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut) throws IOException {

		String fact;

		String vNumString;
		String heapObjectName;

		String primObjectName = this.getVarName(ir, instruction.getDef());
		String primObjectNum = new Integer(instruction.getDef()).toString();
		if(primObjectName == null){
			primObjectName = primObjectNum;
		}
		
		vNumString = this.vNumPrefix + "_" +"v"+ instruction.getDef()+"_"+shortCurrentMethodName;

		heapObjectName = "h_"+ constructorName+"_" + instruction.getDef() +"_"+primObjectName +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;    
		this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, primObjectName, vNumString, heapObjectName);

		fact = "ptsTo("+ vNumString +","+ heapObjectName+").\n"; 
		bOut.write(fact);


	}

	/*
	 * Handling an Object Literal construction Instruction
	 */
	private void processObjectLiteralConstruction( MethodNodeData currentMethodNode, IR ir, SSAInstruction instruction,
			String shortCurrentMethodName, BufferedWriter bOut) throws IOException {

		String fact;

		String vNumString;
		String heapObjectName;

		String objectName = this.getVarName(ir,instruction.getDef());
		String tempName ="";
		String objectNum = new Integer(instruction.getDef()).toString();

		if(objectName == null){
			objectName = objectNum;
		}  
		else{
			tempName	= objectName; 
			objectName = objectName + "_"+objectNum;
		}


		heapObjectName = "h_obj" + "_" + objectName +"_"+shortCurrentMethodName+"_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
		vNumString = this.vNumPrefix + "_" + "v"+ instruction.getDef()+"_"+shortCurrentMethodName; 
		//store this info in the methodNode
		this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, tempName, vNumString, heapObjectName);

		fact = "ptsTo(" + vNumString +","+ heapObjectName+").\n"; 
		bOut.write(fact);

		//TODO take care of this. for privileged global
		if(this.privilegedObjectsContain(tempName)){
			fact = "isPrivileged("+ heapObjectName + ").\n";
			bOut.write(fact);	

			fact = "idIsPrivileged(" 
				+ vNumString + ","
				+ "chrome"
				+ ").\n";

			System.out.println(fact);
			bOut.write(fact);
		}
	}

	/*
	 * Analyze BinaryOP construction Instruction
	 */
	private void processSSABinaryOPInstruction(IR ir,SSAInstruction instruction) {

		CheckBinaryOpInstruction cObj= new  CheckBinaryOpInstruction((SSABinaryOpInstruction) instruction);   

		if( cObj.isAddOperator() && !((SSABinaryOpInstruction)instruction).mayBeIntegerOp()){  
			String operand1 = this.getVarName(ir, instruction.getUse(0));
			String operand2 = this.getVarName(ir, instruction.getUse(1));


			if((operand1 != null && !isNumeric(operand1))
					|| (operand2 != null && !isNumeric(operand2))){

				//concatenates string
			}
		}
		//check if any of the arg has a string val

	}

	/*
	 * Analyze Phi Instruction
	 */

	private void processSSAPhiInstruction( MethodNodeData currentMethodNode, IR ir, SSAInstruction instruction, 
			String shortCurrentMethodName, HashMap<Integer, String> vNumOfIdentifierInParentScope,
			BufferedWriter bOut) throws IOException {

		String fact;
		String lValNumString, rValNumString; 
		int lValNum, rValNum;

		int paramIndex;

		lValNum = ((SSAPhiInstruction)instruction).getDef();
		lValNumString = this.vNumPrefix + "_" + "v"+ lValNum +"_"+shortCurrentMethodName;
		for( paramIndex = 0; paramIndex < instruction.getNumberOfUses(); paramIndex++){

			rValNum = instruction.getUse(paramIndex);
			rValNumString = this.vNumPrefix + "_" + "v"+ rValNum +"_"+shortCurrentMethodName;
			fact = "assign("+ lValNumString +","+ rValNumString +").\n";            	
			bOut.write(fact); 

			if(vNumOfIdentifierInParentScope.containsKey(new Integer(rValNum))){
				String lVarName = vNumOfIdentifierInParentScope.get(new Integer(rValNum));  
				vNumOfIdentifierInParentScope.put(new Integer(lValNum), lVarName);
				fact= "formalLexicalWrite("+ currentMethodNode.methodHeapObject +","+
				lVarName+ ","+
				lValNumString +
				").\n";
				bOut.write(fact);  
			}

		}
		/*
		 * Take the name from 2nd argument of phi instruction, the 1st one in general corrs. to prototype one
		 */
		String secondArgName = getVarName(ir, instruction.getUse(1));
		if(secondArgName == null)
			secondArgName = currentMethodNode.vNumToIdentifierMapping.get(new Integer(instruction.getUse(1)));
		currentMethodNode.vNumToIdentifierMapping.put(new Integer(lValNum), secondArgName);

	}


	/*
	 * Analyze AstLesicalWrite Instruction
	 */

	private void processAstLexicalWriteInstruction( MethodNodeData currentMethodNode, IR ir, SSAInstruction instruction,
			String shortCurrentMethodName, HashMap<Integer, String> vNumOfIdentifierInParentScope,
			BufferedWriter bOut) throws IOException {


		String  fact;
		int rValNum;
		String 	vNumStringInDefiner; 
		String variableDefiner;

		rValNum = ((AstLexicalWrite)instruction).getAccess(0).valueNumber; // assuming only one assignment
		String lVarName = ((AstLexicalWrite)instruction).getAccess(0).variableName;
		variableDefiner = ((AstLexicalWrite)instruction).getAccess(0).variableDefiner;
		//String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
		String rValNumString = this.vNumPrefix + "_" + "v"+ rValNum +"_"+shortCurrentMethodName;

		/*
		 * generate facts only for the methods that are defined and called
		 * i.e. no need to generate these facts for the main (id >=2 && id <=62 ) method 
		 */
		if (currentMethodNode.nodeID > 62){
			//this check may be redundant
			fact = "formalLexicalWrite("+ currentMethodNode.methodHeapObject +","+
			this.makeDatalogCompatibleString(lVarName)+ ","+
			rValNumString +
			").\n";
			bOut.write(fact);
		}
		vNumOfIdentifierInParentScope.put(new Integer(rValNum), lVarName);

		//TODO
		/*
		 * for a varName in the parent/global scope get the vNum from the methodNodeData and generate assign fact
		 * lexicalwrite instruction is not generated for writing into a locally defined variable, 
		 * so whenever a lexicalwrite instruction appears,
		 *      check in the current method node whether any entry have been created for the identifier,
		 *           in that case remove it
		 *   Had there been a collision, say a local variable has the same name as something in parent scope, 
		 *      there would not be lexicalread/lexical write instruction, since the one from parent scope get overwritten by locally declared one          
		 */
		if(variableDefiner == null){
			System.out.println("probably in global scope");
			//TODO change this one if required 
			this.codeBodyNodesInCG.get(0); // node 2 is stored at 0 index 
		}
		else{
			MethodNodeData definerNode = this.getNodeFromMethodName(variableDefiner);
			Pair<String, String> vNumHeapObjPair = definerNode.identifierToHeapMapping.get(lVarName);

			if(vNumHeapObjPair != null) {
				vNumStringInDefiner = vNumHeapObjPair.fst;
				fact = "assign("+ vNumStringInDefiner +","+ rValNumString+").\n";            	
				bOut.write(fact);  
				/*
				 * Change in the current method node
				 */
				this.removeMapEntryInCurrentMethodNode(currentMethodNode.nodeID, lVarName);
			}  
			else{
				/*
				 * this case corresponds to some x, that have in defined in parent scope as a normal var pointing to a primitive value
				 * therefore no entry was created in the methodNode
				 * But at this point x has been updated in some child node. so we are creating the entry in the definer parent node, 
				 *  the motive is x might now point to an heap object now and later accessed in some other method,
				 *  If we don't create the entry now in the definer method, later we wont be able to create appropriate assign fact upon x being accessed
				 */
				this.createMapEntryInDefinerNode(definerNode.nodeID, lVarName, rValNumString);

			}
		}

	}

	/*
	 * Analyze AstLesicalRead Instruction
	 */

	private void processAstLexicalReadInstruction( MethodNodeData currentMethodNode, IR ir,
			SSAInstruction instruction, String shortCurrentMethodName,
			HashMap<Integer, String> vNumOfIdentifierInParentScope,
			BufferedWriter bOut) throws IOException {

		String  fact;
		int lValNum;
		String vNumString;

		String 	vNumStringInDefiner; 
		String variableDefiner;

		int numRead = ((AstLexicalRead)instruction).getAccessCount();

		String rVarName;
		for(int r=0;r<numRead;r++){

			rVarName = ((AstLexicalRead)instruction).getAccess(r).variableName;
			lValNum = ((AstLexicalRead)instruction).getAccess(r).valueNumber;
			variableDefiner = ((AstLexicalRead)instruction).getAccess(r).variableDefiner;
			vNumString = this.vNumPrefix + "_" + "v"+ lValNum +"_"+shortCurrentMethodName;
			/*
			 * generate facts only for the methods that are defined and called
			 * i.e. no need to generate these facts for the main (id >=2 && id <=62 ) method 
			 */
			if(!this.isKeyWord(rVarName)){

				vNumOfIdentifierInParentScope.put(new Integer(lValNum), rVarName);

				if(currentMethodNode.nodeID > 62 ){
					/**
					 * However I think there would not be any lexicalRead instruction with non-keyword string to analyze in main method
					 * so these nodeID checking may be redundant
					 */

					fact= "formalLexicalRead("+ currentMethodNode.methodHeapObject +","
					+vNumString +","
					+this.makeDatalogCompatibleString(rVarName) 
					+").\n";
					bOut.write(fact);  

				}

				/*
				 * for a varName in the parent/global scope get the vNum from the methodNodeData and generate assign fact
				 */
				if(variableDefiner == null){
					System.out.println("probably in global scope");
					//TODO change this one if required 
					this.codeBodyNodesInCG.get(0); // node 2 is stored at 0 index 
				}
				else{
					MethodNodeData definerNode = this.getNodeFromMethodName(variableDefiner);
					Pair<String, String> vNumHeapObjPair = definerNode.identifierToHeapMapping.get(rVarName);
					/*
					 * handing instruction self=this; in parent node and later using self in child node
					 */
					vNumStringInDefiner = definerNode.WALAAssignIdToVNumMapping.get(rVarName);

					if(vNumHeapObjPair != null) {
						vNumStringInDefiner = vNumHeapObjPair.fst;
						fact = "assign("+ vNumString  +","+vNumStringInDefiner +").\n";            	
						bOut.write(fact);  
					}

					else if( vNumStringInDefiner != null){
						fact = "assign("+ vNumString +","+vNumStringInDefiner +").\n";            	
						bOut.write(fact); 
					}
				}
			}  

		}     

	}

	/*
	 * Analyze Array Write Instruction
	 */

	private void processJavaScriptPropertyWriteInstruction(IR ir,
			SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut) throws IOException {


		String field, fact;
		int lValNum, rValNum;
		String lValNumString, rValNumString; 
		int ref, val;

		int objectRef, memberRef;


		rValNum = ((JavaScriptPropertyWrite)instruction).getValue();
		memberRef = ((JavaScriptPropertyWrite)instruction).getMemberRef();
		lValNum = objectRef = ((JavaScriptPropertyWrite)instruction).getObjectRef();

		lValNumString =	this.vNumPrefix + "_" + "v"+ lValNum+"_"+shortCurrentMethodName ;
		rValNumString = this.vNumPrefix + "_" + "v"+ rValNum+"_"+shortCurrentMethodName ;
		//String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
		/* if it is sure that index is a integer value, generate the array facts
		 * otherwise it is hard to determine, since the vNum corresponds to a string which is actually a parameter of a function but carries integer value
		 * 
		 */
		String arrayIndex = this.getVarName(ir, memberRef);
		if(arrayIndex!=null && isNumeric(arrayIndex)){

			//fact= "arrayStore(v"+ lValNum+"_"+shortCurrentMethodName +","+ memberRef+",v"+ rValNum +"_"+shortCurrentMethodName+").\n";
			fact = "arrayStore("+ lValNumString +", "+ memberRef+", "+ rValNumString +").\n";
			bOut.write(fact);
		}

		else if ( this.isStringconstant(ir, instruction, memberRef)){

			field = arrayIndex;
			//fact= "store(v"+ lValNum+"_"+shortCurrentMethodName +","+field.toLowerCase()+",v"+ rValNum +"_"+shortCurrentMethodName+").\n";
			fact = "store("+ lValNumString +", "+ this.makeDatalogCompatibleString(field)+", "+ rValNumString +").\n";
			bOut.write(fact);
		}
		else{
			/* the string corrs. to vNum i.e memberRef is a variable (either local/global/parameter), 
			 *the value of the variable can not be determined without doing a context+flow sensitive analysis
			 */
			//bit hack
			String specialDyn = "specialDyn";
			fact = "store("+ lValNumString +", "+ specialDyn+", "+ rValNumString +").\n";
			bOut.write(fact);
		}

	}

	/*
	 * Analyze Array Read Instruction
	 */

	private void processJavaScriptPropertyReadInstruction(IR ir,
			SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut) throws IOException {

		String field, fact;
		int lValNum, rValNum;
		String lValNumString, rValNumString; 

		int objectRef, memberRef;
		int result;

		lValNum = result = instruction.getDef();
		memberRef = ((JavaScriptPropertyRead)instruction).getMemberRef();
		rValNum = objectRef = ((JavaScriptPropertyRead)instruction).getObjectRef();

		lValNumString =	this.vNumPrefix + "_" + "v"+ lValNum+"_"+shortCurrentMethodName ;
		rValNumString = this.vNumPrefix + "_" + "v"+ rValNum+"_"+shortCurrentMethodName ;

		//String shortCurrentMethodName = this.getMethodShortName(currentMethodNode) ;
		/* if it is sure that index is a integer value, generate the array facts
		 * otherwise it is hard to determine, since the vNum corresponds to a string which is actually a parameter of a function but carries integer value
		 * 
		 */
		String arrayIndex = this.getVarName(ir, memberRef);
		if(arrayIndex!=null && isNumeric(arrayIndex)){
			//fact= "arrayLoad(v"+ lValNum+"_"+shortCurrentMethodName +",v"+ rValNum +"_"+shortCurrentMethodName+","+ memberRef+").\n";
			fact= "arrayLoad("+ lValNumString +", "+ rValNumString +", "+ memberRef +").\n";
			bOut.write(fact);  
		}

		else if ( this.isStringconstant(ir, instruction, memberRef)){

			field = arrayIndex;
			//fact= "load(v"+ lValNum+"_"+shortCurrentMethodName +",v"+ rValNum +"_"+shortCurrentMethodName+","+field.toLowerCase()+").\n";
			fact= "load("+ lValNumString +", "+ rValNumString +", "+ this.makeDatalogCompatibleString(field)+").\n";
			bOut.write(fact);  
		}
		else{
			/* the string corrs. to vNum i.e memberRef is a variable (either local/global/parameter), 
			 *the value of the variable can not be determined without doing a context+flow sensitive analysis
			 */
			String specialDyn = "specialDyn";
			fact = "load("+ lValNumString +", "+ specialDyn+", "+ rValNumString +").\n";
			bOut.write(fact);
		}



	}

	/*
	 * Analyze Object property access Instruction
	 */
	private void processSSAGetInstruction( MethodNodeData currentMethodNode, IR ir, SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut, BufferedWriter privOut, BufferedWriter WAparentOut, BufferedWriter WAMapOut) throws IOException {


		String field, fact;
		String lValNumString, rValNumString; 
		int lValNum, rValNum;
		int ref, val;

		field = ((SSAGetInstruction) instruction).getDeclaredField().getName().toString();
		rValNum = ref = ((SSAGetInstruction) instruction).getRef();
		lValNum = val = ((SSAGetInstruction) instruction).getDef();

		lValNumString =	this.vNumPrefix + "_" + "v"+ lValNum+"_"+shortCurrentMethodName ;
		rValNumString = this.vNumPrefix + "_" + "v"+ rValNum+"_"+shortCurrentMethodName ;

		fact= "load("+ lValNumString +", "+ rValNumString +", "+ this.makeDatalogCompatibleString(field)+").\n";
		bOut.write(fact);  

		String lVarName = getVarName(ir, lValNum);
		if (lVarName != null){
			this.storeIdentifierToHeapMapping(currentMethodNode.nodeID, lVarName, lValNumString, "load");
		}
		/*fact= "parent("+ lValNumString +", "+ rValNumString +", "+ this.makeDatalogCompatibleString(field)+").\n";
		bOut.write(fact);*/  

		String metadata;
		if(this.vNumPrefix.equals("true")){

			metadata = rValNumString +","+ lValNumString +"\n";
			WAparentOut.write(metadata);

			metadata = lValNumString + "," + field+"\n" ;
			WAMapOut.write(metadata);

		}
		String rVarName = getVarName(ir, rValNum);
		if (rVarName == null)
			rVarName = currentMethodNode.vNumToIdentifierMapping.get(new Integer(rValNum));
		//todo. check the 1st condition
		if(rVarName != null && rVarName.equalsIgnoreCase("chromePrivilege") 
				&&  (    field.equalsIgnoreCase("Cc")
						|| field.equalsIgnoreCase("Ci")
						|| field.equalsIgnoreCase("Cu")
						|| field.equalsIgnoreCase("Cr")
						|| field.equalsIgnoreCase("components")
				)
		){
			// heap object name differs from the one in invoke instr. coz the program counter info not available 
			String heapObjectName = "h_obj" +"_"+ lValNum +"_"+ field +"_"+shortCurrentMethodName ;

			//String vNumString = "v"+ lValNum +"_"+shortCurrentMethodName;
			fact = "ptsTo(" + lValNumString +","+ heapObjectName+").\n"; 
			bOut.write(fact);

			fact = "isPrivileged(" 
				+ heapObjectName + ","
				+ "chrome"
				+ ").\n";

			bOut.write(fact);

			fact = "idIsPrivileged(" 
				+ lValNumString + ","
				+ "chrome"
				+ ").\n";
			bOut.write(fact);

			// dump to privFile

			fact = "(" 
				+ "h__"
				+ "v" + instruction.getDef()+"__"
				+ shortCurrentMethodName + "#" 
				+ this.getSrcLineNumForInstruction(ir, instruction)
				+ ",chrome"
				+ "),\n";

			privOut.write(fact);

		} 	 

	}


	/*
	 * Analyze Object property write Instruction
	 */

	private void processSSAPutInstruction(IR ir, SSAInstruction instruction, String shortCurrentMethodName, BufferedWriter bOut,
			BufferedWriter exportOut, BufferedWriter varMapOut, BufferedWriter parentOut, BufferedWriter prototypeOut) throws IOException {

		String field, fact;
		int lValNum, rValNum;
		String lValNumString, rValNumString; 
		int ref, val;

		field = ((SSAPutInstruction) instruction).getDeclaredField().getName().toString();

		lValNum = ref = ((SSAPutInstruction)instruction ).getRef();
		rValNum = val = ((SSAPutInstruction) instruction).getVal();

		lValNumString =	this.vNumPrefix + "_" + "v"+ lValNum+"_"+shortCurrentMethodName ;
		rValNumString = this.vNumPrefix + "_" + "v"+ rValNum+"_"+shortCurrentMethodName ;

		fact = "store("+ lValNumString +", "+ this.makeDatalogCompatibleString(field)+", "+ rValNumString +").\n";
		bOut.write(fact);  

		String metadata;
		if(this.vNumPrefix.equals("false")){
			if(field.equals("prototype")){
				metadata =  lValNumString +","+ rValNumString +"\n";
				prototypeOut.write(metadata);
			}
			else {
				metadata = lValNumString +","+ rValNumString +"\n";
				parentOut.write(metadata);
			}

			metadata = rValNumString + "," + field+"\n" ;
			varMapOut.write(metadata);

		}
		/*
		 *  handling exports
		 */
		String objectName = getVarName(ir, lValNum);

		if (objectName != null && objectName.equals("exports")){

			String exportInfo = field + ","+"v"+rValNum +"\n";
			exportOut.write( exportInfo);

			metadata = lValNumString + "," + "exports"+"\n" ;
			varMapOut.write(metadata);

		}		 


	}



	private void createWALAAssignMapentry(int nodeID, String lVarName, String lValNumString) {
		int i;
		MethodNodeData node;
		for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
			node = this.codeBodyNodesInCG.get(i);
			if(node.nodeID == nodeID){
				node.WALAAssignIdToVNumMapping.put(lVarName, lValNumString);
				this.codeBodyNodesInCG.set(i, node);
				return;
			}
		}

	}

	private void createMapEntryInDefinerNode(int nodeID, String lVarName, String rValNumString) {
		int i;
		MethodNodeData node;
		for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
			node = this.codeBodyNodesInCG.get(i);
			if(node.nodeID == nodeID){
				node.identifierToHeapMapping.put(lVarName,  Pair.make(rValNumString,"heap_var"));
				this.codeBodyNodesInCG.set(i, node);
				return;
			}
		}
	}

	private void removeMapEntryInCurrentMethodNode(int nodeID, String lVarName) {
		int i;
		MethodNodeData node;
		for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
			node = this.codeBodyNodesInCG.get(i);
			if(node.nodeID == nodeID){
				node.identifierToHeapMapping.remove(lVarName);
				this.codeBodyNodesInCG.set(i, node);
				return;
			}
		} 
	}

	private void storeIdentifierToHeapMapping( int nodeID, String objectName, String vNumString, String heapObjectName) {

		int i;
		MethodNodeData node;
		for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
			node = this.codeBodyNodesInCG.get(i);
			if(node.nodeID == nodeID){
				node.identifierToHeapMapping.put(objectName,  Pair.make(vNumString,heapObjectName));
				this.codeBodyNodesInCG.set(i, node);
				return;
			}
		}
	}

	private boolean isKeyWord(String rVarName) {

		if(rVarName.equals("undefined"))
			return true;
		else if (rVarName.equals("Function"))
			return true;
		else if(rVarName.equals("String"))
			return true;
		else if (rVarName.equals("Object"))
			return true;	
		else if(rVarName.equals("Date"))
			return true;
		else if (rVarName.equals("Number"))
			return true;
		else if (rVarName.equals("Boolean"))
			return true;
		else if (rVarName.equals("RegExp"))
			return true;	
		else if (rVarName.equals("Array"))
			return true;	
		
		else if (rVarName.equals("Error"))
			return true;
		// keyword defined for the analysis
		else if (rVarName.equals("WALA_assign"))
			return true;
		else if(rVarName.equals("require"))
			return true;
	
		else if(rVarName.equals("Cuimport"))
			return true;	
		/*
		 * Any string started with Moz
		 */
		else if(mozStub.isPrivilegeXPCOMStub(rVarName))
			return true;	
		
		else if (rVarName.equals("MozFile"))
			return true;	
		else if(rVarName.equals("MozFileInputStream"))
			return true;
		else if (rVarName.equals("MozConverterInputStream"))
			return true;

		else	  
			return false;
	}

	private void storeMethodParentAndHeapObjectMapping(int nodeID, String heapObjectName,  String prototypeObjectName, int parentNodeID) {

		int i;
		MethodNodeData node;
		for(i=0; i< this.codeBodyNodesInCG.size() ;i++){
			node = this.codeBodyNodesInCG.get(i);
			if(nodeID == node.nodeID){
				node.parentNodeID = parentNodeID;
				node.methodHeapObject = heapObjectName;
				node.prototypeHeapObject =  prototypeObjectName;
				this.codeBodyNodesInCG.set(i, node);
				return;
			}
		}
	}

	private boolean isStringconstant(IR ir, SSAInstruction instruction, int vNum) {

		SymbolTable symTable = ir.getSymbolTable();

		if(symTable.isConstant(vNum)) {
			final Object value = symTable.getConstantValue(vNum);
			return !isNumeric(value.toString());

		}
		return false;
	}

	private boolean privilegedObjectsContain(String objectName) {
		if(objectName.equalsIgnoreCase("browser"))
			return true;
		return false;
	}

	private String getDatalogRules(){
		/*
		 * We may not need separate rules for array, they are in fact same as object access,
		 * unless accessing an element of a tainted array results in a tainted element. check this 
		 */
		String rules = "% rules %\n"+
		" ptsTo(V1,H) :- \n"+ 
		"      ptsTo(V2, H),\n"+ 
		"      assign(V1, V2).\n"+
		"\n \n"+

		"heapPtsTo(H1, F, H2) :-\n"+
		"    store(V1, F, V2),\n"+ 
		"    ptsTo(V1, H1),\n"+
		"    ptsTo(V2, H2).\n"+
		"\n \n"+

		"ptsTo(V2,H2) :-\n"+
		"    load(V2, V1, F),\n"+ 
		"    ptsTo(V1, H1),\n"+ 
		"    heapPtsTo(H1, F, H2).\n"+
		"\n \n"+

		"%Privilege Propagation%\n\n"+

		"isTainted(H1, P) :-\n"+
		"    heapPtsTo(H1, F, H2),\n"+ 
		"    isPrivileged(H2, P).\n"+
		"\n \n"+

		"isTainted(H1, P) :-\n"+
		"    heapPtsTo(H1, F, H2),\n"+
		"    isTainted(H2, P).\n"+
		"\n \n"+

		"arrayHeapPtsTo(H1, F, H2) :-\n"+
		"    arrayStore(V1, F, V2),\n"+ 
		"    ptsTo(V1, H1),\n"+
		"    ptsTo(V2, H2).\n"+
		"\n \n"+

		"ptsTo(V2,H2) :-\n"+
		"    arrayLoad(V2, V1, F),\n"+ 
		"    ptsTo(V1, H1),\n"+ 
		"    arrayHeapPtsTo(H1, F, H2).\n"+
		"\n \n"+

		"isTainted(H1, P) :-\n"+
		"    arrayHeapPtsTo(H1, F, H2),\n"+ 
		"    isPrivileged(H2, P).\n"+
		"\n \n"+

		"isTainted(H1, P) :-\n"+
		"    arrayHeapPtsTo(H1, F, H2),\n"+
		"    isTainted(H2, P).\n"+
		"\n \n"+

		"idIsTainted(V, P) :-\n"+
		"    ptsTo(V, H),\n"+
		"    isPrivileged(H, P),\n"+
		"    not(idIsPrivileged(V,P)).\n"+
		"\n \n"+

		"idIsTainted(V, P) :-\n"+
		"	    ptsTo(V, H),\n"+
		"     isTainted(H, P).\n"+
		"\n \n"+

		"aliasTaintedPrivID(VT, VP, P ) :-\n"+
		"	    ptsTo(VT, H),\n"+
		"	    ptsTo(VP, H),\n"+
		"     idIsTainted(VT, P),\n"+
		"     idIsPrivileged(VP, P).\n"+
		"\n \n"+

		"aliasTaintedTaintedID(VT1, VT2, P ) :-\n"+
		"	    ptsTo(VT1, H),\n"+
		"	    ptsTo(VT2, H),\n"+
		"		not(VT1 = VT2),\n"+
		"     idIsTainted(VT1, P),\n"+
		"     idIsTainted(VT2, P).\n"+
		"\n \n"+

		"%call graph%\n\n"+
		"calls(I, M):-\n"+
		"		actual(I, 0, C),\n"+
		"		ptsTo(C,M).\n"+
		"\n \n"+

		"%interprocedural assignments%\n\n"+
		"assign(V1, V2):-\n"+
		"		calls(I,M),\n"+
		"		formal(M, Z, V1),\n"+
		"		actual(I, Z, V2).\n"+
		"\n \n"+

		"assign(V2, V1):-\n"+
		"		calls(I, M),\n"+  
		"		methodRet(M,V1),\n"+
		"		callRet(I, V2).\n"+
		"\n \n"+

		"assign(V1, V2):-\n"+
		"		calls(I,M),\n"+
		"		formalLexicalRead(M, V1, VarName),\n"+
		"		actualLexicalRead(I, V2, VarName).\n"+
		"\n \n"+


		"assign(V1, V2):-\n"+
		"		calls(I,M),\n"+
		"		formalLexicalWrite(M, VarName, V1),\n"+
		"		actualLexicalWrite(I, VarName, V2).\n"+
		"\n \n"+

		"%prototype handling%\n\n"+

		"heapPtsTo(H1, F, H2):-\n"+
		"		prototypeOf(H1,H),\n"+
		"		heapPtsTo(H, F, H2).\n"+
		"\n \n"+

		"prototypeOf(D, H):-\n"+
		"		typeof(M,D),\n"+
		"		heapPtsTo(M, prototype, H).\n"+
		"\n \n"+


		"prototypeOf(O, H):-\n"+
		"		heapPtsTo(M, prototype, P),\n"+
		"		heapPtsTo(M, prototype, H),\n"+
		"		prototypeOf(O,P).\n"+
		"\n \n"+
		/*
		 * The 2nd last rule is redundant if we decide to store the prototype object info in the MethodNodeData
		 * Rule name changed to avoid confusion with property named "prototype"
		 *
		 * The last rule is to equate the two prototype objects. The one declared during function construction and the one is the actual prototype object.
		 * 
		 * */

		"cArrayHeapPtsTo(H1, H2) :-\n"+
		"    arrayStore(V1, V2),\n"+ 
		"    ptsTo(V1, H1),\n"+
		"    ptsTo(V2, H2).\n"+
		"\n \n"+

		"ptsTo(V2,H2) :-\n"+
		"    cArrayLoad(V2, V1),\n"+ 
		"    ptsTo(V1, H1),\n"+ 
		"    cArrayHeapPtsTo(H1, H2).\n"+
		"\n \n"+

		"isTainted(H1, P) :-\n"+
		"    cArrayHeapPtsTo(H1, H2),\n"+ 
		"    isPrivileged(H2, P).\n"+
		"\n \n"+

		"isTainted(H1, P) :-\n"+
		"    cArrayHeapPtsTo(H1, H2),\n"+
		"    isTainted(H2, P).\n"+
		"\n \n"+
		
		/*
		 * rules for capturing property access of privileged/tainted root objects
		 */
		
		"alias(V1, V2) :-\n"+		    
		"	 ptsTo(V1, H),\n"+	
		"    ptsTo(V2, H).\n"+
		"\n \n"+
		
		"findPropLoad(V1, Prop) :-\n"+
		"    isReq(V1, ReqModuleName),\n"+
		"	 alias(V1, V2),\n"+	
		"    load(V,V2,Prop).\n"+
		"\n \n"+
		
		"findPropLoad(V1, Prop) :-\n"+
		"    idIsPrivileged(V1, P),\n"+
		"	 alias(V1, V2),\n"+	
		"    load(V,V2,Prop).\n"+
		"\n \n"+
		
		"findPropLoad(V1, Prop) :-\n"+
		"    idIsTainted(V1, P),\n"+
		"	 alias(V1, V2),\n"+	
		"    load(V,V2,Prop).\n"+
		"\n \n";
		
		
		
		return rules;               		

	}

	public void generateDesIniFile(String outputDirPath, String desPath) throws IOException {

		FileWriter fstream = new FileWriter(desPath+ File.separator +"des.ini");
		BufferedWriter diOut = new BufferedWriter(fstream);  

		String desIniContent;
		String programFactsDLFilePath = this.outputDirName + File.separator + "programFacts.dl";
		String aliasPrivFilePath = this.outputDirName + File.separator + "aliased_priv";
		String aliasTaintFilePath = this.outputDirName + File.separator + "aliased_taint";
		String taintedFilePath = this.outputDirName + File.separator + "tainted";	
		String privIDFilePath = this.outputDirName + File.separator + "privID.txt";	
		String findPropLoadFilePath = this.outputDirName + File.separator + "findPropLoad";

		desIniContent = "/verbose off" + "\n"
		+  "/pretty_print on" + "\n"
		+ "% Process (Datalog, SQL, ... queries and commands)" + "\n";
		desIniContent += "/c " + programFactsDLFilePath + "\n"; 
		desIniContent += "% Dump output to aliased_priv" +"\n";

		desIniContent += "/log " +	aliasPrivFilePath + "\n\n"; 

		desIniContent += "aliasTaintedPrivID(X,Y,P)" + "\n\n" 
		+ "/nolog" + "\n\n\n";

		desIniContent += "% Dump output to aliased_taint" +"\n";

		desIniContent += "/log " +	aliasTaintFilePath + "\n\n";

		desIniContent += "aliasTaintedTaintedID(X,Y,P)" + "\n\n" 
		+ "/nolog" + "\n\n\n";

		desIniContent += "% Dump output to privID.txt" +"\n";

		desIniContent += "/log " +	privIDFilePath + "\n\n";

		desIniContent += "idIsPrivileged(V,P)" + "\n\n" 
		+ "/nolog" + "\n\n\n";


		desIniContent += "% Dump output to tainted" +"\n";

		desIniContent += "/log " +	taintedFilePath + "\n\n";

		desIniContent += "idIsTainted(V,P)" + "\n\n" 
		+ "/nolog" + "\n\n\n\n";

		desIniContent += "% Dump output to findPropLoad" +"\n";

		desIniContent += "/log " +	findPropLoadFilePath + "\n\n";

		desIniContent += "findPropLoad(V,P)" + "\n\n" 
		+ "/nolog" + "\n\n\n\n";
		
		desIniContent += "/q"+"\n";

		diOut.write(desIniContent);
		diOut.close();

	}


	public void applyDatalog()  {


		try {

			// invoke shell script to run DES
			String command = "./datalog.sh";

			Process p = Runtime.getRuntime().exec(command);
			p.waitFor();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}



	private int getSrcLineNumForInstruction(IR ir, SSAInstruction instruction) {

		int instructionIndex=0;
		SSAInstruction ssair[] = ir.getInstructions();

		for(int i=0; i< ssair.length;i++){

			if(ssair[i] == instruction){
				instructionIndex = i;
				break;
			}
		}

		AstMethod method =  (AstMethod) ir.getMethod();

		int lineNum = method.getLineNumber(instructionIndex);  

		return lineNum;
	}



	public MethodNodeData getNodeFromMethodName (String methodName){
		for(int i=0; i< this.codeBodyNodesInCG.size(); i++ ){

			if(this.codeBodyNodesInCG.get(i).type.toString().equalsIgnoreCase(methodName)) 
				return this.codeBodyNodesInCG.get(i);

		}  
		return null;/*indicates the method  was not calles, hence does not appear in the callgraph*/
	}



	private static CGNode getFunctionNode(CallGraph CG, String dir, String file) {
		TypeName type = TypeName.findOrCreate("L" + dir + "/" + file);
		if (CG != null) {
			Iterator<CGNode> iter = CG.iterator();
			CGNode node;
			while (iter.hasNext()) {
				node = iter.next();
				TypeName tempType = node.getMethod().getDeclaringClass().getName();
				//if (tempType.equals(type))
				if (tempType.toString().contains(file) && node.getGraphNodeId()> 1) {
					System.out.println("block no "+ node.getGraphNodeId() + "method "+ node.getMethod() ); 
					System.out.println(tempType.toString() +" " +tempType.getInnermostElementType()+ node.getGraphNodeId());
					if(node.getMethod().toString().contains("Code body") && node.getGraphNodeId()>1)  
						return node;
				}

			}
		}
		System.err.println("Can't find :" + dir + "/" + file);
		return null;
	}

	private void printVarName(IR ir, String varFileName){

		SSAInstruction[] instructions = ir.getInstructions();
		SymbolTable symTable = ir.getSymbolTable();

		int instrIndex = 0; 

		for(int i=0; i< instructions.length;i++){
			if(instructions[i]!=null){
				instrIndex = i;
				break;
			}
		}

		try{


			FileWriter fstream = new FileWriter(this.outputDirName+ "/"+ "map"+ File.separator + varFileName);

			BufferedWriter bufferOut = new BufferedWriter(fstream);  


			SSAInstruction instruction = instructions[instrIndex];
			if (instruction !=null){

				for (int varNum=1; varNum<= symTable.getMaxValueNumber(); varNum++){
					String s;
					if (symTable.isConstant(varNum)) {
						final Object value = symTable.getConstantValue(varNum);
						s = (value != null) ? value.toString() : null;
					}
					else {
						final String[] varName = ir.getLocalNames(instrIndex, varNum);
						if(varName != null && varName.length == 1)
							s = varName[0];
						else if (varName != null && varName.length > 1){
							s = varName[varName.length-1];
							if(s.equalsIgnoreCase("undefined"))
								s= varName[0];
						}
						else
							s =  null;
					}
					//System.out.println("v"+varNum + " "+s);    
					bufferOut.write("v"+varNum + " "+s+"\n");    	
				}
			}

			bufferOut.close(); 
		}catch(Exception e){
			e.printStackTrace();
		}


	}

	private String getVarName ( IR ir, int vN){

		SSAInstruction[] instructions = ir.getInstructions();
		SymbolTable symTable = ir.getSymbolTable();

		int instrIndex = 0; 

		for(int i=0; i< instructions.length;i++){
			if(instructions[i]!=null){
				instrIndex = i;
				break;
			}
		}

		SSAInstruction instruction = instructions[instrIndex];
		String s =null;
		if (instruction !=null){
			if (symTable.isConstant(vN)) {
				final Object value = symTable.getConstantValue(vN);
				return (value != null) ? value.toString() : null;
			}
			else {
				final String[] varName = ir.getLocalNames(instrIndex, vN);
				if(varName != null && varName.length == 1)
					return  varName[0];
				else if (varName != null && varName.length > 1){
					s = varName[varName.length-1];
					if(s.equalsIgnoreCase("undefined"))
						return varName[0];
					else
						return s;
				}
				else
					return  null;
			}
		}
		return s;
	}

	private String getMethodShortName(MethodNodeData node) {

		String temp = node.type.toString();
		String methodName;
		if(node.nodeID > 62){
			methodName = temp.substring( temp.lastIndexOf(".")+4);
			if(methodName.contains("/"))
				//methodName = methodName.substring( methodName.lastIndexOf("/")+1);
				methodName = methodName.replace('/', '_');     


		}    
		else
			// methodName= "mScope"+"_"+temp.substring(temp.lastIndexOf("/")+1, temp.lastIndexOf(".")) ;
			methodName = "moduleScope";

		return methodName;
	}


	private static boolean isNumeric(String str)
	{
		return str.matches("-?\\d+(.\\d+)?");
	}

	private String removeDash( String identifier){
		if(identifier.contains("-"))
			identifier = identifier.replace('-', '_');
		return identifier;
	}

	private String makeDatalogCompatibleString(String identifier) {

		if(identifier.contains("/"))
			identifier = identifier.replace('/', '_');
		if (identifier.contains("-"))
			identifier = identifier.replace('-', '_');

		// TODO Auto-generated method stub
		char firstChar = identifier.charAt(0);
		if (firstChar >='A' && firstChar <= 'Z'){
			identifier = makeInitialLowerCase(identifier);
		}			
				
		/*
		 * trim out all the preceeding _ and put them at end string
		 */
		else if(firstChar == '_'){
			int index = 0;
			int count = 0;
			while(identifier.charAt(index) == '_'){
				count++;
				index++;
			}

			String trimmed = identifier.substring(index);

			String underscores = new String();
			while(count >0 ){
				underscores.concat("_");
				count--;
			}
            
			
			char firstCharofTrimmed = trimmed.charAt(0);
			if (firstCharofTrimmed >='A' && firstCharofTrimmed <= 'Z'){
				trimmed = makeInitialLowerCase(trimmed);
			}	
			identifier = trimmed + underscores + "udified";
		}
		return identifier;
	}

	private String makeInitialLowerCase(String identifier) {
	    	
		char firstChar = identifier.charAt(0);
		// make an uppercase letter to lowercase
		char modifiedFirstChar = (char) (firstChar + ' ');
		identifier = identifier.replace(firstChar, modifiedFirstChar);
		return identifier + "_uppercase"; // indicating that the original text has the first letter in uppercase
		
	}




}