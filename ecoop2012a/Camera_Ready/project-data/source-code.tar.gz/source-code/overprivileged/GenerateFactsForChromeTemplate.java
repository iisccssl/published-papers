package com.ibm.wala.cast.js.test.overprivileged;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import com.ibm.wala.cast.js.ssa.JavaScriptInvoke;
import com.ibm.wala.cast.js.test.overprivileged.DumpModuleDatalogFacts.MethodNodeData;

import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.SSAInstruction;


public class GenerateFactsForChromeTemplate {

	private Map<String, TemplateEntry> importedPropertyTree; //hierarchy, TemplateEntry
	private ArrayList<String> hierarchyArray; // required to maintin the order, so the fact generation does not fail, acts like an index for the hashmap
	private Map<String, String> vNumToRandomStringMapping; 
		
	public class TemplateEntry{
		String hierarchy;
		String parent; // parent means the hierarchy except the propertyName
		String propertyName;
		ArrayList<String> privileges;
		String type;
		String heapObject; // heapObject corrs to the the property in the hierarchy
		String v2NumString;
	}

	private String templateDir;
	private String reqHeapObjName;
	String importedModule;
	String importedModuleFileName;
	MethodNodeData currentMethodNode;
	IR ir;
	SSAInstruction instruction;
	String shortCurrentMethodName;
	BufferedWriter bOut;

	private String vNumPrefix;
	private BufferedWriter heapMapOut;
	
	public GenerateFactsForChromeTemplate(String tempDir, String heapObjectName,
			MethodNodeData currentMethodNode, IR ir,
			SSAInstruction instruction, String shortCurrentMethodName,
			BufferedWriter bOut) {
		
		this.templateDir = tempDir;
		this.reqHeapObjName = heapObjectName;
		this.importedModule = "chrome";
		this.importedModuleFileName = "chrome";
		this.currentMethodNode = currentMethodNode;
		this.instruction = instruction;
		this.ir = ir;
		this.shortCurrentMethodName = shortCurrentMethodName;
		this.bOut = bOut;
	
		this.vNumPrefix = "false";
		this.vNumToRandomStringMapping = new HashMap<String, String>();
	}
	

	public void generateFactsFromTemplate() throws IOException {

		String fact;
		String vRandomString;
		
		Iterator<String> hierarchyIterator = this.hierarchyArray.iterator();

		while(hierarchyIterator.hasNext()){

			TemplateEntry entry = this.importedPropertyTree.get(hierarchyIterator.next());
			
			if(entry.propertyName.equals("exports")){
				/*
				 * no need to process for exports entry
				 */
				continue;
			}

			TemplateEntry parentEntry = this.importedPropertyTree.get(entry.parent);

			if(parentEntry.type.equalsIgnoreCase("Object")) {
				
				this.processEntry(entry);

				/*
				 * generate heapPtsTo fact
				 * Assumption parentEntry.heapObject mapping is never null 
				 * And after processing the entry entry.heapObject has been set to
				 */
								
				fact = "heapPtsTo("+ parentEntry.heapObject +","
						+ this.makeDatalogCompatibleString(entry.propertyName) +", "
						+ entry.heapObject + ").\n";

				bOut.write(fact);

			}
			else if (parentEntry.type.equalsIgnoreCase("Function")){
				
				/*
				 *  store everything in the v2 for this method if it is used as a constructor
				 *  which we can determine if it appears as a parent of any property in the tree
				 *  otheriwse it will be treated as a normal function and only facts for the return values will be generated
				 */
				
				
				String vNumString = this.vNumPrefix + "_" + "v2" + "_"+ this.makeDatalogCompatibleString(parentEntry.hierarchy) +"_"+ this.importedModule +"_"+ this.shortCurrentMethodName;
				if(parentEntry.v2NumString == null){
					vRandomString = getVnumRandomString(vNumString);
					parentEntry.v2NumString = vRandomString; 
				}
				else
					vRandomString = parentEntry.v2NumString;
				
				/*
				 * make vNumString equal to the random string generated, to generate the correct facts
				 */
				vNumString = vRandomString; 
				
				fact = "formal("+ parentEntry.heapObject+ ","+ 1 +","+ vNumString + ").\n";  
				bOut.write(fact);
				
				String lValNumString =	vNumString;
				String  rValNumString = this.vNumPrefix + "_" + "v"+ "_" + this.makeDatalogCompatibleString(entry.propertyName)+ "_" +  this.importedModule + "_"+ this.makeDatalogCompatibleString(parentEntry.hierarchy) +"_"+ this.shortCurrentMethodName;
				
				vRandomString = getVnumRandomString(rValNumString);
				/*
				 * make vNumString equal to the random string generated, to generate the correct facts
				 */
				rValNumString = vRandomString; 				
				
				fact = "store("+ lValNumString +", "+ this.makeDatalogCompatibleString(entry.propertyName)+", "+ rValNumString +").\n";
				bOut.write(fact);  

				/*
				 * set the heap object mapping for both object and function
				 */				 
				this.processEntry(entry);
				/*
				 * generate ptsTo fact
				 * after processing the entry entry.heapObject has been set to
				 */
				
				fact = "ptsTo("+ rValNumString + ", " + entry.heapObject + ").\n";
				bOut.write(fact);
			}
		}		
	}

	
	
	private String getVnumRandomString(String vNumString) {
		
		int randomValue;
		String vRandomString;
		
		randomValue = getRandomNumber();				
		vRandomString = this.vNumPrefix + "_"+ "v" + randomValue + "_"+ this.shortCurrentMethodName;
		this.addToLogVNumToRandomMapping(vNumString, vRandomString);
		return vRandomString; 
	}


	private void addToLogVNumToRandomMapping(String vNumString,
			String vRandomString) {
		this.vNumToRandomStringMapping.put(vNumString, vRandomString);
		
	}


	private int getRandomNumber() {
		int min = 1000;
		int max = 5000;
		Random rand = new Random();
		int random = rand.nextInt(max-min+1) + min;	
		return random;
	}


	private void processEntry(TemplateEntry entry) throws IOException {
	
		if(entry.type.equalsIgnoreCase("Object")){					
			this.processObjectEntry(entry);					
		}

		else if (entry.type.equalsIgnoreCase("Function")){					
			this.processFunctionEntry(entry);				
		}
			
	}


	private void processFunctionEntry(TemplateEntry entry) throws IOException {
		
		String fact;
		String vRandomString;
		String propertyHeapObjName = "";
		
		propertyHeapObjName = entry.heapObject;
		
		if(propertyHeapObjName == null){		
			propertyHeapObjName = "h_func_" + entry.propertyName + "_" +  this.makeDatalogCompatibleString(this.importedModule) +"_"+ this.shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter() ;
			entry.heapObject = propertyHeapObjName; 
			this.importedPropertyTree.put( entry.hierarchy, entry);
		}	
		/*
		 * handling return privileges from a function, generate the below facts only if the function returns any privileges
		 */
		if(entry.privileges != null){
			/*
			 * methodRet facts
			 */
			String vNumString = this.vNumPrefix + "_" + "v" +"_"+ "retOf_" + this.makeDatalogCompatibleString(entry.hierarchy) + "_" + this.importedModule +"_"+ shortCurrentMethodName ; 
			
			vRandomString = getVnumRandomString(vNumString);
			
			/*
			 * make vNumString equal to the random string generated, to generate the correct facts
			 */
			vNumString = vRandomString; 
			fact = "methodRet("+ propertyHeapObjName +","+ vNumString  + ").\n";  
			bOut.write(fact);

			String retHeapObjName = "h_ret_" + entry.propertyName + "_" + this.makeDatalogCompatibleString(this.importedModule) +"_"+ this.shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();

			fact = "ptsTo("+ vNumString+","+ retHeapObjName+").\n";
			bOut.write(fact);
			
			this.generatePrivilegedFacts(retHeapObjName, entry.privileges);		
			/*
			 * dump the heap mapping in the heapMap file
			 */			
			String heapMapFormatString = "h"+"__"+"v"+"_retOf_"+ this.makeDatalogCompatibleString(entry.hierarchy) + "_" + this.makeDatalogCompatibleString(this.importedModule) + "_" + entry.propertyName + "__"+ this.shortCurrentMethodName + "#"; 
			this.heapMapOut.write(entry.hierarchy +","+heapMapFormatString+"\n");
		}

		//TODO handle  prototype
		
	}


	private void processObjectEntry(TemplateEntry entry) throws IOException {
		
		String propertyHeapObjName = "";
		
		propertyHeapObjName = entry.heapObject;
		
		if(propertyHeapObjName == null){
			propertyHeapObjName = "h_obj_" + entry.propertyName + "_" +  this.makeDatalogCompatibleString(this.importedModule) +"_"+shortCurrentMethodName+ "_"+ ((JavaScriptInvoke)instruction).getProgramCounter();
			entry.heapObject = propertyHeapObjName; 
			this.importedPropertyTree.put( entry.hierarchy, entry);
			/*
			 * dump the heap mapping in the heapMap file
			 */			
			String heapMapFormatString = "h"+"__"+"v"+"_obj_"+ this.makeDatalogCompatibleString(entry.hierarchy) + "_" + this.makeDatalogCompatibleString(this.importedModule) + "_" + entry.propertyName + "__"+ this.shortCurrentMethodName + "#"; 
			this.heapMapOut.write(entry.hierarchy +","+heapMapFormatString+"\n");
		}	

		if(entry.privileges != null){						
			this.generatePrivilegedFacts(propertyHeapObjName, entry.privileges);						
		}
		
	}


	private void generatePrivilegedFacts(String heapObjName, ArrayList<String> privileges) throws IOException {
		
		int i;
		String fact;
		
		for(i = 0 ; i < privileges.size() ; i++){
			
			fact = "isPrivileged(" 
				+ heapObjName + ","
				+ privileges.get(i)
				+ ").\n";

			bOut.write(fact);
		}		
	}


	public void readTemplatedFile() {
		
		TemplateEntry tEntry;
		String templateFile = this.templateDir+ File.separator + this.importedModuleFileName+".txt"; 
		
		this.importedPropertyTree = new HashMap<String,TemplateEntry>(); 
		this.hierarchyArray = new ArrayList<String>(); 
		
		try{
			// Open the file 	
			FileInputStream fstream = new FileInputStream(templateFile);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			
			/*
			 * Process the 1st line for the exports entry
			 */
			if ((strLine = br.readLine()) != null){
				
				String entry[] = strLine.split("\\s+");
				
				/*
				 * privileges associated with exports
				 */
				if(entry.length > 1){
					String privileges[] = entry[1].split(",");
					tEntry = new TemplateEntry();
					tEntry.hierarchy = entry[0];
					tEntry.heapObject = this.reqHeapObjName;
					tEntry.parent = "";			
					tEntry.propertyName = "exports";
					tEntry.type = "Object";
					tEntry.privileges = new ArrayList<String>();
					for(int i = 0 ; i < privileges.length ; i++){
						tEntry.privileges.add(privileges[i]);
					}
					this.importedPropertyTree.put( tEntry.hierarchy, tEntry);
					this.generatePrivilegedFacts(this.reqHeapObjName, tEntry.privileges);
				}			
			}
			
			//Read File Line By Line
			while ((strLine = br.readLine()) != null)   {
				// Print the content on the console
				System.out.println ("^^^^^^^^^^^^^^^^^^^^^^^^^"+strLine);
				if(strLine.equalsIgnoreCase(""))
					continue;// skip the empty lines
				
				String entry[] = strLine.split("\\s+");
				String hierarchy = entry[0];
				if(this.existsInPropertyTree(hierarchy)){
					/*
					 * entry already exists, ass to privileges list
					 * Assumption: An entry will not have null privilege if it has privilege in another line
					 * So the privileges list has already been initialized
					 */
					tEntry = this.importedPropertyTree.get(hierarchy);
					if(! entry[2].equalsIgnoreCase("null")){
						tEntry.privileges.add(entry[2]);
						this.importedPropertyTree.put(hierarchy, tEntry);
					}
				}
				else{
					/*
					 * entry does not exist in the tree, create a new one
					 */
					tEntry = new TemplateEntry();
					tEntry.hierarchy = entry[0];
					int index = tEntry.hierarchy.lastIndexOf(".");
					tEntry.parent = tEntry.hierarchy.substring(0, index); 							
					tEntry.propertyName = tEntry.hierarchy.substring(index + 1);
					tEntry.type = entry[1];
				
					if(!entry[2].equalsIgnoreCase("null")){
						tEntry.privileges = new ArrayList<String>();
						tEntry.privileges.add(entry[2]);
					}
				
					this.importedPropertyTree.put( tEntry.hierarchy, tEntry);
					
					this.hierarchyArray.add(tEntry.hierarchy);
				}
			}
			//Close the input stream
			in.close();
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}		
	}

	private boolean existsInPropertyTree(String hierarchy) {
		
		return this.importedPropertyTree.containsKey(hierarchy);		
	}


	public void dumpDatalogFacts(String heapMapFromTemplateDirName) {
		 this.readTemplatedFile();
		
		 try {
			 File file = new File(heapMapFromTemplateDirName);
				if(!file.exists())
						file.mkdir();
				FileWriter heapMapFile = new FileWriter( heapMapFromTemplateDirName + File.separator + this.importedModuleFileName +".heapmap");
				this.heapMapOut = new BufferedWriter(heapMapFile);  
		
				this.generateFactsFromTemplate();
				this.heapMapOut.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

	private String makeDatalogCompatibleString(String identifier) {

		if(identifier.contains("/"))
			identifier = identifier.replace('/', '_');
		if(identifier.contains("."))
			identifier = identifier.replace('.', '_');		
		if (identifier.contains("-"))
			identifier = identifier.replace('-', '_');

		// TODO Auto-generated method stub
		char firstChar = identifier.charAt(0);
		if (firstChar >='A' && firstChar <= 'Z'){
			// make an uppercase letter to lowercase
			char modifiedFirstChar = (char) (firstChar + ' ');
			identifier = identifier.replace(firstChar, modifiedFirstChar);
			return identifier + "_uppercase"; // indicating that the original text has the first letter in uppercase
		}	
		
		/*
		 * trim out all the preceeding _ and put them at end string
		 */
		else if(firstChar == '_'){
			int index = 0;
			int count = 0;
			while(identifier.charAt(index) == '_'){
				count++;
				index++;
			}

			String trimmed = identifier.substring(index);

			String underscores = new String();
			while(count >0 ){
				underscores.concat("_");
				count--;
			}

			identifier = trimmed + underscores + "udified";
		}
		return identifier;
	}


	public void dumpvNumToRandomMapping(String mapDirName) throws IOException {
		String fileName = this.makeDatalogCompatibleString(this.importedModule) + "_"+ this.shortCurrentMethodName + ((JavaScriptInvoke)instruction).getProgramCounter()+".random";
		FileWriter randomMapFile = new FileWriter( mapDirName + File.separator + fileName);
		BufferedWriter randomMapOut = new BufferedWriter(randomMapFile);
		
		Iterator<String> vNumStringIterator = this.vNumToRandomStringMapping.keySet().iterator();
		
		while(vNumStringIterator.hasNext()){
			String vNumString = vNumStringIterator.next();
			randomMapOut.write(vNumString+"   "+ this.vNumToRandomStringMapping.get(vNumString)+"\n");	
		}
		
		randomMapOut.close();
	}
	


}
