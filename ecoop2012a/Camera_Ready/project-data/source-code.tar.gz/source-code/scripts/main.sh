#!/bin/bash

x="unzipped_jetpacks/"
y="";
while read file
do
cd "$x$file/";
z=`ls | (wc -l)`;
y="$y$a\t\t$z\n";
cd /home/mdhawan/Desktop/
done < <(cat /home/mdhawan/Desktop/res)
echo -e $y > /home/mdhawan/Desktop/out
