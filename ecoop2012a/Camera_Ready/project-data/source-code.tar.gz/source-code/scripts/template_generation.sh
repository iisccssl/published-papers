# !/bin/sh

local priv=""
while read line
do
done < <(cat $1)
local prop=""
local type=""
local retval=""
declare -a arr
# get prop
where = match($1, /_export/)
print $2
split($1, arr, "_")
end = 0
result = ""
for (i in arr)
end++
for (i = 2; i <= end; i++)
result = result"_"arr[i]
print substr(result, 2, length(result))
# get priv
# get type
print "Object"
print "Function"
retval=$retval"\n"$prop","$priv","$type
echo  $retval
cat $1 | sed 's/  */ /g' > /tmp/temp
mv /tmp/temp $1
local text=""
# remove all empty lines, non-essential lines
# name == directory
# all privs
text=$text" "`allPrivs $1`"\n"
# property, privilige, type
text=$text`getTuples $1`
`echo -e $text > ./template`
cd $1
for p in *
cd "$p"
process "./output"
cd ..
done
