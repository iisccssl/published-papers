# !/bin/sh

# fix WALA_append to WALAappend
cat $1 | sed -e 's/WALA_append/WALAappend/g' > /tmp/temp
mv /tmp/temp $1
# remove WALA_ASSIGN from exports
cat $1 | sed -e 's/\(exports\.[a-zA-Z0-9_]\+\)[ ]*=[ ]*WALA_ASSIGN(\([a-zA-Z0-9_]\+\));/\1 = \2/g' > /tmp/temp
for p in *
do
if [ -d "$p" ]
then
cd $p
recurse
cd ..
else
echo `pwd`/$p
process $p
fi
done
cd $1
