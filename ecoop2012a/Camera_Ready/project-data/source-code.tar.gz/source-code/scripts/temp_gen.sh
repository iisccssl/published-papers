# !/bin/sh

function getLiteral() {

	local vval=$1
	local name=""
	
	while read line
	do
		name=`echo -e $line | awk -F',' '{ print $2 }'`
		if [ "$name" != "" ]
		then
			break
		fi
	done < <(grep $1 ./tempGenDir/varMap.txt)
	
	# if name is null then it is not a property
	# it could be a local variable, so look in the scope map
	#if [ "$name" == "" ]
	#then
	#	
	#	val=`echo $1 | sed -e 's/\(v[0-9]\+\)_\(.*\)/\1__\2/'`
	#	vnum=`echo $val | awk -F'__' '{print $1}'`
	#	vloc=`echo $val | awk -F'__' '{print $2}'`
	#	
	#	while read line
	#	do
	#		name=`echo -e $line | grep $vnum | awk '{print $2}'`
	#		if [ "$name" != "" ]
	#		then
	#			break
	#		fi
	#	done < <(cat ./"map"/$vloc"_var")
	#fi
	
	echo $name
}

function functionHierarchy() {

	local text=""

	# get the 'this' object of the function
	local this="v2"_`echo $1 | awk -F'_' '{print $2}'`
	
	# get the parent of the this object
	while read line
	do
		local parent=`echo $line | awk -F',' '{print $2}'`
		local temp=`grep $parent"," ./tempGenDir/parent.txt`
		if [ "$temp" != ""]
		then
			break
		else
			break
		fi
	done < <(grep ",false_"$this ./aliased)
	
	text=`getLiteral $parent`"."$text
	echo $text

}

function hierarchy() {

	local text=$2
	
	while read line
	do
		local parentV=`echo -e $line | awk -F',' '{ print $1 }' | awk -F'false_' '{ print $2 }'`
		if [ "$parentV" == "" ]
		then
			break
		fi
		text=`getLiteral $parentV`"."$text
		text=`hierarchy $parentV $text`
	done < <(grep ",false_"$1 ./tempGenDir/parent.txt)
	
	echo $text
}

function testChildren() {
	
	local vval=$1
	local priv=$2
	local text=$3

	while read line
	do
		local child=`echo -e $line | awk -F',false_' '{ print $2 }'`
		local check=`grep $child ./tainted`
		if [ "$check" != "" ]
		then
			text=$text"."`getLiteral $child`"."`testChildren $child $priv $text`
			echo ${text%?}
		else
			local val=`echo $child | sed -e 's/\(v[0-9]\+\)_\(.*\)/\1__\2/'`
			check=`grep $val ./privileged`
			if [ "$check" != "" ]
			then
				text=$text"."`getLiteral $child`"."`testChildren $child $priv $text`
				echo ${text%?}
			fi
		fi
	done < <(grep $vval"," ./tempGenDir/parent.txt)
}

function checkFnReturn() {

	local vval=$1
	
	# test if the child appears in the privileged or not
	local tmp1=`echo -e $vval | awk -F'_' '{ print $1 }'`
	local tmp2=`echo -e $vval | awk -F'_' '{
		out = $2;
		for (i = 3; i <= NF; i++)
			out	= out"_"$i;
		print out;
	}'`
	local checkscope=`grep $tmp1"__"$tmp2 ./privileged`
	if [ "$checkscope" != "" ]
	then
		# TODO: ensure that the capability in privileged file is same
		text=`echo -e $tmp2 | awk -F'_' '{
			out = "exports";
			for (i = 1; i <= NF; i++)
				out	=	out"."$i;
			print out;
		}'`
	else
		# if it is not found in the privileged file, then it could be an alias
		# or an inherited privilege, either through 'require' or 'this'
		text=`echo -e $tmp2 | awk -F'_' '{
			out = "exports";
			for (i = 1; i <= NF; i++)
				out	=	out"."$i;
			print out;
		}'`
	fi
	
	echo $text
}

# process each directory
function process() {

	# remove duplicates from tempGenDir
	cd tempGenDir
	for i in *
	do
		cat $i | awk '!x[$0]++' > /tmp/temp
		mv /tmp/temp $i
	done
	cd ..

	# remove multiple spaces in output file
	#cat ./output | sed -e "s/[ \t]\+/ /g" | sed '1d' | sed '1d' | sed -e '/this[ ]\+,N\/A/d' -e '/null[ ]\+,N\/A/d' > ./output_temp
	cat ./output | sed -e "s/[ \t]\+/ /g" | sed '1d' | sed '1d' | sed -e '/this[ ]\+,N\/A/d' -e '/null[ ]\+,N\/A/d' -e '/exports[ ]\+,N\/A/d' -e '/WALAappend/d' > ./output_temp
	#cat ./output | sed -e "s/[ \t]\+/ /g" | sed '1d' | sed '1d' > ./output_temp

	declare -A arr
	local fileContent=""

	# get all the exported privileges
	while read line
	do
		local tempcap=`echo -e $line | awk '{ print $4 }'`
		arr[$tempcap]=true
	done < <(cat ./output_temp)

	for i in ${!arr[*]}
	do
		fileContent=$fileContent","$i
	done
	fileContent="exports "${fileContent:1}"\n"

	# read the output file
	while read line
	do

		local vval=`echo -e $line | awk '{ print $1 }'`
		local priv=`echo -e $line | awk '{ print $4 }'`
		
		local child=`getLiteral $vval`
		local text=`hierarchy $vval $child`
		
		# several cases arise here
		# case 1: text is not null and vval is same as in privileged
		# - this is the actual privileged object
		# case 2: text is not null, but vval is not same as in privileged
		# - this is an object whose child is privileged
		# case 3: text is null then vval could be a function
		# - get the children and match their vval with privileged
		# - the return value is tainted, so check the vval and its aliases with privileged
		
		if [ "$text" != "" ]
		then
			local checkscope=`grep $vval ./tainted`
			if [ "$checkscope" != "" ]
			then
				echo $text" Object "$priv
				fileContent=$fileContent"\n"$text" Object "$priv
				text=`testChildren $vval $priv $text`
				if [ "$text" != "" ]
				then
					echo $text" Object "$priv
					fileContent=$fileContent"\n"$text" Object "$priv
				fi
			fi
		else
			# text was null

			# get the this object and then find its hierarchy
			#text=`functionHierarchy $vval`
			
			text=`echo -e $vval | awk -F'_' '{
				out = "exports";
				for (i = 2; i <= NF; i++)
					out	= out"."$i;
				print out;
			}'`
			local tmptext=$text
			# check if any associated properties
			text=`testChildren $vval $priv $text`
			if [ "$text" == "" ]
			then
				# if text is null, then it means that the return value of the function is tainted
				# check for vval and its aliases in privileged
				text=`checkFnReturn $vval`
				if [ "$text" != "" ]
				then
					echo $tmptext" Function "$priv
					fileContent=$fileContent"\n"$tmptext" Function "$priv
				#else
				#	echo "Something is also wrong"
				fi
			else
				echo $tmptext" Function Null"
				fileContent=$fileContent"\n"$tmptext" Function Null"
				echo $text" Object "$priv
				fileContent=$fileContent"\n"$text" Object "$priv
			fi
		fi
	done < <(cat ./output_temp)
	
	echo -e $fileContent | awk '!x[$0]++' > ./template
	rm ./output_temp
}

cd $1
for p in *
do
	cd "$p"
	echo -e "\nFile = "`pwd`
	process
	cd ..
done
