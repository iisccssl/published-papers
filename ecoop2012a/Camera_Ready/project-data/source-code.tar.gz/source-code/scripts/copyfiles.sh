# !/bin/sh

path1=$1
path2=$2

cd $path1

for i in *
do
	if [ -d "$i" ]
	then	
		
		cd $i
		
		for j in *
		do
		
			cp $path2/$i/$j".js" $j/
		
		done
		
		
		cd ..
		
	fi
done
