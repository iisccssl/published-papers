# !/bin/sh

global="moduleScope"
walaAppend="WALAappend"
top_level_path=$1

# get the mapping of v values to variables
function position() {
	
	local match=""
	local heap=""
	
	# remove all true_, false_ prefixes
	cat ./tempGenDir/varMap.txt | sed -e 's/false_//g' | sed -e 's/true_//g' > /tmp/temp
	mv /tmp/temp ./tempGenDir/varMap.txt
	
	# open the file
	while read line
	do
		match=`echo -e $line | grep $1 | awk -F',' '{print $2}'`
		if [ "$match" != "" ]
		then
			vl=`echo -e $line | grep $1 | awk -F',' '{print $1}'`
			vnum=`echo -e $vl | awk -F'_' '{print $1}'`
			vloc=`echo -e $vl | awk -F'_' '{print $2}'`
			break
		fi
	done < <(cat ./tempGenDir/varMap.txt)
	
	if [ "$match" == "" ]
	then
		val=`echo $1 | sed -e 's/\(v[0-9]\+\)_\(.*\)/\1__\2/'`
		vnum=`echo $val | awk -F'__' '{print $1}'`
		vloc=`echo $val | awk -F'__' '{print $2}'`
		while read line
		do
			match=`echo -e $line | grep $vnum | awk '{print $2}'`
			if [ "$match" != "" ] && [ "$match" != "null" ]
			then
				break
			fi
		done < <(cat ./"map"/$vloc"_var")
	fi

	if [ "$match" == "" ]
	then
		
		local flag=false
		
		while read line
		do
			local test=`echo -e $line | awk -F',' '{print $2}'`
			if [ "$test" != "" ]
			then
				cd ./map			
				for x in *.random
				do
					local heap=`cat $x | grep $test | awk '{print $1}'`
					if [ "$heap" != "" ]
					then
						flag=true
						break
					fi
				done
				cd ..
				if [ "$flag" == true ]
				then
					break
				fi
			fi
		done < <(grep $1 ./aliased)

		if [ "$heap" != "" ] && [ "$flag" == true ]
		then
			cd ./heapMapForTemplate
			for j in *.heapmap
			do
				local vl=`cat $j | grep $heap | awk -F',' '{print $1}' | sed -e 's/mozStub//g'`
				if [ "$vl" != "" ]
				then
					match=`echo $j | awk -F'.' '{print $1}'`$vl
					break
				fi
			done
			cd ..
		fi
	fi

	if [ "$match" == "" ]
	then
		match="null"
	fi

	match=$match"\t"
	flag=false

	# get line number from the privileged facts
	while read line
	do
		tmp1=`echo $line | awk -F',' '{print $1}'`
		tmp2=`echo $tmp1 | awk -F'#' '{print $1}'`
		lno=`echo $tmp1 | awk -F'#' '{print $2}'`
		vno=`echo $tmp2 | awk -F'__' '{print $2}'`
		fun=`echo $tmp2 | awk -F'__' '{print $3}'`
		pri=`echo $line | awk -F',' '{print $2}' | awk -F')' '{print $1}'`
		if [ "$vloc" == "$fun" ] && [ "$2" == "$pri" ]
		then
			flag=true
			if [ "$vno" == "$vnum" ]
			then
				match=$match",Y"
				match=$match":"$lno
				break
			else
				match=$match",N"
				match=$match":"$lno
			fi
		fi
	done < <(cat ./privileged) 

	if [ "$flag" == false ]
	then
		match=$match",N/A"
	fi

	echo $match
}

function getLiteral() {

	local vval=$1
	local name=""
	
	while read line
	do
		name=`echo -e $line | awk -F',' '{ print $2 }'`
		if [ "$name" != "" ]
		then
			break
		fi
	done < <(grep $1 ./tempGenDir/varMap.txt)
	
	echo $name
}

function scopeChain() {

	local scope=$2
	local b=""
	local c=""
	local d=""
	
	# find v value for the function -> ret.txt
	while read line
	do
		b=`echo $line | awk -F',' '{print $1}'`
		if [ "$b" != "" ]
		then
			break
		fi
	done < <(grep $1 ./WALAappendDir/ret.txt)
	
	# get the litername for the function from v value -> varMap.txt
	if [ "$b" != "" ]
	then
		while read line
		do
			c=`echo $line | awk -F',' '{print $2}'`
			if [ "$c" != "" ]
			then
				break
			fi
		done < <(grep $b ./WALAappendDir/varMap.txt)
	fi
	
	# get the litername for the function from v value -> varMap.txt
	if [ "$c" != "" ]
	then
		while read line
		do
			d=`echo $line | awk -F',' '{print $1}'`
			if [ "$d" != "" ]
			then
				break
			fi
		done < <(grep $b ./WALAappendDir/parent.txt)
	fi
	
	# then get the parent of the v value -> check in the parent.txt
	# again in the varMap, repeat this till you reach null or exports
	
	if [ "$d" != "" ] && [ "$c" != "exports" ]
	then
		scope=`scopeChain $d $2`"_"$c
	fi
	
	echo ${scope:1}
}

function setCorrectAlias() {

	local scope=`scopeChain $1 ""`
	local e=""
	
	# constuct the scope chain for the function
	# grep for scope_chain, v_value in ./aliased

	while read line
	do
		e=`echo $line | awk -F',' '{print $2}'`
		if [ "$e" != "" ]
		then
			break
		fi
	done < <(grep $1",[a-zA-Z0-9_]\+"$scope ./aliased)

	echo $e
}

# process each directory
function process() {

	# a) read v values of direct childern of exports object
	declare -A child

	while read file
	do
		local a=`echo $file | awk -F',' '{print $2}'`

		if [ "$a" != "" ]
		then
			child[$a"_"$global]=true
		fi

	done < <(cat ./children)

	# b) read aliased v values
	declare -A alias

	while read file
	do
		local b=`echo $file | awk -F',' '{print $1}' | awk -F'(' '{print $2}'`
		local c=`echo $file | awk -F',' '{print $2}'`

		if [ "$b" != "" ] && [ "$c" != "" ]
		then
			tmp=`echo $c | grep $global`
			if [[ "$tmp" != "" && "${child[$tmp]}" ]] || [ "$tmp" == "" ]
			then
				alias[$b]=$c
			fi
		fi

	done < <(cat ./aliased)

	# c) find set of top level exported v values
	text="V_Value Variable Line# Privilege\n---------------------------------------------------------------------------------------------------------------------------------"
	while read file
	do

		local d=`echo $file | awk -F',' '{print $1}' | awk -F'(' '{print $2}'`
		local e=`echo $file | awk -F',' '{print $2}' | awk -F')' '{print $1}'`

		# if $d is not introduced from new code, then it must be a direct child
		local f=`echo $d | awk -F'false_' '{print $2}'`
		if [ "$f" != "" ] && [ "${child[$f]}" ]
		then
			text=$text"\n"$f"\t"`position $f $e`"\t"$e
		fi

		# if $d is from new code, then find aliases for $d
		local g=`echo $d | awk -F'true_' '{print $2}'`
		#if [[ "$g" && "${alias[$g]}" != "" ]]
		#then
		#	m=${alias[$g]}
		#	text=$text"\n"$m"\t"`position $m $e`"\t"$e
		#fi
		if [ "$g" != "" ]
		then
			m=`setCorrectAlias $g`
			if [ "$m" != "" ]
			then
				text=$text"\n"$m"\t"`position $m $e`"\t"$e
			fi
		fi

	done < <(grep "$global\|$walaAppend" ./tainted)
	
	# d) now check if any direct child is privileged
	while read file
	do
	
		f=`echo $file | awk -F'__' '{print $2}'`
		g=`echo $file | awk -F'__' '{print $3}' | awk -F'#' '{print $1}'`
		local h=`echo $file | awk -F'__' '{print $3}' | awk -F'#' '{print $2}' | awk -F',' '{print $1}'`
		local k=`echo $file | awk -F',' '{print $2}' | awk -F')' '{print $1}'`
		local l=`getLiteral $f"_"$g`
	
		# now grep in the children file
		local m=`grep -w $l","$f ./children`
		if [ "$m" != "" ]
		then
			text=$text"\n"$f"_"$g"\t"`position $f"_"$g $k`"\t"$k
		fi
	
	done < <(grep "$global" ./privileged)
	

	# e) final output

	`echo -e $text | sed -e '/WALAappend/d' | awk '!x[$0]++' | awk '{printf "%-40s%-40s%-40s%s\n",$1,$2,$3,$4}' > ./output`
	cat ./output
	#rm ./aliased
}

cd $top_level_path
for p in *
do
	cd "$p"
	echo -e "\nFile = "`pwd`
	
	# concatenate aliased_priv and aliased_taint files
	`cat ./aliased_taint ./aliased_priv > ./aliased`
	
	# remove lines with false->true and true->true alias mapping
	cat ./aliased | sed '/false_v[0-9]\+_[a-zA-Z]\+,true_v[0-9]\+_[a-zA-Z]\+/d' > /tmp/temp
	mv /tmp/temp ./aliased
	cat ./aliased | sed '/true_v[0-9]\+_[a-zA-Z]\+,true_v[0-9]\+_[a-zA-Z]\+/d' > /tmp/temp
	mv /tmp/temp ./aliased
	
	# remove all true, false prefixes
	cat ./aliased | sed -e 's/false_//g' | sed -e 's/true_//g' > /tmp/temp
	mv /tmp/temp ./aliased
	
	process
	cd ..
done
