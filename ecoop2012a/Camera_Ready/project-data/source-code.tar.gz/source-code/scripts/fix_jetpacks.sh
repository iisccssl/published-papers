#!/bin/bash

harness="harness-options.json"
trap `echo pwd` ERR
# create and copy lib
outputPath=$2
rm -rf $outputPath 
mkdir $outputPath
cd $1
while read line
do
cd $path
process $name
cd ..
done < <(cat ~/Desktop/list)
