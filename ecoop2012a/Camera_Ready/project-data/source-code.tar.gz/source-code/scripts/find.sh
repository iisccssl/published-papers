# !/bin/sh

word="require"
for i in $1
do
cd $i
if [ "$i" == "" ]
then
echo $i
fi
cd ..
done
