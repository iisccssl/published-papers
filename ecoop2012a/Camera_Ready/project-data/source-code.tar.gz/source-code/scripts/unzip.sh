#!/bin/bash

while read file
do
mkdir $file; cd $file; unzip ../$file
done < <(cat list)
