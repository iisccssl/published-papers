#!/bin/bash

rm -r $2
cp -r $1 $2
echo "%%%%" >> $1
cat $1 | sed '/\/\* This is automatically generated code\. \*\//,/%%%%/d' > /tmp/temp
mv /tmp/temp $1
for p in *
do
if [ -d "$p" ]
then
cd $p
recurse
cd ..
else
echo `pwd`/$p
process $p
fi
done
cd $2
