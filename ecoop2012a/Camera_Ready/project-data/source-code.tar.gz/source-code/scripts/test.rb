require 'rubygems'
require 'watir-webdriver'
b = Watir::Browser.new :firefox

for i in (1..19)
b.goto('https://addons.mozilla.org/en-US/firefox/tag/jetpack?page='+ i.to_s())
File.open('/home/mdhawan/Desktop/html/t_' + i.to_s() + '.txt', 'a') do |f|
f.puts b.html
end
sleep 5
