# !/bin/sh

rm -r $2
cp -r $1 $2
local cnt=""
mv /tmp/temp $1
declare -a arr1
declare -a arr2
declare -a arr3
# using var instead of arr2[1]
n = split($0, arr1, "@@@")
m = split(arr1[i], arr2, "###")
o = split(arr2[2], arr3, ",")
printf("%s %s %s.%s;", "var", arr3[j], arr2[3], arr3[j])
printf("%s", arr1[i])
if [ "$cnt" == "1" ]
then
destructuring $1
else
return;
fi
# minify
~/Desktop/jsmin < $1 > /tmp/temp
# function definition
# Cu.import => Cuimport
cat $1 | sed -e 's/Cu\.import/Cuimport/g' > /tmp/temp
# const => var
cat $1 | sed -e 's/\<const\>/var/g' > /tmp/temp
# let => var (does not handle let scope)
# a = b; => a = WALA_ASSIGN(b);
cat $1 | sed -e 's/\(.*[^+-]\)=\([ ]*\)\([a-zA-Z0-9_]\+\)[,;]\+/\1=\2WALA_ASSIGN(\3);/g' > /tmp/temp
# stub generation
cat $1 | sed -e 's/\([a-zA-Z0-9_]\+\)[ ]*=[ ]*Cc.*(Ci\.nsI\([a-zA-Z0-9_]\+\))\([;\.]\)/\1 = Moz\2()\3/g' > /tmp/temp
# destructuring
# beautify
java -cp ~/Desktop/rhino/js.jar org.mozilla.javascript.tools.shell.Main ~/Desktop/beautify.js $1 > /tmp/temp
# fix indents for get/set
# prints get/set functions
local text=""
while read line
do
if [ "$text" != "" ]
echo $text
done < <(cat $1)
for p in *
if [ -d "$p" ]
cd $p
recurse
cd ..
echo `pwd`/$p
process $p
done
cd $2
