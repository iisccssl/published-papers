# !/bin/sh

base=$1
text=""
ft=""
while read line
do
cd $base"/"$line
for i in *
text=$text"\n"$temp	
done
done < <(cat ./heapmap)
echo -e $text > /tmp/temp
temp=`grep "\<"$line"\>" /tmp/temp | wc -l`
ft=$ft"\n"$line"\t"$temp	
done < <(cat /tmp/temp)
echo -e $ft | awk '!x[$0]++' | sort > ~/Desktop/heap_output
