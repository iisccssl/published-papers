# !/bin/sh

i=$1

#cd $1

#for i in *
#do
	~/Desktop/fix_datalog.sh $i
	~/Desktop/post.sh $i
	~/Desktop/temp_gen.sh $i
	~/Desktop/overpriv.sh $i
#done
