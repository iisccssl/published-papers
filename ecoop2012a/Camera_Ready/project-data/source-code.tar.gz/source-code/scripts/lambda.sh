# !/bin/sh

rm -r $2
cp -r $1 $2
# prints lambda functions
local text=""
while read line
do
if [ "$text" != "" ]
then
echo $text
fi
done < <(cat $1)
for p in *
if [ -d "$p" ]
cd $p
recurse
cd ..
else
echo `pwd`/$p
process $p
done
cd $2
