# !/bin/sh

global="moduleScope"
walaAppend="WALAappend"
top_level_path=$1
# get the mapping of v values to variables
local match=""
local heap=""
# remove all true_, false_ prefixes
cat ./tempGenDir/varMap.txt | sed -e 's/false_//g' | sed -e 's/true_//g' > /tmp/temp
mv /tmp/temp ./tempGenDir/varMap.txt
# open the file
while read line
do
if [ "$match" != "" ]
then
break
fi
done < <(cat ./tempGenDir/varMap.txt)
if [ "$match" == "" ] && [ "$match" != "null" ]
val=`echo $1 | sed -e 's/\(v[0-9]\+\)_\(.*\)/\1__\2/'`
done < <(cat ./"map"/$vloc"_var")
cd ./map
for x in *.random
# remove any true_ or false_
cat $x | sed -e 's/false_//g' | sed -e 's/true_//g' > /tmp/temp
mv /tmp/temp $x
if [ "$heap" != "" ]
done
cd ..
cd ./heapMapForTemplate
for j in *.heapmap
echo $match
local match=`map $1 $2`
match=$match"\t"
local flag=false
# get line number from the privileged facts
if [ "$vloc" == "$fun" ] && [ "$2" == "$pri" ]
flag=true
if [ "$vno" == "$vnum" ]
match=$match",Y"
match=$match":"$lno
else
match=$match",N"
done < <(cat ./privileged) 
if [ "$flag" == false ]
match=$match",N/A"
local vval=$1
local name=""
if [ "$name" != "" ]
done < <(grep $1 ./tempGenDir/varMap.txt)
echo $name
local scope=$2
local b=""
local c=""
local d=""
# find v value for the function -> ret.txt
if [ "$b" != "" ]
done < <(grep $1 ./WALAappendDir/ret.txt)
# get the litername for the function from v value -> varMap.txt
if [ "$c" != "" ]
done < <(grep $b ./WALAappendDir/varMap.txt)
if [ "$d" != "" ]
done < <(grep $b ./WALAappendDir/parent.txt)
# then get the parent of the v value -> check in the parent.txt
# again in the varMap, repeat this till you reach null or exports
if [ "$d" != "" ] && [ "$c" != "exports" ]
scope=`scopeChain $d $2`"_"$c
local scope=`scopeChain $1 ""`
# constuct the scope chain for the function
# grep for scope_chain, v_value in ./aliased
if [ "$e" != "" ]
done < <(grep $scope","$1 ./aliased)
echo $e
# process each directory
# a) read v values of direct childern of exports object
declare -A child
while read file
if [ "$a" != "" ]
child[$a"_"$global]=true
done < <(cat ./children)
# b) read aliased v values
declare -A alias
if [ "$b" != "" ] && [ "$c" != "" ]
tmp=`echo $c | grep $global`
alias[$b]=$c
done < <(cat ./aliased)
# c) find set of top level exported v values
text="V_Value Variable Line# Privilege\n---------------------------------------------------------------------------------------------------------------------------------"
# if $d is not introduced from new code, then it must be a direct child
text=$text"\n"$f"\t"`position $f $e`"\t"$e
# if $d is from new code, then find aliases for $d
text=$text"\n"$m"\t"`position $m $e`"\t"$e
#if [ "$g" != "" ]
#then
#	m=`setCorrectAlias $g`
#	text=$text"\n"$m"\t"`position $m $e`"\t"$e
#fi
done < <(grep "$global\|$walaAppend" ./tainted)
# d) now check if any direct child is privileged
l=`getLiteral $f"_"$g`
# now grep in the children file
m=`grep -w $l","$f ./children`
if [ "$m" != "" ]
text=$text"\n"$f"_"$g"\t"`position $f"_"$g $k`"\t"$k
done < <(grep "$global" ./privileged)
# e) final output
cat ./output
rm ./aliased
cd $top_level_path
for p in *
cd "$p"
echo -e "\nFile = "`pwd`
# concatenate aliased_priv and aliased_taint files
`cat ./aliased_taint ./aliased_priv > ./aliased`
# remove lines with false->true and true->true alias mapping
#cat ./aliased | sed '/false_v[0-9]\+_[a-zA-Z]\+,true_v[0-9]\+_[a-zA-Z]\+/d' > /tmp/temp
#mv /tmp/temp ./aliased
cat ./aliased | sed '/true_v[0-9]\+_[a-zA-Z]\+,true_v[0-9]\+_[a-zA-Z]\+/d' > /tmp/temp
mv /tmp/temp ./aliased
# remove all true, false prefixes
cat ./aliased | sed -e 's/false_//g' | sed -e 's/true_//g' > /tmp/temp
process
