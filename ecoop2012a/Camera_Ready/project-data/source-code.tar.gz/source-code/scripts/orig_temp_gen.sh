# !/bin/sh

local vval=$1
local name=""
while read line
do
if [ "$name" != "" ]
then
break
fi
done < <(grep $1 ./tempGenDir/varMap.txt)
# if name is null then it is not a property
# it could be a local variable, so look in the scope map
#if [ "$name" == "" ]
#then
#	
#	val=`echo $1 | sed -e 's/\(v[0-9]\+\)_\(.*\)/\1__\2/'`
#	while read line
#	do
#		if [ "$name" != "" ]
#		then
#			break
#		fi
#	done < <(cat ./"map"/$vloc"_var")
#fi
echo $name
local text=$2
if [ "$parentV" == "" ]
text=`getLiteral $parentV`"."$text
text=`hierarchy $parentV $text`
done < <(grep ",false_"$1 ./tempGenDir/parent.txt)
echo $text
local priv=$2
local text=$3
# test if the child appears in the privileged or not
#local checkscope=`grep $tmp2 ./privileged`
#
#if [ "$checkscope" != "" ]
#	local checkval=`echo -e $checkscope | grep $tmp1`
#	# TODO: ensure that the capability in privileged file is same
#	if [ "$checkval" != "" ]
#	then
#		echo $text"."`getLiteral $child`
#	#else
#		# check if the privileged value is an alias for this child or not
#		# loop over aliased_priv
#		# if yes, then echo $text"."`getLiteral $child`
#	fi
#else
#	# if not then is the child a parent of another object which
#	# could be an alias of another privilege
#	echo $text"."`getLiteral $vval`"."`testChildren $child $priv $text`
local check=`grep $child ./tainted`
if [ "$check" != "" ]
echo $text"."`getLiteral $vval`
else
echo $text"."`getLiteral $vval`"."`testChildren $child $priv $text`
done < <(grep $vval"," ./tempGenDir/parent.txt)
out = $2;
for (i = 3; i <= NF; i++)
out	= out"_"$i;
print out;
local checkscope=`grep $tmp1"__"$tmp2 ./privileged`
if [ "$checkscope" != "" ]
# TODO: ensure that the capability in privileged file is same
out = "exports";
for (i = 1; i <= NF; i++)
out	=	out"."$i;
# if it is not found in the privileged file, then it could be an alias
# or an inherited privilege, either through 'require' or 'this'
# process each directory
# remove duplicates from tempGenDir
cd tempGenDir
for i in *
cat $i | awk '!x[$0]++' > /tmp/temp
mv /tmp/temp $i
done
cd ..
# remove multiple spaces in output file
#cat ./output | sed -e "s/[ \t]\+/ /g" | sed '1d' | sed '1d' | sed -e '/this[ ]\+,N\/A/d' -e '/null[ ]\+,N\/A/d' > ./output_temp
cat ./output | sed -e "s/[ \t]\+/ /g" | sed '1d' | sed '1d' | sed -e '/this[ ]\+,N\/A/d' -e '/null[ ]\+,N\/A/d' -e '/exports[ ]\+,N\/A/d' > ./output_temp
#cat ./output | sed -e "s/[ \t]\+/ /g" | sed '1d' | sed '1d' > ./output_temp
declare -A arr
local fileContent=""
# get all the exported privileges
arr[$tempcap]=true
done < <(cat ./output_temp)
fileContent=$fileContent","$i
# read the output file
local child=`getLiteral $vval`
local text=`hierarchy $vval $child`
# several cases arise here
# case 1: text is not null and vval is same as in privileged
# - this is the actual privileged object
# case 2: text is not null, but vval is not same as in privileged
# - this is an object whose child is privileged
# case 3: text is null then vval could be a function
# - get the children and match their vval with privileged
# - the return value is tainted, so check the vval and its aliases with privileged
if [ "$text" != "" ]
local checkscope=`grep $tmp2 ./privileged`
local checkval=`echo -e $checkscope | grep $tmp1`
if [ "$checkval" != "" ]
echo $text" Object "$priv
fileContent=$fileContent"\n"$text" Object "$priv
# check if any child is privileged
# - check parent.txt, get child v values
# now check in privileged file
# do this recursively
text=`testChildren $vval $priv $text`
#	echo "Something is wrong"
# this could be because the privilege is inherited
# and the scope is not present in the privilege file
# in this case, simply output the template
# text was null
for (i = 2; i <= NF; i++)
local tmptext=$text
# check if any associated properties
if [ "$text" == "" ]
# if text is null, then it means that the return value of the function is tainted
# check for vval and its aliases in privileged
text=`checkFnReturn $vval`
echo $text" Function "$priv
fileContent=$fileContent"\n"$text" Function "$priv
#	echo "Something is also wrong"
echo $tmptext" Function Null"
fileContent=$fileContent"\n"$tmptext" Function Null"
echo -e $fileContent | awk '!x[$0]++' > ./template
rm ./output_temp
cd $1
for p in *
cd "$p"
echo -e "\nFile = "`pwd`
process
