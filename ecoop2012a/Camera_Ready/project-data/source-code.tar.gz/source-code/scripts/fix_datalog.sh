# !/bin/sh

function process() {

	# remove all empty lines
	cat $1 | awk 'match($0,"Info:") == 0 {print $0}' | awk 'match($0,"DES-Datalog") == 0 {print $0}' | awk 'match($0,"{") == 0 {print $0}' | awk 'match($0,"}") == 0 {print $0}' | awk '{sub(/^[ \t]+/, "")};1' | awk '!x[$0]++' > /tmp/temp
	mv /tmp/temp $1

}

cd $1
for p in *
do
	cd $p
	for i in *
	do
		if [[ -f "$i" && "$i" != *.dl && "$i" != *.js ]]
		then
			echo "Done: " + `pwd`/$i
			process $i
		else
			echo `pwd`/$i
		fi
	done
	cd ..
done
