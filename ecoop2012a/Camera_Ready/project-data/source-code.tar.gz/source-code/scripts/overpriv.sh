# !/bin/sh

global="moduleScope"
top_level_path=$1

function getLiteral() {

	local val=`echo $1 | sed -e 's/false_//g' | sed -e 's/true_//g' | sed -e 's/\(v[0-9]\+\)_\(.*\)/\1__\2/'`
	local vnum=`echo $val | awk -F'__' '{print $1}'`
	local vloc=`echo $val | awk -F'__' '{print $2}'`
	while read line
	do
		local match=`echo -e $line | grep $vnum | awk '{print $2}'`
		if [ "$match" != "" ] && [ "$match" != "null" ]
		then
			break
		fi
	done < <(cat ./"map"/$vloc"_var")

	echo $match
}

function isAliased() {

	local val=`echo -e $1 | sed -e 's/false_//g'`
	local res=""
	
	while read line
	do
		local test=`echo -e $line | awk -F',' '{print $2}'`
		local match=`grep $test ./findPropLoad`
		if [ "$match" != "" ]
		then
			res=$1
			break
		fi
	done < <(grep $val ./aliased)
	
	echo $res
}

function process() {

	rm ./checkoverpriv.txt
	rm ./overpriv.txt

	# concatenate the 3 files: privID, tainted and isMozReq to checkoverpriv.txt
	`cat ./tainted ./privID.txt ./overprivilegedDir/isMozReq.txt > ./checkoverpriv.txt`
	
	# remove all true_ prefixed values from ./checkoverpriv.txt
	# get uniqe 'v' values
	cat ./checkoverpriv.txt | sed -e '/true_/d' | awk -F'[(,]' '{ print $2 }' | awk '!x[$0]++' > /tmp/temp
	mv /tmp/temp ./checkoverpriv.txt

	# remove a 'v' if it is a direct child of the exports object
	while read line
	do
		local l="false_"`echo -e $line | awk -F',' '{ print $2 }'`"_$global"
		# this is in-efficient
		cat ./checkoverpriv.txt | sed -e "/$l/d" > /tmp/temp
		mv /tmp/temp ./checkoverpriv.txt
	done < <(cat ./children)

	local text=""

	# next, get the 'v' values in findPropLoad
	while read line
	do
		local v=`echo -e $line`
		if [ "$v" != "" ]
		then
			local match=`cat ./findPropLoad | grep $v`
			if [ "$match" == "" ]
			then
				# check if there is an alias
				local n=`isAliased $v`
				if [ "$n" == "" ]
				then
					text=$text"\n"$v
				fi
			fi
		fi
	done < <(cat ./checkoverpriv.txt)

	echo -e $text | sed '/^$/d' | awk '!x[$0]++' > ./overpriv1.txt

	# get the literal values
	local fText=""
	while read line
	do
		local v=`echo -e $line`
		if [ "$v" != "" ]
		then
			local temp=`getLiteral $v`
			if [ "$temp" != "" ]
			then
				if [ "$temp" == "Cc" ] || [ "$temp" == "Ci" ] || [ "$temp" == "Cu" ]
				then
					local moz=`grep '=[ ]*Moz' ${PWD##*/}".js"`
					local cu=`grep Cuimport ${PWD##*/}".js"`
					if [ "$moz" != "" ] || [ "$cu" != "" ]
					then
						continue
					fi
				fi
				local val=`echo $v | sed -e 's/false_//g' | sed -e 's/true_//g' | sed -e 's/\(v[0-9]\+\)_\(.*\)/\1__\2/'`
				local vloc=`echo $val | awk -F'__' '{print $2}'`
				fText=$fText"\n"$temp" :: "$vloc
			fi
		fi
	done < <(cat ./overpriv1.txt)

	echo -e $fText | sed '/^$/d' | awk '!x[$0]++' > ./overpriv.txt
}

cd $top_level_path
for p in *
do
	cd "$p"
	echo -e "\nFile = "`pwd`
	process
	cd ..
done
